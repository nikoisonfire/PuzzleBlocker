// modules are defined as an array
// [ module function, map of requires ]
//
// map of requires is short require name -> numeric require
//
// anything defined in a previous bundle is accessed via the
// orig method which is the require for previous bundles

(function(modules, entry, mainEntry, parcelRequireName, globalName) {
  /* eslint-disable no-undef */
  var globalObject =
    typeof globalThis !== 'undefined'
      ? globalThis
      : typeof self !== 'undefined'
      ? self
      : typeof window !== 'undefined'
      ? window
      : typeof global !== 'undefined'
      ? global
      : {};
  /* eslint-enable no-undef */

  // Save the require from previous bundle to this closure if any
  var previousRequire =
    typeof globalObject[parcelRequireName] === 'function' &&
    globalObject[parcelRequireName];

  var cache = previousRequire.cache || {};
  // Do not use `require` to prevent Webpack from trying to bundle this call
  var nodeRequire =
    typeof module !== 'undefined' &&
    typeof module.require === 'function' &&
    module.require.bind(module);

  function newRequire(name, jumped) {
    if (!cache[name]) {
      if (!modules[name]) {
        // if we cannot find the module within our internal map or
        // cache jump to the current global require ie. the last bundle
        // that was added to the page.
        var currentRequire =
          typeof globalObject[parcelRequireName] === 'function' &&
          globalObject[parcelRequireName];
        if (!jumped && currentRequire) {
          return currentRequire(name, true);
        }

        // If there are other bundles on this page the require from the
        // previous one is saved to 'previousRequire'. Repeat this as
        // many times as there are bundles until the module is found or
        // we exhaust the require chain.
        if (previousRequire) {
          return previousRequire(name, true);
        }

        // Try the node require function if it exists.
        if (nodeRequire && typeof name === 'string') {
          return nodeRequire(name);
        }

        var err = new Error("Cannot find module '" + name + "'");
        err.code = 'MODULE_NOT_FOUND';
        throw err;
      }

      localRequire.resolve = resolve;
      localRequire.cache = {};

      var module = (cache[name] = new newRequire.Module(name));

      modules[name][0].call(
        module.exports,
        localRequire,
        module,
        module.exports,
        this
      );
    }

    return cache[name].exports;

    function localRequire(x) {
      return newRequire(localRequire.resolve(x));
    }

    function resolve(x) {
      return modules[name][1][x] || x;
    }
  }

  function Module(moduleName) {
    this.id = moduleName;
    this.bundle = newRequire;
    this.exports = {};
  }

  newRequire.isParcelRequire = true;
  newRequire.Module = Module;
  newRequire.modules = modules;
  newRequire.cache = cache;
  newRequire.parent = previousRequire;
  newRequire.register = function(id, exports) {
    modules[id] = [
      function(require, module) {
        module.exports = exports;
      },
      {},
    ];
  };

  Object.defineProperty(newRequire, 'root', {
    get: function() {
      return globalObject[parcelRequireName];
    },
  });

  globalObject[parcelRequireName] = newRequire;

  for (var i = 0; i < entry.length; i++) {
    newRequire(entry[i]);
  }

  if (mainEntry) {
    // Expose entry point to Node, AMD or browser globals
    // Based on https://github.com/ForbesLindesay/umd/blob/master/template.js
    var mainExports = newRequire(mainEntry);

    // CommonJS
    if (typeof exports === 'object' && typeof module !== 'undefined') {
      module.exports = mainExports;

      // RequireJS
    } else if (typeof define === 'function' && define.amd) {
      define(function() {
        return mainExports;
      });

      // <script>
    } else if (globalName) {
      this[globalName] = mainExports;
    }
  }
})({"1RQCG":[function(require,module,exports) {
var _optionsOptionsStorageJs = require('./options/options-storage.js');
var _parcelHelpers = require("@parcel/transformer-js/lib/esmodule-helpers.js");
var _optionsOptionsStorageJsDefault = _parcelHelpers.interopDefault(_optionsOptionsStorageJs);
var _webextensionPolyfill = require('webextension-polyfill');
var _webextensionPolyfillDefault = _parcelHelpers.interopDefault(_webextensionPolyfill);
var _webextStorageCache = require('webext-storage-cache');
var _webextStorageCacheDefault = _parcelHelpers.interopDefault(_webextStorageCache);
let difficulty;
async function main(details) {
  const options = await _optionsOptionsStorageJsDefault.default.getAll();
  if (options.enabled) {
    const blacklistArray = options.blacklist.split("\n").filter(el => el !== "");
    const currentURL = details.url;
    const currentTab = details.tabId;
    const blockEmbedded = options.embedded ? true : details.frameId === 0;
    /**
    * [
    * 	{
    * 		tabId: 1,
    * 		url: "facebook.com"
    * 	}
    * ]
    */
    const tabCache = await _webextStorageCacheDefault.default.get(currentTab);
    /**
    * 1. Check if URL matches
    * 2. Check if URL is not embedded (iFrame)
    */
    if (urlContains(currentURL, blacklistArray) && blockEmbedded) {
      // Match on blacklist
      // Check if tabCache exists
      if (tabCache === undefined) {
        const newCache = await _webextStorageCacheDefault.default.set(currentTab, currentURL, {
          minutes: options.cacheTime
        });
      } else if (tabCache === "") {
        return;
      }
      _webextensionPolyfillDefault.default.tabs.update(currentTab, {
        "url": "./redirect.html"
      });
    } else {}
  }
}
async function unblockSite(tabId) {
  const redirect = await _webextStorageCacheDefault.default.get(tabId);
  await _webextStorageCacheDefault.default.set(tabId, "");
  _webextensionPolyfillDefault.default.tabs.update(tabId, {
    "url": redirect
  });
}
async function removeTabFromCache(tabId) {
  await _webextStorageCacheDefault.default.delete(tabId);
}
function urlContains(url, keywords) {
  var result = false;
  keywords.forEach(n => {
    if (url.includes(n)) {
      result = true;
    }
  });
  return result;
}
// long days = (millis / (60*60*24*1000))
async function showGetStarted(details) {
  const now = new Date(Date.now());
  if (details.reason === "install") {
    await _optionsOptionsStorageJsDefault.default.set({
      installDate: now.toString()
    });
    _webextensionPolyfillDefault.default.tabs.create({
      active: true,
      url: "https://www.puzzleblocker.com/get-started.html"
    });
  }
}
// Clear the tab from cache once the tab is closed
_webextensionPolyfillDefault.default.tabs.onRemoved.addListener(removeTabFromCache);
// Listen to unblocking from redirect.js
_webextensionPolyfillDefault.default.runtime.onMessage.addListener(unblockSite);
// Main Loop
_webextensionPolyfillDefault.default.webNavigation.onCommitted.addListener(main);
// Show get started upon install
_webextensionPolyfillDefault.default.runtime.onInstalled.addListener(showGetStarted);
// Show uninstall url
_webextensionPolyfillDefault.default.runtime.setUninstallURL("https://www.puzzleblocker.com/uninstall.html");

},{"./options/options-storage.js":"1iuiP","webextension-polyfill":"ZHCM0","webext-storage-cache":"670ht","@parcel/transformer-js/lib/esmodule-helpers.js":"7jqoH"}],"1iuiP":[function(require,module,exports) {
var _parcelHelpers = require("@parcel/transformer-js/lib/esmodule-helpers.js");
_parcelHelpers.defineInteropFlag(exports);
var _webextOptionsSync = require('webext-options-sync');
var _webextOptionsSyncDefault = _parcelHelpers.interopDefault(_webextOptionsSync);
exports.default = new _webextOptionsSyncDefault.default({
  defaults: {
    enabled: true,
    blacklist: "facebook.com\ntwitter.com\ninstagram.com\nyoutube.com",
    difficulty: "hard",
    embedded: false,
    hintTime: 0,
    solutionTime: 0,
    cacheTime: 10
  },
  migrations: [_webextOptionsSyncDefault.default.migrations.removeUnused],
  logging: true
});

},{"webext-options-sync":"5gExX","@parcel/transformer-js/lib/esmodule-helpers.js":"7jqoH"}],"5gExX":[function(require,module,exports) {
var _parcelHelpers = require("@parcel/transformer-js/lib/esmodule-helpers.js");
_parcelHelpers.defineInteropFlag(exports);
var _webextDetectPage = require("webext-detect-page");
function throttle(delay, noTrailing, callback, debounceMode) {
  var timeoutID;
  var cancelled = false;
  var lastExec = 0;
  function clearExistingTimeout() {
    timeoutID && clearTimeout(timeoutID);
  }
  if ("boolean" != typeof noTrailing) {
    debounceMode = callback;
    callback = noTrailing;
    noTrailing = void 0;
  }
  function wrapper() {
    for (var _len = arguments.length, arguments_ = new Array(_len), _key = 0; _key < _len; _key++) arguments_[_key] = arguments[_key];
    var self = this;
    var elapsed = Date.now() - lastExec;
    if (!cancelled) {
      debounceMode && !timeoutID && exec();
      clearExistingTimeout();
      void 0 === debounceMode && elapsed > delay ? exec() : true !== noTrailing && (timeoutID = setTimeout(debounceMode ? clear : exec, void 0 === debounceMode ? delay - elapsed : delay));
    }
    function exec() {
      lastExec = Date.now();
      callback.apply(self, arguments_);
    }
    function clear() {
      timeoutID = void 0;
    }
  }
  wrapper.cancel = function () {
    clearExistingTimeout();
    cancelled = true;
  };
  return wrapper;
}
class TypeRegistry {
  constructor(initial = {}) {
    this.registeredTypes = initial;
  }
  get(type) {
    return void 0 !== this.registeredTypes[type] ? this.registeredTypes[type] : this.registeredTypes.default;
  }
  register(type, item) {
    void 0 === this.registeredTypes[type] && (this.registeredTypes[type] = item);
  }
  registerDefault(item) {
    this.register("default", item);
  }
}
class KeyExtractors extends TypeRegistry {
  constructor(options) {
    super(options);
    this.registerDefault(el => el.getAttribute("name") || "");
  }
}
class InputReaders extends TypeRegistry {
  constructor(options) {
    super(options);
    this.registerDefault(el => el.value);
    this.register("checkbox", el => null !== el.getAttribute("value") ? el.checked ? el.getAttribute("value") : null : el.checked);
    this.register("select", el => (function (elem) {
      var value, option, i;
      var options = elem.options;
      var index = elem.selectedIndex;
      var one = "select-one" === elem.type;
      var values = one ? null : [];
      var max = one ? index + 1 : options.length;
      i = index < 0 ? max : one ? index : 0;
      for (; i < max; i++) if (((option = options[i]).selected || i === index) && !option.disabled && !(option.parentNode.disabled && "optgroup" === option.parentNode.tagName.toLowerCase())) {
        value = option.value;
        if (one) return value;
        values.push(value);
      }
      return values;
    })(el));
  }
}
class KeyAssignmentValidators extends TypeRegistry {
  constructor(options) {
    super(options);
    this.registerDefault(() => true);
    this.register("radio", el => el.checked);
  }
}
function keySplitter(key) {
  let matches = key.match(/[^[\]]+/g);
  let lastKey;
  if (key.length > 1 && key.indexOf("[]") === key.length - 2) {
    lastKey = matches.pop();
    matches.push([lastKey]);
  }
  return matches;
}
var proto = "undefined" != typeof Element ? Element.prototype : {};
var vendor = proto.matches || proto.matchesSelector || proto.webkitMatchesSelector || proto.mozMatchesSelector || proto.msMatchesSelector || proto.oMatchesSelector;
var matchesSelector = function (el, selector) {
  if (!el || 1 !== el.nodeType) return false;
  if (vendor) return vendor.call(el, selector);
  var nodes = el.parentNode.querySelectorAll(selector);
  for (var i = 0; i < nodes.length; i++) if (nodes[i] == el) return true;
  return false;
};
function getElementType(el) {
  let typeAttr;
  let tagName = el.tagName;
  let type = tagName;
  if ("input" === tagName.toLowerCase()) {
    typeAttr = el.getAttribute("type");
    type = typeAttr || "text";
  }
  return type.toLowerCase();
}
function getInputElements(element, options) {
  return Array.prototype.filter.call(element.querySelectorAll("input,select,textarea"), el => {
    if ("input" === el.tagName.toLowerCase() && ("submit" === el.type || "reset" === el.type)) return false;
    let myType = getElementType(el);
    let identifier = options.keyExtractors.get(myType)(el);
    let foundInInclude = -1 !== (options.include || []).indexOf(identifier);
    let foundInExclude = -1 !== (options.exclude || []).indexOf(identifier);
    let foundInIgnored = false;
    let reject = false;
    if (options.ignoredTypes) for (let selector of options.ignoredTypes) matchesSelector(el, selector) && (foundInIgnored = true);
    reject = !foundInInclude && (!!options.include || (foundInExclude || foundInIgnored));
    return !reject;
  });
}
function assignKeyValue(obj, keychain, value) {
  if (!keychain) return obj;
  var key = keychain.shift();
  obj[key] || (obj[key] = Array.isArray(key) ? [] : {});
  0 === keychain.length && (Array.isArray(obj[key]) ? null !== value && obj[key].push(value) : obj[key] = value);
  keychain.length > 0 && assignKeyValue(obj[key], keychain, value);
  return obj;
}
function serialize(element, options = {}) {
  let data = {};
  options.keySplitter = options.keySplitter || keySplitter;
  options.keyExtractors = new KeyExtractors(options.keyExtractors || ({}));
  options.inputReaders = new InputReaders(options.inputReaders || ({}));
  options.keyAssignmentValidators = new KeyAssignmentValidators(options.keyAssignmentValidators || ({}));
  Array.prototype.forEach.call(getInputElements(element, options), el => {
    let type = getElementType(el);
    let key = options.keyExtractors.get(type)(el);
    let value = options.inputReaders.get(type)(el);
    if (options.keyAssignmentValidators.get(type)(el, key, value)) {
      let keychain = options.keySplitter(key);
      data = assignKeyValue(data, keychain, value);
    }
  });
  return data;
}
class InputWriters extends TypeRegistry {
  constructor(options) {
    super(options);
    this.registerDefault((el, value) => {
      el.value = value;
    });
    this.register("checkbox", (el, value) => {
      null === value ? el.indeterminate = true : el.checked = Array.isArray(value) ? -1 !== value.indexOf(el.value) : value;
    });
    this.register("radio", function (el, value) {
      void 0 !== value && (el.checked = el.value === value.toString());
    });
    this.register("select", setSelectValue);
  }
}
function setSelectValue(elem, value) {
  var optionSet, option;
  var options = elem.options;
  var values = (function (arr) {
    var ret = [];
    null !== arr && (Array.isArray(arr) ? ret.push.apply(ret, arr) : ret.push(arr));
    return ret;
  })(value);
  var i = options.length;
  for (; i--; ) {
    option = options[i];
    if (values.indexOf(option.value) > -1) {
      option.setAttribute("selected", true);
      optionSet = true;
    }
  }
  optionSet || (elem.selectedIndex = -1);
}
function keyJoiner(parentKey, childKey) {
  return parentKey + "[" + childKey + "]";
}
function flattenData(data, parentKey, options = {}) {
  let flatData = {};
  let keyJoiner$1 = options.keyJoiner || keyJoiner;
  for (let keyName in data) {
    if (!data.hasOwnProperty(keyName)) continue;
    let value = data[keyName];
    let hash = {};
    parentKey && (keyName = keyJoiner$1(parentKey, keyName));
    if (Array.isArray(value)) {
      hash[keyName + "[]"] = value;
      hash[keyName] = value;
    } else "object" == typeof value ? hash = flattenData(value, keyName, options) : hash[keyName] = value;
    Object.assign(flatData, hash);
  }
  return flatData;
}
function deserialize(form, data, options = {}) {
  let flattenedData = flattenData(data, null, options);
  options.keyExtractors = new KeyExtractors(options.keyExtractors || ({}));
  options.inputWriters = new InputWriters(options.inputWriters || ({}));
  Array.prototype.forEach.call(getInputElements(form, options), el => {
    let type = getElementType(el);
    let key = options.keyExtractors.get(type)(el);
    options.inputWriters.get(type)(el, flattenedData[key]);
  });
}
var lzString = ((function (module) {
  var LZString = (function () {
    var f = String.fromCharCode;
    var keyStrBase64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
    var keyStrUriSafe = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+-$";
    var baseReverseDic = {};
    function getBaseValue(alphabet, character) {
      if (!baseReverseDic[alphabet]) {
        baseReverseDic[alphabet] = {};
        for (var i = 0; i < alphabet.length; i++) baseReverseDic[alphabet][alphabet.charAt(i)] = i;
      }
      return baseReverseDic[alphabet][character];
    }
    var LZString = {
      compressToBase64: function (input) {
        if (null == input) return "";
        var res = LZString._compress(input, 6, function (a) {
          return keyStrBase64.charAt(a);
        });
        switch (res.length % 4) {
          default:
          case 0:
            return res;
          case 1:
            return res + "===";
          case 2:
            return res + "==";
          case 3:
            return res + "=";
        }
      },
      decompressFromBase64: function (input) {
        return null == input ? "" : "" == input ? null : LZString._decompress(input.length, 32, function (index) {
          return getBaseValue(keyStrBase64, input.charAt(index));
        });
      },
      compressToUTF16: function (input) {
        return null == input ? "" : LZString._compress(input, 15, function (a) {
          return f(a + 32);
        }) + " ";
      },
      decompressFromUTF16: function (compressed) {
        return null == compressed ? "" : "" == compressed ? null : LZString._decompress(compressed.length, 16384, function (index) {
          return compressed.charCodeAt(index) - 32;
        });
      },
      compressToUint8Array: function (uncompressed) {
        var compressed = LZString.compress(uncompressed);
        var buf = new Uint8Array(2 * compressed.length);
        for (var i = 0, TotalLen = compressed.length; i < TotalLen; i++) {
          var current_value = compressed.charCodeAt(i);
          buf[2 * i] = current_value >>> 8;
          buf[2 * i + 1] = current_value % 256;
        }
        return buf;
      },
      decompressFromUint8Array: function (compressed) {
        if (null == compressed) return LZString.decompress(compressed);
        var buf = new Array(compressed.length / 2);
        for (var i = 0, TotalLen = buf.length; i < TotalLen; i++) buf[i] = 256 * compressed[2 * i] + compressed[2 * i + 1];
        var result = [];
        buf.forEach(function (c) {
          result.push(f(c));
        });
        return LZString.decompress(result.join(""));
      },
      compressToEncodedURIComponent: function (input) {
        return null == input ? "" : LZString._compress(input, 6, function (a) {
          return keyStrUriSafe.charAt(a);
        });
      },
      decompressFromEncodedURIComponent: function (input) {
        if (null == input) return "";
        if ("" == input) return null;
        input = input.replace(/ /g, "+");
        return LZString._decompress(input.length, 32, function (index) {
          return getBaseValue(keyStrUriSafe, input.charAt(index));
        });
      },
      compress: function (uncompressed) {
        return LZString._compress(uncompressed, 16, function (a) {
          return f(a);
        });
      },
      _compress: function (uncompressed, bitsPerChar, getCharFromInt) {
        if (null == uncompressed) return "";
        var i, value, ii, context_dictionary = {}, context_dictionaryToCreate = {}, context_c = "", context_wc = "", context_w = "", context_enlargeIn = 2, context_dictSize = 3, context_numBits = 2, context_data = [], context_data_val = 0, context_data_position = 0;
        for (ii = 0; ii < uncompressed.length; ii += 1) {
          context_c = uncompressed.charAt(ii);
          if (!Object.prototype.hasOwnProperty.call(context_dictionary, context_c)) {
            context_dictionary[context_c] = context_dictSize++;
            context_dictionaryToCreate[context_c] = true;
          }
          context_wc = context_w + context_c;
          if (Object.prototype.hasOwnProperty.call(context_dictionary, context_wc)) context_w = context_wc; else {
            if (Object.prototype.hasOwnProperty.call(context_dictionaryToCreate, context_w)) {
              if (context_w.charCodeAt(0) < 256) {
                for (i = 0; i < context_numBits; i++) {
                  context_data_val <<= 1;
                  if (context_data_position == bitsPerChar - 1) {
                    context_data_position = 0;
                    context_data.push(getCharFromInt(context_data_val));
                    context_data_val = 0;
                  } else context_data_position++;
                }
                value = context_w.charCodeAt(0);
                for (i = 0; i < 8; i++) {
                  context_data_val = context_data_val << 1 | 1 & value;
                  if (context_data_position == bitsPerChar - 1) {
                    context_data_position = 0;
                    context_data.push(getCharFromInt(context_data_val));
                    context_data_val = 0;
                  } else context_data_position++;
                  value >>= 1;
                }
              } else {
                value = 1;
                for (i = 0; i < context_numBits; i++) {
                  context_data_val = context_data_val << 1 | value;
                  if (context_data_position == bitsPerChar - 1) {
                    context_data_position = 0;
                    context_data.push(getCharFromInt(context_data_val));
                    context_data_val = 0;
                  } else context_data_position++;
                  value = 0;
                }
                value = context_w.charCodeAt(0);
                for (i = 0; i < 16; i++) {
                  context_data_val = context_data_val << 1 | 1 & value;
                  if (context_data_position == bitsPerChar - 1) {
                    context_data_position = 0;
                    context_data.push(getCharFromInt(context_data_val));
                    context_data_val = 0;
                  } else context_data_position++;
                  value >>= 1;
                }
              }
              if (0 == --context_enlargeIn) {
                context_enlargeIn = Math.pow(2, context_numBits);
                context_numBits++;
              }
              delete context_dictionaryToCreate[context_w];
            } else {
              value = context_dictionary[context_w];
              for (i = 0; i < context_numBits; i++) {
                context_data_val = context_data_val << 1 | 1 & value;
                if (context_data_position == bitsPerChar - 1) {
                  context_data_position = 0;
                  context_data.push(getCharFromInt(context_data_val));
                  context_data_val = 0;
                } else context_data_position++;
                value >>= 1;
              }
            }
            if (0 == --context_enlargeIn) {
              context_enlargeIn = Math.pow(2, context_numBits);
              context_numBits++;
            }
            context_dictionary[context_wc] = context_dictSize++;
            context_w = String(context_c);
          }
        }
        if ("" !== context_w) {
          if (Object.prototype.hasOwnProperty.call(context_dictionaryToCreate, context_w)) {
            if (context_w.charCodeAt(0) < 256) {
              for (i = 0; i < context_numBits; i++) {
                context_data_val <<= 1;
                if (context_data_position == bitsPerChar - 1) {
                  context_data_position = 0;
                  context_data.push(getCharFromInt(context_data_val));
                  context_data_val = 0;
                } else context_data_position++;
              }
              value = context_w.charCodeAt(0);
              for (i = 0; i < 8; i++) {
                context_data_val = context_data_val << 1 | 1 & value;
                if (context_data_position == bitsPerChar - 1) {
                  context_data_position = 0;
                  context_data.push(getCharFromInt(context_data_val));
                  context_data_val = 0;
                } else context_data_position++;
                value >>= 1;
              }
            } else {
              value = 1;
              for (i = 0; i < context_numBits; i++) {
                context_data_val = context_data_val << 1 | value;
                if (context_data_position == bitsPerChar - 1) {
                  context_data_position = 0;
                  context_data.push(getCharFromInt(context_data_val));
                  context_data_val = 0;
                } else context_data_position++;
                value = 0;
              }
              value = context_w.charCodeAt(0);
              for (i = 0; i < 16; i++) {
                context_data_val = context_data_val << 1 | 1 & value;
                if (context_data_position == bitsPerChar - 1) {
                  context_data_position = 0;
                  context_data.push(getCharFromInt(context_data_val));
                  context_data_val = 0;
                } else context_data_position++;
                value >>= 1;
              }
            }
            if (0 == --context_enlargeIn) {
              context_enlargeIn = Math.pow(2, context_numBits);
              context_numBits++;
            }
            delete context_dictionaryToCreate[context_w];
          } else {
            value = context_dictionary[context_w];
            for (i = 0; i < context_numBits; i++) {
              context_data_val = context_data_val << 1 | 1 & value;
              if (context_data_position == bitsPerChar - 1) {
                context_data_position = 0;
                context_data.push(getCharFromInt(context_data_val));
                context_data_val = 0;
              } else context_data_position++;
              value >>= 1;
            }
          }
          if (0 == --context_enlargeIn) {
            context_enlargeIn = Math.pow(2, context_numBits);
            context_numBits++;
          }
        }
        value = 2;
        for (i = 0; i < context_numBits; i++) {
          context_data_val = context_data_val << 1 | 1 & value;
          if (context_data_position == bitsPerChar - 1) {
            context_data_position = 0;
            context_data.push(getCharFromInt(context_data_val));
            context_data_val = 0;
          } else context_data_position++;
          value >>= 1;
        }
        for (; ; ) {
          context_data_val <<= 1;
          if (context_data_position == bitsPerChar - 1) {
            context_data.push(getCharFromInt(context_data_val));
            break;
          }
          context_data_position++;
        }
        return context_data.join("");
      },
      decompress: function (compressed) {
        return null == compressed ? "" : "" == compressed ? null : LZString._decompress(compressed.length, 32768, function (index) {
          return compressed.charCodeAt(index);
        });
      },
      _decompress: function (length, resetValue, getNextValue) {
        var i, w, bits, resb, maxpower, power, c, dictionary = [], enlargeIn = 4, dictSize = 4, numBits = 3, entry = "", result = [], data = {
          val: getNextValue(0),
          position: resetValue,
          index: 1
        };
        for (i = 0; i < 3; i += 1) dictionary[i] = i;
        bits = 0;
        maxpower = Math.pow(2, 2);
        power = 1;
        for (; power != maxpower; ) {
          resb = data.val & data.position;
          data.position >>= 1;
          if (0 == data.position) {
            data.position = resetValue;
            data.val = getNextValue(data.index++);
          }
          bits |= (resb > 0 ? 1 : 0) * power;
          power <<= 1;
        }
        switch (bits) {
          case 0:
            bits = 0;
            maxpower = Math.pow(2, 8);
            power = 1;
            for (; power != maxpower; ) {
              resb = data.val & data.position;
              data.position >>= 1;
              if (0 == data.position) {
                data.position = resetValue;
                data.val = getNextValue(data.index++);
              }
              bits |= (resb > 0 ? 1 : 0) * power;
              power <<= 1;
            }
            c = f(bits);
            break;
          case 1:
            bits = 0;
            maxpower = Math.pow(2, 16);
            power = 1;
            for (; power != maxpower; ) {
              resb = data.val & data.position;
              data.position >>= 1;
              if (0 == data.position) {
                data.position = resetValue;
                data.val = getNextValue(data.index++);
              }
              bits |= (resb > 0 ? 1 : 0) * power;
              power <<= 1;
            }
            c = f(bits);
            break;
          case 2:
            return "";
        }
        dictionary[3] = c;
        w = c;
        result.push(c);
        for (; ; ) {
          if (data.index > length) return "";
          bits = 0;
          maxpower = Math.pow(2, numBits);
          power = 1;
          for (; power != maxpower; ) {
            resb = data.val & data.position;
            data.position >>= 1;
            if (0 == data.position) {
              data.position = resetValue;
              data.val = getNextValue(data.index++);
            }
            bits |= (resb > 0 ? 1 : 0) * power;
            power <<= 1;
          }
          switch (c = bits) {
            case 0:
              bits = 0;
              maxpower = Math.pow(2, 8);
              power = 1;
              for (; power != maxpower; ) {
                resb = data.val & data.position;
                data.position >>= 1;
                if (0 == data.position) {
                  data.position = resetValue;
                  data.val = getNextValue(data.index++);
                }
                bits |= (resb > 0 ? 1 : 0) * power;
                power <<= 1;
              }
              dictionary[dictSize++] = f(bits);
              c = dictSize - 1;
              enlargeIn--;
              break;
            case 1:
              bits = 0;
              maxpower = Math.pow(2, 16);
              power = 1;
              for (; power != maxpower; ) {
                resb = data.val & data.position;
                data.position >>= 1;
                if (0 == data.position) {
                  data.position = resetValue;
                  data.val = getNextValue(data.index++);
                }
                bits |= (resb > 0 ? 1 : 0) * power;
                power <<= 1;
              }
              dictionary[dictSize++] = f(bits);
              c = dictSize - 1;
              enlargeIn--;
              break;
            case 2:
              return result.join("");
          }
          if (0 == enlargeIn) {
            enlargeIn = Math.pow(2, numBits);
            numBits++;
          }
          if (dictionary[c]) entry = dictionary[c]; else {
            if (c !== dictSize) return null;
            entry = w + w.charAt(0);
          }
          result.push(entry);
          dictionary[dictSize++] = w + entry.charAt(0);
          w = entry;
          if (0 == --enlargeIn) {
            enlargeIn = Math.pow(2, numBits);
            numBits++;
          }
        }
      }
    };
    return LZString;
  })();
  null != module && (module.exports = LZString);
})(module = {
  exports: {}
}, module.exports), module.exports);
var module;
class OptionsSync {
  constructor({defaults: defaults = {}, storageName: storageName = "options", migrations: migrations = [], logging: logging = true} = {}) {
    Object.defineProperty(this, "storageName", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "defaults", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "_form", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "_migrations", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    this.storageName = storageName;
    this.defaults = defaults;
    this._handleFormInput = (delay = 300, atBegin = this._handleFormInput.bind(this), void 0 === callback ? throttle(delay, atBegin, false) : throttle(delay, callback, false !== atBegin));
    var delay, atBegin, callback;
    this._handleStorageChangeOnForm = this._handleStorageChangeOnForm.bind(this);
    logging || (this._log = () => {});
    this._migrations = this._runMigrations(migrations);
  }
  async getAll() {
    await this._migrations;
    return this._getAll();
  }
  async setAll(newOptions) {
    await this._migrations;
    return this._setAll(newOptions);
  }
  async set(newOptions) {
    return this.setAll({
      ...await this.getAll(),
      ...newOptions
    });
  }
  async syncForm(form) {
    this._form = form instanceof HTMLFormElement ? form : document.querySelector(form);
    this._form.addEventListener("input", this._handleFormInput);
    this._form.addEventListener("submit", this._handleFormSubmit);
    chrome.storage.onChanged.addListener(this._handleStorageChangeOnForm);
    this._updateForm(this._form, await this.getAll());
  }
  async stopSyncForm() {
    if (this._form) {
      this._form.removeEventListener("input", this._handleFormInput);
      this._form.removeEventListener("submit", this._handleFormSubmit);
      chrome.storage.onChanged.removeListener(this._handleStorageChangeOnForm);
      delete this._form;
    }
  }
  _log(method, ...args) {
    console[method](...args);
  }
  async _getAll() {
    return new Promise((resolve, reject) => {
      chrome.storage.sync.get(this.storageName, result => {
        chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(this._decode(result[this.storageName]));
      });
    });
  }
  async _setAll(newOptions) {
    this._log("log", "Saving options", newOptions);
    return new Promise((resolve, reject) => {
      chrome.storage.sync.set({
        [this.storageName]: this._encode(newOptions)
      }, () => {
        chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve();
      });
    });
  }
  _encode(options) {
    const thinnedOptions = {
      ...options
    };
    for (const [key, value] of Object.entries(thinnedOptions)) this.defaults[key] === value && delete thinnedOptions[key];
    this._log("log", "Without the default values", thinnedOptions);
    return lzString.compressToEncodedURIComponent(JSON.stringify(thinnedOptions));
  }
  _decode(options) {
    let decompressed = options;
    "string" == typeof options && (decompressed = JSON.parse(lzString.decompressFromEncodedURIComponent(options)));
    return {
      ...this.defaults,
      ...decompressed
    };
  }
  async _runMigrations(migrations) {
    if (0 === migrations.length || !_webextDetectPage.isBackgroundPage() || !await (async function () {
      return new Promise(resolve => {
        var _a;
        const callback = installType => {
          if ("development" !== installType) {
            chrome.runtime.onInstalled.addListener(() => resolve(true));
            setTimeout(resolve, 500, false);
          } else resolve(true);
        };
        (null === (_a = chrome.management) || void 0 === _a ? void 0 : _a.getSelf) ? chrome.management.getSelf(({installType: installType}) => callback(installType)) : callback("unknown");
      });
    })()) return;
    const options = await this._getAll();
    const initial = JSON.stringify(options);
    this._log("log", "Found these stored options", {
      ...options
    });
    this._log("info", "Will run", migrations.length, 1 === migrations.length ? "migration" : " migrations");
    migrations.forEach(migrate => migrate(options, this.defaults));
    initial !== JSON.stringify(options) && await this._setAll(options);
  }
  async _handleFormInput({target: target}) {
    const field = target;
    if (field.name) {
      await this.set(this._parseForm(field.form));
      field.form.dispatchEvent(new CustomEvent("options-sync:form-synced", {
        bubbles: true
      }));
    }
  }
  _handleFormSubmit(event) {
    event.preventDefault();
  }
  _updateForm(form, options) {
    const currentFormState = this._parseForm(form);
    for (const [key, value] of Object.entries(options)) currentFormState[key] === value && delete options[key];
    const include = Object.keys(options);
    include.length > 0 && deserialize(form, options, {
      include: include
    });
  }
  _parseForm(form) {
    const include = [];
    for (const field of form.querySelectorAll("[name]")) field.validity.valid && !field.disabled && include.push(field.name.replace(/\[.*]/, ""));
    return serialize(form, {
      include: include
    });
  }
  _handleStorageChangeOnForm(changes, areaName) {
    "sync" !== areaName || !changes[this.storageName] || document.hasFocus() && this._form.contains(document.activeElement) || this._updateForm(this._form, this._decode(changes[this.storageName].newValue));
  }
}
Object.defineProperty(OptionsSync, "migrations", {
  enumerable: true,
  configurable: true,
  writable: true,
  value: {
    removeUnused(options, defaults) {
      for (const key of Object.keys(options)) (key in defaults) || delete options[key];
    }
  }
});
exports.default = OptionsSync;

},{"webext-detect-page":"74KI2","@parcel/transformer-js/lib/esmodule-helpers.js":"7jqoH"}],"74KI2":[function(require,module,exports) {
var _parcelHelpers = require("@parcel/transformer-js/lib/esmodule-helpers.js");
_parcelHelpers.defineInteropFlag(exports);
_parcelHelpers.export(exports, "isContentScript", function () {
  return isContentScript;
});
_parcelHelpers.export(exports, "isBackgroundPage", function () {
  return isBackgroundPage;
});
_parcelHelpers.export(exports, "isOptionsPage", function () {
  return isOptionsPage;
});
const isExtensionContext = typeof chrome === 'object' && chrome && typeof chrome.extension === 'object';
const globalWindow = typeof window === 'object' ? window : undefined;
const isWeb = typeof location === 'object' && location.protocol.startsWith('http');
function isContentScript() {
  return isExtensionContext && isWeb;
}
function isBackgroundPage() {
  var _a, _b;
  return isExtensionContext && (location.pathname === '/_generated_background_page.html' || ((_b = (_a = chrome.extension) === null || _a === void 0 ? void 0 : _a.getBackgroundPage) === null || _b === void 0 ? void 0 : _b.call(_a)) === globalWindow);
}
function isOptionsPage() {
  if (!isExtensionContext || !chrome.runtime.getManifest) {
    return false;
  }
  const {options_ui} = chrome.runtime.getManifest();
  if (typeof options_ui !== 'object' || typeof options_ui.page !== 'string') {
    return false;
  }
  const url = new URL(options_ui.page, location.origin);
  return url.pathname === location.pathname && url.origin === location.origin;
}

},{"@parcel/transformer-js/lib/esmodule-helpers.js":"7jqoH"}],"7jqoH":[function(require,module,exports) {
"use strict";

exports.interopDefault = function (a) {
  return a && a.__esModule ? a : {
    default: a
  };
};

exports.defineInteropFlag = function (a) {
  Object.defineProperty(a, '__esModule', {
    value: true
  });
};

exports.exportAll = function (source, dest) {
  Object.keys(source).forEach(function (key) {
    if (key === 'default' || key === '__esModule') {
      return;
    } // Skip duplicate re-exports when they have the same value.


    if (key in dest && dest[key] === source[key]) {
      return;
    }

    Object.defineProperty(dest, key, {
      enumerable: true,
      get: function () {
        return source[key];
      }
    });
  });
  return dest;
};

exports.export = function (dest, destName, get) {
  Object.defineProperty(dest, destName, {
    enumerable: true,
    get: get
  });
};
},{}],"ZHCM0":[function(require,module,exports) {
var define;
(function (global, factory) {
  if (typeof define === "function" && define.amd) {
    define("webextension-polyfill", ["module"], factory);
  } else if (typeof exports !== "undefined") {
    factory(module);
  } else {
    var mod = {
      exports: {}
    };
    factory(mod);
    global.browser = mod.exports;
  }
})(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : this, function (module) {
  /*webextension-polyfill - v0.7.0 - Tue Nov 10 2020 20:24:04*/
  /*-*- Mode: indent-tabs-mode: nil; js-indent-level: 2 -*-*/
  /*vim: set sts=2 sw=2 et tw=80:*/
  /*This Source Code Form is subject to the terms of the Mozilla Public
  * License, v. 2.0. If a copy of the MPL was not distributed with this
  * file, You can obtain one at http://mozilla.org/MPL/2.0/.*/
  "use strict";
  if (typeof browser === "undefined" || Object.getPrototypeOf(browser) !== Object.prototype) {
    const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
    const SEND_RESPONSE_DEPRECATION_WARNING = "Returning a Promise is the preferred way to send a reply from an onMessage/onMessageExternal listener, as the sendResponse will be removed from the specs (See https://developer.mozilla.org/docs/Mozilla/Add-ons/WebExtensions/API/runtime/onMessage)";
    // Wrapping the bulk of this polyfill in a one-time-use function is a minor
    // optimization for Firefox. Since Spidermonkey does not fully parse the
    // contents of a function until the first time it's called, and since it will
    // never actually need to be called, this allows the polyfill to be included
    // in Firefox nearly for free.
    const wrapAPIs = extensionAPIs => {
      // NOTE: apiMetadata is associated to the content of the api-metadata.json file
      // at build time by replacing the following "include" with the content of the
      // JSON file.
      const apiMetadata = {
        "alarms": {
          "clear": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "clearAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "get": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "bookmarks": {
          "create": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getChildren": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getRecent": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getSubTree": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTree": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "move": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeTree": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "browserAction": {
          "disable": {
            "minArgs": 0,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "enable": {
            "minArgs": 0,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "getBadgeBackgroundColor": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getBadgeText": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getPopup": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTitle": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "openPopup": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "setBadgeBackgroundColor": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setBadgeText": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setIcon": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "setPopup": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setTitle": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "browsingData": {
          "remove": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "removeCache": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeCookies": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeDownloads": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeFormData": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeHistory": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeLocalStorage": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removePasswords": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removePluginData": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "settings": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "commands": {
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "contextMenus": {
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "cookies": {
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAllCookieStores": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "set": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "devtools": {
          "inspectedWindow": {
            "eval": {
              "minArgs": 1,
              "maxArgs": 2,
              "singleCallbackArg": false
            }
          },
          "panels": {
            "create": {
              "minArgs": 3,
              "maxArgs": 3,
              "singleCallbackArg": true
            },
            "elements": {
              "createSidebarPane": {
                "minArgs": 1,
                "maxArgs": 1
              }
            }
          }
        },
        "downloads": {
          "cancel": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "download": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "erase": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getFileIcon": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "open": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "pause": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeFile": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "resume": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "show": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "extension": {
          "isAllowedFileSchemeAccess": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "isAllowedIncognitoAccess": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "history": {
          "addUrl": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "deleteAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "deleteRange": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "deleteUrl": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getVisits": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "i18n": {
          "detectLanguage": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAcceptLanguages": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "identity": {
          "launchWebAuthFlow": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "idle": {
          "queryState": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "management": {
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getSelf": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "setEnabled": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "uninstallSelf": {
            "minArgs": 0,
            "maxArgs": 1
          }
        },
        "notifications": {
          "clear": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "create": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getPermissionLevel": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "pageAction": {
          "getPopup": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTitle": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "hide": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setIcon": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "setPopup": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setTitle": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "show": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "permissions": {
          "contains": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "request": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "runtime": {
          "getBackgroundPage": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getPlatformInfo": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "openOptionsPage": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "requestUpdateCheck": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "sendMessage": {
            "minArgs": 1,
            "maxArgs": 3
          },
          "sendNativeMessage": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "setUninstallURL": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "sessions": {
          "getDevices": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getRecentlyClosed": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "restore": {
            "minArgs": 0,
            "maxArgs": 1
          }
        },
        "storage": {
          "local": {
            "clear": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "remove": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "set": {
              "minArgs": 1,
              "maxArgs": 1
            }
          },
          "managed": {
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            }
          },
          "sync": {
            "clear": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "remove": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "set": {
              "minArgs": 1,
              "maxArgs": 1
            }
          }
        },
        "tabs": {
          "captureVisibleTab": {
            "minArgs": 0,
            "maxArgs": 2
          },
          "create": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "detectLanguage": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "discard": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "duplicate": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "executeScript": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getCurrent": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getZoom": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getZoomSettings": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "goBack": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "goForward": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "highlight": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "insertCSS": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "move": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "query": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "reload": {
            "minArgs": 0,
            "maxArgs": 2
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeCSS": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "sendMessage": {
            "minArgs": 2,
            "maxArgs": 3
          },
          "setZoom": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "setZoomSettings": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "update": {
            "minArgs": 1,
            "maxArgs": 2
          }
        },
        "topSites": {
          "get": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "webNavigation": {
          "getAllFrames": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getFrame": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "webRequest": {
          "handlerBehaviorChanged": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "windows": {
          "create": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getCurrent": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getLastFocused": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        }
      };
      if (Object.keys(apiMetadata).length === 0) {
        throw new Error("api-metadata.json has not been included in browser-polyfill");
      }
      /**
      * A WeakMap subclass which creates and stores a value for any key which does
      * not exist when accessed, but behaves exactly as an ordinary WeakMap
      * otherwise.
      *
      * @param {function} createItem
      *        A function which will be called in order to create the value for any
      *        key which does not exist, the first time it is accessed. The
      *        function receives, as its only argument, the key being created.
      */
      class DefaultWeakMap extends WeakMap {
        constructor(createItem, items = undefined) {
          super(items);
          this.createItem = createItem;
        }
        get(key) {
          if (!this.has(key)) {
            this.set(key, this.createItem(key));
          }
          return super.get(key);
        }
      }
      /**
      * Returns true if the given object is an object with a `then` method, and can
      * therefore be assumed to behave as a Promise.
      *
      * @param {*} value The value to test.
      * @returns {boolean} True if the value is thenable.
      */
      const isThenable = value => {
        return value && typeof value === "object" && typeof value.then === "function";
      };
      /**
      * Creates and returns a function which, when called, will resolve or reject
      * the given promise based on how it is called:
      *
      * - If, when called, `chrome.runtime.lastError` contains a non-null object,
      *   the promise is rejected with that value.
      * - If the function is called with exactly one argument, the promise is
      *   resolved to that value.
      * - Otherwise, the promise is resolved to an array containing all of the
      *   function's arguments.
      *
      * @param {object} promise
      *        An object containing the resolution and rejection functions of a
      *        promise.
      * @param {function} promise.resolve
      *        The promise's resolution function.
      * @param {function} promise.rejection
      *        The promise's rejection function.
      * @param {object} metadata
      *        Metadata about the wrapped method which has created the callback.
      * @param {integer} metadata.maxResolvedArgs
      *        The maximum number of arguments which may be passed to the
      *        callback created by the wrapped async function.
      *
      * @returns {function}
      *        The generated callback function.
      */
      const makeCallback = (promise, metadata) => {
        return (...callbackArgs) => {
          if (extensionAPIs.runtime.lastError) {
            promise.reject(extensionAPIs.runtime.lastError);
          } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
            promise.resolve(callbackArgs[0]);
          } else {
            promise.resolve(callbackArgs);
          }
        };
      };
      const pluralizeArguments = numArgs => numArgs == 1 ? "argument" : "arguments";
      /**
      * Creates a wrapper function for a method with the given name and metadata.
      *
      * @param {string} name
      *        The name of the method which is being wrapped.
      * @param {object} metadata
      *        Metadata about the method being wrapped.
      * @param {integer} metadata.minArgs
      *        The minimum number of arguments which must be passed to the
      *        function. If called with fewer than this number of arguments, the
      *        wrapper will raise an exception.
      * @param {integer} metadata.maxArgs
      *        The maximum number of arguments which may be passed to the
      *        function. If called with more than this number of arguments, the
      *        wrapper will raise an exception.
      * @param {integer} metadata.maxResolvedArgs
      *        The maximum number of arguments which may be passed to the
      *        callback created by the wrapped async function.
      *
      * @returns {function(object, ...*)}
      *       The generated wrapper function.
      */
      const wrapAsyncFunction = (name, metadata) => {
        return function asyncFunctionWrapper(target, ...args) {
          if (args.length < metadata.minArgs) {
            throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
          }
          if (args.length > metadata.maxArgs) {
            throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
          }
          return new Promise((resolve, reject) => {
            if (metadata.fallbackToNoCallback) {
              // This API method has currently no callback on Chrome, but it return a promise on Firefox,
              // and so the polyfill will try to call it with a callback first, and it will fallback
              // to not passing the callback if the first call fails.
              try {
                target[name](...args, makeCallback({
                  resolve,
                  reject
                }, metadata));
              } catch (cbError) {
                console.warn(`${name} API method doesn't seem to support the callback parameter, ` + "falling back to call it without a callback: ", cbError);
                target[name](...args);
                // Update the API method metadata, so that the next API calls will not try to
                // use the unsupported callback anymore.
                metadata.fallbackToNoCallback = false;
                metadata.noCallback = true;
                resolve();
              }
            } else if (metadata.noCallback) {
              target[name](...args);
              resolve();
            } else {
              target[name](...args, makeCallback({
                resolve,
                reject
              }, metadata));
            }
          });
        };
      };
      /**
      * Wraps an existing method of the target object, so that calls to it are
      * intercepted by the given wrapper function. The wrapper function receives,
      * as its first argument, the original `target` object, followed by each of
      * the arguments passed to the original method.
      *
      * @param {object} target
      *        The original target object that the wrapped method belongs to.
      * @param {function} method
      *        The method being wrapped. This is used as the target of the Proxy
      *        object which is created to wrap the method.
      * @param {function} wrapper
      *        The wrapper function which is called in place of a direct invocation
      *        of the wrapped method.
      *
      * @returns {Proxy<function>}
      *        A Proxy object for the given method, which invokes the given wrapper
      *        method in its place.
      */
      const wrapMethod = (target, method, wrapper) => {
        return new Proxy(method, {
          apply(targetMethod, thisObj, args) {
            return wrapper.call(thisObj, target, ...args);
          }
        });
      };
      let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
      /**
      * Wraps an object in a Proxy which intercepts and wraps certain methods
      * based on the given `wrappers` and `metadata` objects.
      *
      * @param {object} target
      *        The target object to wrap.
      *
      * @param {object} [wrappers = {}]
      *        An object tree containing wrapper functions for special cases. Any
      *        function present in this object tree is called in place of the
      *        method in the same location in the `target` object tree. These
      *        wrapper methods are invoked as described in {@see wrapMethod}.
      *
      * @param {object} [metadata = {}]
      *        An object tree containing metadata used to automatically generate
      *        Promise-based wrapper functions for asynchronous. Any function in
      *        the `target` object tree which has a corresponding metadata object
      *        in the same location in the `metadata` tree is replaced with an
      *        automatically-generated wrapper function, as described in
      *        {@see wrapAsyncFunction}
      *
      * @returns {Proxy<object>}
      */
      const wrapObject = (target, wrappers = {}, metadata = {}) => {
        let cache = Object.create(null);
        let handlers = {
          has(proxyTarget, prop) {
            return (prop in target) || (prop in cache);
          },
          get(proxyTarget, prop, receiver) {
            if ((prop in cache)) {
              return cache[prop];
            }
            if (!((prop in target))) {
              return undefined;
            }
            let value = target[prop];
            if (typeof value === "function") {
              // This is a method on the underlying object. Check if we need to do
              // any wrapping.
              if (typeof wrappers[prop] === "function") {
                // We have a special-case wrapper for this method.
                value = wrapMethod(target, target[prop], wrappers[prop]);
              } else if (hasOwnProperty(metadata, prop)) {
                // This is an async method that we have metadata for. Create a
                // Promise wrapper for it.
                let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                value = wrapMethod(target, target[prop], wrapper);
              } else {
                // This is a method that we don't know or care about. Return the
                // original method, bound to the underlying object.
                value = value.bind(target);
              }
            } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
              // This is an object that we need to do some wrapping for the children
              // of. Create a sub-object wrapper for it with the appropriate child
              // metadata.
              value = wrapObject(value, wrappers[prop], metadata[prop]);
            } else if (hasOwnProperty(metadata, "*")) {
              // Wrap all properties in * namespace.
              value = wrapObject(value, wrappers[prop], metadata["*"]);
            } else {
              // We don't need to do any wrapping for this property,
              // so just forward all access to the underlying object.
              Object.defineProperty(cache, prop, {
                configurable: true,
                enumerable: true,
                get() {
                  return target[prop];
                },
                set(value) {
                  target[prop] = value;
                }
              });
              return value;
            }
            cache[prop] = value;
            return value;
          },
          set(proxyTarget, prop, value, receiver) {
            if ((prop in cache)) {
              cache[prop] = value;
            } else {
              target[prop] = value;
            }
            return true;
          },
          defineProperty(proxyTarget, prop, desc) {
            return Reflect.defineProperty(cache, prop, desc);
          },
          deleteProperty(proxyTarget, prop) {
            return Reflect.deleteProperty(cache, prop);
          }
        };
        // Per contract of the Proxy API, the "get" proxy handler must return the
        // original value of the target if that value is declared read-only and
        // non-configurable. For this reason, we create an object with the
        // prototype set to `target` instead of using `target` directly.
        // Otherwise we cannot return a custom object for APIs that
        // are declared read-only and non-configurable, such as `chrome.devtools`.
        // 
        // The proxy handlers themselves will still use the original `target`
        // instead of the `proxyTarget`, so that the methods and properties are
        // dereferenced via the original targets.
        let proxyTarget = Object.create(target);
        return new Proxy(proxyTarget, handlers);
      };
      /**
      * Creates a set of wrapper functions for an event object, which handles
      * wrapping of listener functions that those messages are passed.
      *
      * A single wrapper is created for each listener function, and stored in a
      * map. Subsequent calls to `addListener`, `hasListener`, or `removeListener`
      * retrieve the original wrapper, so that  attempts to remove a
      * previously-added listener work as expected.
      *
      * @param {DefaultWeakMap<function, function>} wrapperMap
      *        A DefaultWeakMap object which will create the appropriate wrapper
      *        for a given listener function when one does not exist, and retrieve
      *        an existing one when it does.
      *
      * @returns {object}
      */
      const wrapEvent = wrapperMap => ({
        addListener(target, listener, ...args) {
          target.addListener(wrapperMap.get(listener), ...args);
        },
        hasListener(target, listener) {
          return target.hasListener(wrapperMap.get(listener));
        },
        removeListener(target, listener) {
          target.removeListener(wrapperMap.get(listener));
        }
      });
      // Keep track if the deprecation warning has been logged at least once.
      let loggedSendResponseDeprecationWarning = false;
      const onMessageWrappers = new DefaultWeakMap(listener => {
        if (typeof listener !== "function") {
          return listener;
        }
        /**
        * Wraps a message listener function so that it may send responses based on
        * its return value, rather than by returning a sentinel value and calling a
        * callback. If the listener function returns a Promise, the response is
        * sent when the promise either resolves or rejects.
        *
        * @param {*} message
        *        The message sent by the other end of the channel.
        * @param {object} sender
        *        Details about the sender of the message.
        * @param {function(*)} sendResponse
        *        A callback which, when called with an arbitrary argument, sends
        *        that value as a response.
        * @returns {boolean}
        *        True if the wrapped listener returned a Promise, which will later
        *        yield a response. False otherwise.
        */
        return function onMessage(message, sender, sendResponse) {
          let didCallSendResponse = false;
          let wrappedSendResponse;
          let sendResponsePromise = new Promise(resolve => {
            wrappedSendResponse = function (response) {
              if (!loggedSendResponseDeprecationWarning) {
                console.warn(SEND_RESPONSE_DEPRECATION_WARNING, new Error().stack);
                loggedSendResponseDeprecationWarning = true;
              }
              didCallSendResponse = true;
              resolve(response);
            };
          });
          let result;
          try {
            result = listener(message, sender, wrappedSendResponse);
          } catch (err) {
            result = Promise.reject(err);
          }
          const isResultThenable = result !== true && isThenable(result);
          // If the listener didn't returned true or a Promise, or called
          // wrappedSendResponse synchronously, we can exit earlier
          // because there will be no response sent from this listener.
          if (result !== true && !isResultThenable && !didCallSendResponse) {
            return false;
          }
          // A small helper to send the message if the promise resolves
          // and an error if the promise rejects (a wrapped sendMessage has
          // to translate the message into a resolved promise or a rejected
          // promise).
          const sendPromisedResult = promise => {
            promise.then(msg => {
              // send the message value.
              sendResponse(msg);
            }, error => {
              // Send a JSON representation of the error if the rejected value
              // is an instance of error, or the object itself otherwise.
              let message;
              if (error && (error instanceof Error || typeof error.message === "string")) {
                message = error.message;
              } else {
                message = "An unexpected error occurred";
              }
              sendResponse({
                __mozWebExtensionPolyfillReject__: true,
                message
              });
            }).catch(err => {
              // Print an error on the console if unable to send the response.
              console.error("Failed to send onMessage rejected reply", err);
            });
          };
          // If the listener returned a Promise, send the resolved value as a
          // result, otherwise wait the promise related to the wrappedSendResponse
          // callback to resolve and send it as a response.
          if (isResultThenable) {
            sendPromisedResult(result);
          } else {
            sendPromisedResult(sendResponsePromise);
          }
          // Let Chrome know that the listener is replying.
          return true;
        };
      });
      const wrappedSendMessageCallback = ({reject, resolve}, reply) => {
        if (extensionAPIs.runtime.lastError) {
          // Detect when none of the listeners replied to the sendMessage call and resolve
          // the promise to undefined as in Firefox.
          // See https://github.com/mozilla/webextension-polyfill/issues/130
          if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
            resolve();
          } else {
            reject(extensionAPIs.runtime.lastError);
          }
        } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
          // Convert back the JSON representation of the error into
          // an Error instance.
          reject(new Error(reply.message));
        } else {
          resolve(reply);
        }
      };
      const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
        if (args.length < metadata.minArgs) {
          throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
        }
        if (args.length > metadata.maxArgs) {
          throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
        }
        return new Promise((resolve, reject) => {
          const wrappedCb = wrappedSendMessageCallback.bind(null, {
            resolve,
            reject
          });
          args.push(wrappedCb);
          apiNamespaceObj.sendMessage(...args);
        });
      };
      const staticWrappers = {
        runtime: {
          onMessage: wrapEvent(onMessageWrappers),
          onMessageExternal: wrapEvent(onMessageWrappers),
          sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
            minArgs: 1,
            maxArgs: 3
          })
        },
        tabs: {
          sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
            minArgs: 2,
            maxArgs: 3
          })
        }
      };
      const settingMetadata = {
        clear: {
          minArgs: 1,
          maxArgs: 1
        },
        get: {
          minArgs: 1,
          maxArgs: 1
        },
        set: {
          minArgs: 1,
          maxArgs: 1
        }
      };
      apiMetadata.privacy = {
        network: {
          "*": settingMetadata
        },
        services: {
          "*": settingMetadata
        },
        websites: {
          "*": settingMetadata
        }
      };
      return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
    };
    if (typeof chrome != "object" || !chrome || !chrome.runtime || !chrome.runtime.id) {
      throw new Error("This script should only be loaded in a browser extension.");
    }
    // The build process adds a UMD wrapper around this file, which makes the
    // `module` variable available.
    module.exports = wrapAPIs(chrome);
  } else {
    module.exports = browser;
  }
});

},{}],"670ht":[function(require,module,exports) {
var _parcelHelpers = require("@parcel/transformer-js/lib/esmodule-helpers.js");
_parcelHelpers.defineInteropFlag(exports);
var _microMemoize = require('micro-memoize');
var _microMemoizeDefault = _parcelHelpers.interopDefault(_microMemoize);
var _webextDetectPage = require('webext-detect-page');
var _sindresorhusToMilliseconds = require('@sindresorhus/to-milliseconds');
var _sindresorhusToMillisecondsDefault = _parcelHelpers.interopDefault(_sindresorhusToMilliseconds);
// @ts-expect-error
// eslint-disable-next-line @typescript-eslint/promise-function-async
const getPromise = executor => key => new Promise((resolve, reject) => {
  // @ts-expect-error
  executor(key, result => {
    if (chrome.runtime.lastError) {
      reject(chrome.runtime.lastError);
    } else {
      resolve(result);
    }
  });
});
function timeInTheFuture(time) {
  return Date.now() + _sindresorhusToMillisecondsDefault.default(time);
}
// @ts-expect-error
const storageGet = getPromise((...args) => chrome.storage.local.get(...args));
// @ts-expect-error
const storageSet = getPromise((...args) => chrome.storage.local.set(...args));
// @ts-expect-error
const storageRemove = getPromise((...args) => chrome.storage.local.remove(...args));
async function has(key) {
  return await _get(key, false) !== undefined;
}
async function _get(key, remove) {
  const internalKey = `cache:${key}`;
  const storageData = await storageGet(internalKey);
  const cachedItem = storageData[internalKey];
  if (cachedItem === undefined) {
    // `undefined` means not in cache
    return;
  }
  if (Date.now() > cachedItem.maxAge) {
    if (remove) {
      await storageRemove(internalKey);
    }
    return;
  }
  return cachedItem;
}
async function get(key) {
  var _a;
  return (_a = await _get(key, true)) === null || _a === void 0 ? void 0 : _a.data;
}
async function set(key, value, maxAge = {
  days: 30
}) {
  if (typeof value === 'undefined') {
    // @ts-expect-error This never happens in TS because `value` can't be undefined
    return;
  }
  const internalKey = `cache:${key}`;
  await storageSet({
    [internalKey]: {
      data: value,
      maxAge: timeInTheFuture(maxAge)
    }
  });
  return value;
}
async function delete_(key) {
  const internalKey = `cache:${key}`;
  return storageRemove(internalKey);
}
async function deleteWithLogic(logic) {
  var _a;
  const wholeCache = await storageGet();
  const removableItems = [];
  for (const [key, value] of Object.entries(wholeCache)) {
    if (key.startsWith('cache:') && ((_a = logic === null || logic === void 0 ? void 0 : logic(value)) !== null && _a !== void 0 ? _a : true)) {
      removableItems.push(key);
    }
  }
  if (removableItems.length > 0) {
    await storageRemove(removableItems);
  }
}
async function deleteExpired() {
  await deleteWithLogic(cachedItem => Date.now() > cachedItem.maxAge);
}
async function clear() {
  await deleteWithLogic();
}
function function_(getter, {cacheKey, maxAge = {
  days: 30
}, staleWhileRevalidate = {
  days: 0
}, shouldRevalidate} = {}) {
  const getSet = async (key, args) => {
    const freshValue = await getter(...args);
    if (freshValue === undefined) {
      await delete_(key);
      return;
    }
    const milliseconds = _sindresorhusToMillisecondsDefault.default(maxAge) + _sindresorhusToMillisecondsDefault.default(staleWhileRevalidate);
    return set(key, freshValue, {
      milliseconds
    });
  };
  return _microMemoizeDefault.default(async (...args) => {
    const userKey = cacheKey ? cacheKey(args) : args[0];
    const cachedItem = await _get(userKey, false);
    if (cachedItem === undefined || (shouldRevalidate === null || shouldRevalidate === void 0 ? void 0 : shouldRevalidate(cachedItem.data))) {
      return getSet(userKey, args);
    }
    // When the expiration is earlier than the number of days specified by `staleWhileRevalidate`, it means `maxAge` has already passed and therefore the cache is stale.
    if (timeInTheFuture(staleWhileRevalidate) > cachedItem.maxAge) {
      setTimeout(getSet, 0, userKey, args);
    }
    return cachedItem.data;
  });
}
const cache = {
  has,
  get,
  set,
  clear,
  function: function_,
  delete: delete_
};
function init() {
  // Make it available globally for ease of use
  window.webextStorageCache = cache;
  // Automatically clear cache every day
  if (!_webextDetectPage.isBackgroundPage()) {
    return;
  }
  if (chrome.alarms) {
    chrome.alarms.create('webext-storage-cache', {
      delayInMinutes: 1,
      periodInMinutes: 60 * 24
    });
    let lastRun = 0;
    // Homemade debouncing due to `chrome.alarms` potentially queueing this function
    chrome.alarms.onAlarm.addListener(alarm => {
      if (alarm.name === 'webext-storage-cache' && lastRun < Date.now() - 1000) {
        lastRun = Date.now();
        void deleteExpired();
      }
    });
  } else {
    setTimeout(deleteExpired, 60000);
    // Purge cache on launch, but wait a bit
    setInterval(deleteExpired, 1000 * 3600 * 24);
  }
}
init();
exports.default = cache;

},{"micro-memoize":"1lCCl","webext-detect-page":"74KI2","@sindresorhus/to-milliseconds":"1eujH","@parcel/transformer-js/lib/esmodule-helpers.js":"7jqoH"}],"1lCCl":[function(require,module,exports) {
var define;
(function (global, factory) {
  typeof exports === 'object' && typeof module !== 'undefined' ? module.exports = factory() : typeof define === 'function' && define.amd ? define(factory) : (global = global || self, global['micro-memoize'] = factory());
})(this, function () {
  "use strict";
  /**
  * @constant DEFAULT_OPTIONS_KEYS the default options keys
  */
  var DEFAULT_OPTIONS_KEYS = {
    isEqual: true,
    isMatchingKey: true,
    isPromise: true,
    maxSize: true,
    onCacheAdd: true,
    onCacheChange: true,
    onCacheHit: true,
    transformKey: true
  };
  /**
  * @function slice
  *
  * @description
  * slice.call() pre-bound
  */
  var slice = Array.prototype.slice;
  /**
  * @function cloneArray
  *
  * @description
  * clone the array-like object and return the new array
  *
  * @param arrayLike the array-like object to clone
  * @returns the clone as an array
  */
  function cloneArray(arrayLike) {
    var length = arrayLike.length;
    if (!length) {
      return [];
    }
    if (length === 1) {
      return [arrayLike[0]];
    }
    if (length === 2) {
      return [arrayLike[0], arrayLike[1]];
    }
    if (length === 3) {
      return [arrayLike[0], arrayLike[1], arrayLike[2]];
    }
    return slice.call(arrayLike, 0);
  }
  /**
  * @function getCustomOptions
  *
  * @description
  * get the custom options on the object passed
  *
  * @param options the memoization options passed
  * @returns the custom options passed
  */
  function getCustomOptions(options) {
    var customOptions = {};
    /*eslint-disable no-restricted-syntax*/
    for (var key in options) {
      if (!DEFAULT_OPTIONS_KEYS[key]) {
        customOptions[key] = options[key];
      }
    }
    /*eslint-enable*/
    return customOptions;
  }
  /**
  * @function isMemoized
  *
  * @description
  * is the function passed already memoized
  *
  * @param fn the function to test
  * @returns is the function already memoized
  */
  function isMemoized(fn) {
    return typeof fn === 'function' && fn.isMemoized;
  }
  /**
  * @function isSameValueZero
  *
  * @description
  * are the objects equal based on SameValueZero equality
  *
  * @param object1 the first object to compare
  * @param object2 the second object to compare
  * @returns are the two objects equal
  */
  function isSameValueZero(object1, object2) {
    // eslint-disable-next-line no-self-compare
    return object1 === object2 || object1 !== object1 && object2 !== object2;
  }
  /**
  * @function mergeOptions
  *
  * @description
  * merge the options into the target
  *
  * @param existingOptions the options provided
  * @param newOptions the options to include
  * @returns the merged options
  */
  function mergeOptions(existingOptions, newOptions) {
    // @ts-ignore
    var target = {};
    /*eslint-disable no-restricted-syntax*/
    for (var key in existingOptions) {
      target[key] = existingOptions[key];
    }
    for (var key in newOptions) {
      target[key] = newOptions[key];
    }
    /*eslint-enable*/
    return target;
  }
  // utils
  var Cache = /** @class*/
  (function () {
    function Cache(options) {
      this.keys = [];
      this.values = [];
      this.options = options;
      var isMatchingKeyFunction = typeof options.isMatchingKey === 'function';
      if (isMatchingKeyFunction) {
        this.getKeyIndex = this._getKeyIndexFromMatchingKey;
      } else if (options.maxSize > 1) {
        this.getKeyIndex = this._getKeyIndexForMany;
      } else {
        this.getKeyIndex = this._getKeyIndexForSingle;
      }
      this.canTransformKey = typeof options.transformKey === 'function';
      this.shouldCloneArguments = this.canTransformKey || isMatchingKeyFunction;
      this.shouldUpdateOnAdd = typeof options.onCacheAdd === 'function';
      this.shouldUpdateOnChange = typeof options.onCacheChange === 'function';
      this.shouldUpdateOnHit = typeof options.onCacheHit === 'function';
    }
    Object.defineProperty(Cache.prototype, "size", {
      get: function () {
        return this.keys.length;
      },
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(Cache.prototype, "snapshot", {
      get: function () {
        return {
          keys: cloneArray(this.keys),
          size: this.size,
          values: cloneArray(this.values)
        };
      },
      enumerable: true,
      configurable: true
    });
    /**
    * @function _getKeyIndexFromMatchingKey
    *
    * @description
    * gets the matching key index when a custom key matcher is used
    *
    * @param keyToMatch the key to match
    * @returns the index of the matching key, or -1
    */
    Cache.prototype._getKeyIndexFromMatchingKey = function (keyToMatch) {
      var _a = this.options, isMatchingKey = _a.isMatchingKey, maxSize = _a.maxSize;
      var keys = this.keys;
      var keysLength = keys.length;
      if (!keysLength) {
        return -1;
      }
      if (isMatchingKey(keys[0], keyToMatch)) {
        return 0;
      }
      if (maxSize > 1) {
        for (var index = 1; index < keysLength; index++) {
          if (isMatchingKey(keys[index], keyToMatch)) {
            return index;
          }
        }
      }
      return -1;
    };
    /**
    * @function _getKeyIndexForMany
    *
    * @description
    * gets the matching key index when multiple keys are used
    *
    * @param keyToMatch the key to match
    * @returns the index of the matching key, or -1
    */
    Cache.prototype._getKeyIndexForMany = function (keyToMatch) {
      var isEqual = this.options.isEqual;
      var keys = this.keys;
      var keysLength = keys.length;
      if (!keysLength) {
        return -1;
      }
      if (keysLength === 1) {
        return this._getKeyIndexForSingle(keyToMatch);
      }
      var keyLength = keyToMatch.length;
      var existingKey;
      var argIndex;
      if (keyLength > 1) {
        for (var index = 0; index < keysLength; index++) {
          existingKey = keys[index];
          if (existingKey.length === keyLength) {
            argIndex = 0;
            for (; argIndex < keyLength; argIndex++) {
              if (!isEqual(existingKey[argIndex], keyToMatch[argIndex])) {
                break;
              }
            }
            if (argIndex === keyLength) {
              return index;
            }
          }
        }
      } else {
        for (var index = 0; index < keysLength; index++) {
          existingKey = keys[index];
          if (existingKey.length === keyLength && isEqual(existingKey[0], keyToMatch[0])) {
            return index;
          }
        }
      }
      return -1;
    };
    /**
    * @function _getKeyIndexForSingle
    *
    * @description
    * gets the matching key index when a single key is used
    *
    * @param keyToMatch the key to match
    * @returns the index of the matching key, or -1
    */
    Cache.prototype._getKeyIndexForSingle = function (keyToMatch) {
      var keys = this.keys;
      if (!keys.length) {
        return -1;
      }
      var existingKey = keys[0];
      var length = existingKey.length;
      if (keyToMatch.length !== length) {
        return -1;
      }
      var isEqual = this.options.isEqual;
      if (length > 1) {
        for (var index = 0; index < length; index++) {
          if (!isEqual(existingKey[index], keyToMatch[index])) {
            return -1;
          }
        }
        return 0;
      }
      return isEqual(existingKey[0], keyToMatch[0]) ? 0 : -1;
    };
    /**
    * @function orderByLru
    *
    * @description
    * order the array based on a Least-Recently-Used basis
    *
    * @param key the new key to move to the front
    * @param value the new value to move to the front
    * @param startingIndex the index of the item to move to the front
    */
    Cache.prototype.orderByLru = function (key, value, startingIndex) {
      var keys = this.keys;
      var values = this.values;
      var currentLength = keys.length;
      var index = startingIndex;
      while (index--) {
        keys[index + 1] = keys[index];
        values[index + 1] = values[index];
      }
      keys[0] = key;
      values[0] = value;
      var maxSize = this.options.maxSize;
      if (currentLength === maxSize && startingIndex === currentLength) {
        keys.pop();
        values.pop();
      } else if (startingIndex >= maxSize) {
        // eslint-disable-next-line no-multi-assign
        keys.length = values.length = maxSize;
      }
    };
    /**
    * @function updateAsyncCache
    *
    * @description
    * update the promise method to auto-remove from cache if rejected, and
    * if resolved then fire cache hit / changed
    *
    * @param memoized the memoized function
    */
    Cache.prototype.updateAsyncCache = function (memoized) {
      var _this = this;
      var _a = this.options, onCacheChange = _a.onCacheChange, onCacheHit = _a.onCacheHit;
      var firstKey = this.keys[0];
      var firstValue = this.values[0];
      this.values[0] = firstValue.then(function (value) {
        if (_this.shouldUpdateOnHit) {
          onCacheHit(_this, _this.options, memoized);
        }
        if (_this.shouldUpdateOnChange) {
          onCacheChange(_this, _this.options, memoized);
        }
        return value;
      }, function (error) {
        var keyIndex = _this.getKeyIndex(firstKey);
        if (keyIndex !== -1) {
          _this.keys.splice(keyIndex, 1);
          _this.values.splice(keyIndex, 1);
        }
        throw error;
      });
    };
    return Cache;
  })();
  // cache
  function createMemoizedFunction(fn, options) {
    if (options === void 0) {
      options = {};
    }
    if (isMemoized(fn)) {
      return createMemoizedFunction(fn.fn, mergeOptions(fn.options, options));
    }
    if (typeof fn !== 'function') {
      throw new TypeError('You must pass a function to `memoize`.');
    }
    var _a = options.isEqual, isEqual = _a === void 0 ? isSameValueZero : _a, isMatchingKey = options.isMatchingKey, _b = options.isPromise, isPromise = _b === void 0 ? false : _b, _c = options.maxSize, maxSize = _c === void 0 ? 1 : _c, onCacheAdd = options.onCacheAdd, onCacheChange = options.onCacheChange, onCacheHit = options.onCacheHit, transformKey = options.transformKey;
    var normalizedOptions = mergeOptions({
      isEqual: isEqual,
      isMatchingKey: isMatchingKey,
      isPromise: isPromise,
      maxSize: maxSize,
      onCacheAdd: onCacheAdd,
      onCacheChange: onCacheChange,
      onCacheHit: onCacheHit,
      transformKey: transformKey
    }, getCustomOptions(options));
    var cache = new Cache(normalizedOptions);
    var keys = cache.keys, values = cache.values, canTransformKey = cache.canTransformKey, shouldCloneArguments = cache.shouldCloneArguments, shouldUpdateOnAdd = cache.shouldUpdateOnAdd, shouldUpdateOnChange = cache.shouldUpdateOnChange, shouldUpdateOnHit = cache.shouldUpdateOnHit;
    // @ts-ignore
    var memoized = function memoized() {
      // @ts-ignore
      var key = shouldCloneArguments ? cloneArray(arguments) : arguments;
      if (canTransformKey) {
        key = transformKey(key);
      }
      var keyIndex = keys.length ? cache.getKeyIndex(key) : -1;
      if (keyIndex !== -1) {
        if (shouldUpdateOnHit) {
          onCacheHit(cache, normalizedOptions, memoized);
        }
        if (keyIndex) {
          cache.orderByLru(keys[keyIndex], values[keyIndex], keyIndex);
          if (shouldUpdateOnChange) {
            onCacheChange(cache, normalizedOptions, memoized);
          }
        }
      } else {
        var newValue = fn.apply(this, arguments);
        var newKey = shouldCloneArguments ? key : cloneArray(arguments);
        cache.orderByLru(newKey, newValue, keys.length);
        if (isPromise) {
          cache.updateAsyncCache(memoized);
        }
        if (shouldUpdateOnAdd) {
          onCacheAdd(cache, normalizedOptions, memoized);
        }
        if (shouldUpdateOnChange) {
          onCacheChange(cache, normalizedOptions, memoized);
        }
      }
      return values[0];
    };
    memoized.cache = cache;
    memoized.fn = fn;
    memoized.isMemoized = true;
    memoized.options = normalizedOptions;
    return memoized;
  }
  return createMemoizedFunction;
});

},{}],"1eujH":[function(require,module,exports) {
'use strict';

const converters = {
	days: value => value * 864e5,
	hours: value => value * 36e5,
	minutes: value => value * 6e4,
	seconds: value => value * 1e3,
	milliseconds: value => value,
	microseconds: value => value / 1e3,
	nanoseconds: value => value / 1e6
};

const toMilliseconds = object => Object.entries(object).reduce((milliseconds, [key, value]) => {
	if (typeof value !== 'number') {
		throw new TypeError(`Expected a \`number\` for key \`${key}\`, got \`${value}\` (${typeof value})`);
	}

	if (!converters[key]) {
		throw new Error('Unsupported time key');
	}

	return milliseconds + converters[key](value);
}, 0);

module.exports = toMilliseconds;
// TODO: remove this for next major version
module.exports.default = toMilliseconds;

},{}]},["1RQCG"], "1RQCG", "parcelRequire427e")

