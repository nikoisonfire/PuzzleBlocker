// modules are defined as an array
// [ module function, map of requires ]
//
// map of requires is short require name -> numeric require
//
// anything defined in a previous bundle is accessed via the
// orig method which is the require for previous bundles

(function(modules, entry, mainEntry, parcelRequireName, globalName) {
  /* eslint-disable no-undef */
  var globalObject =
    typeof globalThis !== 'undefined'
      ? globalThis
      : typeof self !== 'undefined'
      ? self
      : typeof window !== 'undefined'
      ? window
      : typeof global !== 'undefined'
      ? global
      : {};
  /* eslint-enable no-undef */

  // Save the require from previous bundle to this closure if any
  var previousRequire =
    typeof globalObject[parcelRequireName] === 'function' &&
    globalObject[parcelRequireName];

  var cache = previousRequire.cache || {};
  // Do not use `require` to prevent Webpack from trying to bundle this call
  var nodeRequire =
    typeof module !== 'undefined' &&
    typeof module.require === 'function' &&
    module.require.bind(module);

  function newRequire(name, jumped) {
    if (!cache[name]) {
      if (!modules[name]) {
        // if we cannot find the module within our internal map or
        // cache jump to the current global require ie. the last bundle
        // that was added to the page.
        var currentRequire =
          typeof globalObject[parcelRequireName] === 'function' &&
          globalObject[parcelRequireName];
        if (!jumped && currentRequire) {
          return currentRequire(name, true);
        }

        // If there are other bundles on this page the require from the
        // previous one is saved to 'previousRequire'. Repeat this as
        // many times as there are bundles until the module is found or
        // we exhaust the require chain.
        if (previousRequire) {
          return previousRequire(name, true);
        }

        // Try the node require function if it exists.
        if (nodeRequire && typeof name === 'string') {
          return nodeRequire(name);
        }

        var err = new Error("Cannot find module '" + name + "'");
        err.code = 'MODULE_NOT_FOUND';
        throw err;
      }

      localRequire.resolve = resolve;
      localRequire.cache = {};

      var module = (cache[name] = new newRequire.Module(name));

      modules[name][0].call(
        module.exports,
        localRequire,
        module,
        module.exports,
        this
      );
    }

    return cache[name].exports;

    function localRequire(x) {
      return newRequire(localRequire.resolve(x));
    }

    function resolve(x) {
      return modules[name][1][x] || x;
    }
  }

  function Module(moduleName) {
    this.id = moduleName;
    this.bundle = newRequire;
    this.exports = {};
  }

  newRequire.isParcelRequire = true;
  newRequire.Module = Module;
  newRequire.modules = modules;
  newRequire.cache = cache;
  newRequire.parent = previousRequire;
  newRequire.register = function(id, exports) {
    modules[id] = [
      function(require, module) {
        module.exports = exports;
      },
      {},
    ];
  };

  Object.defineProperty(newRequire, 'root', {
    get: function() {
      return globalObject[parcelRequireName];
    },
  });

  globalObject[parcelRequireName] = newRequire;

  for (var i = 0; i < entry.length; i++) {
    newRequire(entry[i]);
  }

  if (mainEntry) {
    // Expose entry point to Node, AMD or browser globals
    // Based on https://github.com/ForbesLindesay/umd/blob/master/template.js
    var mainExports = newRequire(mainEntry);

    // CommonJS
    if (typeof exports === 'object' && typeof module !== 'undefined') {
      module.exports = mainExports;

      // RequireJS
    } else if (typeof define === 'function' && define.amd) {
      define(function() {
        return mainExports;
      });

      // <script>
    } else if (globalName) {
      this[globalName] = mainExports;
    }
  }
})({"FsXfO":[function(require,module,exports) {
var _webextensionPolyfill = require('webextension-polyfill');
var _parcelHelpers = require("@parcel/transformer-js/lib/esmodule-helpers.js");
var _webextensionPolyfillDefault = _parcelHelpers.interopDefault(_webextensionPolyfill);
var _tangramDirections = require("./tangram/directions");
var _tangramHelpers = require("./tangram/helpers");
var _tangramTangram = require("./tangram/tangram");
var _tangramIntadjoinsqrt = require("./tangram/intadjoinsqrt2");
var _tangramPoint = require("./tangram/point");
var _tangramTan = require("./tangram/tan");
var _tangramLineSegement = require("./tangram/lineSegement");
var _tangramGenerator = require("./tangram/generator");
var _optionsOptionsStorage = require("./options/options-storage");
var _optionsOptionsStorageDefault = _parcelHelpers.interopDefault(_optionsOptionsStorage);
var _urlLogoPng = require('url:./logo.png');
var _urlLogoPngDefault = _parcelHelpers.interopDefault(_urlLogoPng);
var _WebWebExtAsk4rating1DistTsc = require('../../../_Web/web-ext-ask4rating-1/dist/tsc/');
var _WebWebExtAsk4rating1DistTscDefault = _parcelHelpers.interopDefault(_WebWebExtAsk4rating1DistTsc);
/*Settings/letiables for generating yea*/
let numTangrams = 1000;
let generated = [];
let chosen;
let firstGeneration = true;
/*letiables used during solving*/
let currentTan = -1;
let move = false;
let mouseOffset = new _tangramPoint.Point(new _tangramIntadjoinsqrt.IntAdjoinSqrt2(0, 0), new _tangramIntadjoinsqrt.IntAdjoinSqrt2(0, 0));
let lastMouse = new _tangramPoint.Point(new _tangramIntadjoinsqrt.IntAdjoinSqrt2(0, 0), new _tangramIntadjoinsqrt.IntAdjoinSqrt2(0, 0));
let lastAngle = 0;
let hints = [0, 1, 2, 3, 4, 5, 6];
let numHints = 0;
let snapRange = 1.2;
let snapped = [false, false, false, false, false, false, false];
/*letiables for statistics*/
let timer;
let minutes;
let seconds;
let rotations;
let translations;
let user;
let gameOutline;
/*Game logic - compute mouse coordinates*/
let getMouseCoordinates = function (event) {
  let svg = document.getElementById("game");
  let pt = svg.createSVGPoint();
  if (('touches' in event)) {
    let touch = event.changedTouches[0];
    pt.x = touch.clientX;
    pt.y = touch.clientY;
  } else {
    pt.x = event.clientX;
    pt.y = event.clientY;
  }
  /*Transform coordinates from pixels to coordinates inside the svg-element*/
  let globalPoint = pt.matrixTransform(svg.getScreenCTM().inverse());
  return new _tangramPoint.Point(new _tangramIntadjoinsqrt.IntAdjoinSqrt2(globalPoint.x, 0), new _tangramIntadjoinsqrt.IntAdjoinSqrt2(globalPoint.y, 0));
};
let resetPieces = function () {
  let anchorBT1_G = new _tangramPoint.Point(new _tangramIntadjoinsqrt.IntAdjoinSqrt2(72, -6), new _tangramIntadjoinsqrt.IntAdjoinSqrt2(18.9, -7.5));
  let bigTriangle1_G = new _tangramTan.Tan(0, anchorBT1_G, 0);
  let anchorBT2_G = new _tangramPoint.Point(new _tangramIntadjoinsqrt.IntAdjoinSqrt2(78, 6), new _tangramIntadjoinsqrt.IntAdjoinSqrt2(18.9, 4.5));
  let bigTriangle2_G = new _tangramTan.Tan(0, anchorBT2_G, 4);
  let anchorM_G = new _tangramPoint.Point(new _tangramIntadjoinsqrt.IntAdjoinSqrt2(72, -6), new _tangramIntadjoinsqrt.IntAdjoinSqrt2(29.1, 7.5));
  let mediumTriangle_G = new _tangramTan.Tan(1, anchorM_G, 0);
  let anchorST1_G = new _tangramPoint.Point(new _tangramIntadjoinsqrt.IntAdjoinSqrt2(72, -6), new _tangramIntadjoinsqrt.IntAdjoinSqrt2(26.1, 1.5));
  let smallTriangle1_G = new _tangramTan.Tan(2, anchorST1_G, 0);
  let anchorST2_G = new _tangramPoint.Point(new _tangramIntadjoinsqrt.IntAdjoinSqrt2(75, 0), new _tangramIntadjoinsqrt.IntAdjoinSqrt2(26.1, 7.5));
  let smallTriangle2_G = new _tangramTan.Tan(2, anchorST2_G, 4);
  let anchorS_G = new _tangramPoint.Point(new _tangramIntadjoinsqrt.IntAdjoinSqrt2(78, 6), new _tangramIntadjoinsqrt.IntAdjoinSqrt2(26.1, 7.5));
  let square_G = new _tangramTan.Tan(3, anchorS_G, 4);
  let anchorP_G = new _tangramPoint.Point(new _tangramIntadjoinsqrt.IntAdjoinSqrt2(60, 6), new _tangramIntadjoinsqrt.IntAdjoinSqrt2(41.1, 7.5));
  let parallelogram_G = new _tangramTan.Tan(5, anchorP_G, 0);
  gameOutline = [bigTriangle1_G, bigTriangle2_G, mediumTriangle_G, smallTriangle1_G, smallTriangle2_G, square_G, parallelogram_G];
};
/*Game logic - Show which action will be used if dragging is used*/
let changeIconVisibility = function (showMove, showRotate) {
  move = !!showMove;
};
/*Game logic - Set the action that will be used if dragging is used based on the
* proximity of the mouse to the vertices of the current tan*/
let showAction = function (event) {
  /*If tan is already selected and we are not currently handling a touch event
  * nothing has to be done*/
  if (currentTan != -1 && !(('touches' in event))) return;
  let target = event.currentTarget;
  let tanIndex = parseInt(target.id[target.id.length - 1]);
  let mouse = getMouseCoordinates(event);
  let points = gameOutline[tanIndex].getPoints();
  let rotate = false;
  /*Smaller rotate range for "small" tans*/
  let rotateRange = tanIndex > 2 ? 1.8 : 2.7;
  /*Action if rotate if the mouse is close to one the vertices of the tan*/
  for (let pointId = 0; pointId < points.length; pointId++) {
    if (Math.abs(points[pointId].toFloatX() - mouse.toFloatX()) < rotateRange && Math.abs(points[pointId].toFloatY() - mouse.toFloatY()) < rotateRange) {
      rotate = true;
      break;
    }
  }
  if (rotate) {
    changeIconVisibility(false, true);
  } else {
    changeIconVisibility(true, false);
  }
};
/*Game logic - Check if the tangram has already been solved*/
let checkSolved = function () {
  let tangramFromPieces = new _tangramTangram.Tangram(gameOutline);
  /*Outline of the pieces and the chosen tangram have different length or the
  * outline is undefined -> not solved*/
  if (typeof tangramFromPieces.outline === 'undefined' || generated[chosen].outline.length != tangramFromPieces.outline.length) {
    return false;
  }
  /*Check if the outlines are the same, when the tangram has been solved, the
  * outlines have to match exactly due to snapping*/
  let solved = true;
  sendMessage();
  for (let outlineId = 0; outlineId < generated[chosen].outline.length; outlineId++) {
    solved = solved && _tangramHelpers.arrayEq(generated[chosen].outline[outlineId], tangramFromPieces.outline[outlineId], _tangramPoint.Point.comparePoints);
  }
  if (!solved) {
    return;
  }
  /*Also check if any of the segments intersect*/
  let tanSegments = _tangramTan.computeSegments(_tangramTan.getAllPoints(gameOutline), gameOutline);
  for (let segmentId = 0; segmentId < tanSegments.length; segmentId++) {
    for (let otherSegmentsId = segmentId + 1; otherSegmentsId < tanSegments.length; otherSegmentsId++) {
      if (tanSegments[segmentId].intersects(tanSegments[otherSegmentsId])) {
        return false;
      }
    }
  }
  /*Color the tan pieces and display some statistics about the game play*/
  stopWatch();
  let tangramPieces = document.getElementsByClassName("tan");
  for (let tanIndex = 0; tanIndex < tangramPieces.length; tanIndex++) {
    tangramPieces[tanIndex].setAttributeNS(null, "fill", "#3299BB");
    tangramPieces[tanIndex].setAttributeNS(null, "opacity", "1.0");
  }
  let watch = document.getElementById("watch");
  watch.textContent = "";
  let line0 = document.createElementNS("http://www.w3.org/2000/svg", "tspan");
  line0.setAttributeNS(null, 'x', '66');
  line0.setAttributeNS(null, 'y', '24');
  line0.textContent = "You solved it";
  watch.appendChild(line0);
  let line1 = document.createElementNS("http://www.w3.org/2000/svg", "tspan");
  line1.setAttributeNS(null, 'x', '66');
  line1.setAttributeNS(null, 'y', '27');
  line1.textContent = "in \uf017  " + (minutes ? minutes > 9 ? minutes : "0" + minutes : "00") + ":" + (seconds > 9 ? seconds : "0" + seconds) + " with";
  watch.appendChild(line1);
  let line2 = document.createElementNS("http://www.w3.org/2000/svg", "tspan");
  line2.setAttributeNS(null, 'x', '66');
  line2.setAttributeNS(null, 'y', '30');
  line2.textContent = "\uf047  " + translations + " and \uf01e  " + rotations;
  watch.appendChild(line2);
};
/*Game logic - Sets every piece to the solution*/
let setToSol = function () {
  for (let tanIndex = 0; tanIndex < 7; tanIndex++) {
    gameOutline[tanIndex] = generated[chosen].tans[tanIndex].dup();
    updateTanPiece(tanIndex);
  }
  sendMessage();
};
/*Game logic - Display the outline of one tan that has not been displayed before*/
let hint = function () {
  /*Give hints in random order*/
  if (numHints === 0) {
    hints = _tangramHelpers.shuffleArray(hints);
  }
  if (numHints > 6) {
    return;
  }
  /*Display outline*/
  let shape = document.createElementNS("http://www.w3.org/2000/svg", "polygon");
  shape.setAttributeNS(null, "points", generated[chosen].tans[hints[numHints]].toSVG());
  shape.setAttributeNS(null, "fill", 'none');
  shape.setAttributeNS(null, "stroke", "#00FFFF");
  shape.setAttributeNS(null, "stroke-width", "0.2");
  shape.setAttributeNS(null, "class", "hint");
  document.getElementById("game").appendChild(shape);
  numHints++;
};
/*Game logic - After a tan has been placed, snap to either other tans or the
* outline of the tangram to be solved*/
let snapToClosePoints = function () {
  if (currentTan === -1) {
    return;
  }
  let tanPoints = gameOutline[currentTan].getPoints();
  let currentTanPoints;
  let snap = false;
  /*Snap to the first point of a different tan that falls into the snapRange*/
  for (let tanId = 0; tanId < 7; tanId++) {
    if (tanId === currentTan) continue;
    currentTanPoints = gameOutline[tanId].getPoints();
    for (let pointsId = 0; pointsId < tanPoints.length; pointsId++) {
      for (let currentPointsId = 0; currentPointsId < currentTanPoints.length; currentPointsId++) {
        if (_tangramPoint.Point.closePoint(tanPoints[pointsId], currentTanPoints[currentPointsId], snapRange)) {
          /*The tan that is being snapped to has not been snapped to the outline yet
          * (therefore does not have exact coordinates yet) -> simply compute
          * difference vector and add it to the anchor*/
          if (!snapped[tanId]) {
            let direction = currentTanPoints[currentPointsId].dup().subtract(tanPoints[pointsId]);
            gameOutline[currentTan].anchor.add(direction);
          } else {
            /*The tan that is being snapped to has already been snapped
            * to the outline -> update the anchor to that it has exact
            * coordinates as well (involves some direction computation
            * if the points that snap to each other are not the anchors*/
            gameOutline[currentTan].anchor = currentPointsId === 0 ? gameOutline[tanId].anchor.dup() : gameOutline[tanId].anchor.dup().add(_tangramDirections.Directions[gameOutline[tanId].tanType][gameOutline[tanId].orientation][currentPointsId - 1]);
            if (pointsId != 0) {
              gameOutline[currentTan].anchor.subtract(_tangramDirections.Directions[gameOutline[currentTan].tanType][gameOutline[currentTan].orientation][pointsId - 1]);
            }
            snapped[currentTan] = true;
          }
          snap = true;
          break;
        }
      }
      if (snap) {
        break;
      }
    }
    if (snap) {
      break;
    }
  }
  /*Places tan has not snapped to any other tan -> try snapping to the
  * outline in the same manner*/
  if (!snap) {
    for (let pointsId = 0; pointsId < tanPoints.length; pointsId++) {
      for (let outlineId = 0; outlineId < generated[chosen].outline.length; outlineId++) {
        for (let currentPointsId = 0; currentPointsId < generated[chosen].outline[outlineId].length; currentPointsId++) {
          if (_tangramPoint.Point.closePoint(tanPoints[pointsId], generated[chosen].outline[outlineId][currentPointsId], snapRange)) {
            /*let direction = generated[chosen].outline[outlineId][currentPointsId].dup().subtract(tanPoints[pointsId]);
            gameOutline[currentTan].anchor.add(direction);*/
            gameOutline[currentTan].anchor = generated[chosen].outline[outlineId][currentPointsId].dup();
            if (pointsId != 0) {
              gameOutline[currentTan].anchor.subtract(_tangramDirections.Directions[gameOutline[currentTan].tanType][gameOutline[currentTan].orientation][pointsId - 1]);
            }
            snap = true;
            /*The placed tan is now snapped to the outline*/
            snapped[currentTan] = true;
            break;
          }
        }
      }
      if (snap) {
        break;
      }
    }
  }
  updateTanPiece(currentTan);
};
/*Game logic - After a tan has been rotated, snap to the closest 45 degree rotation*/
let snapToClosestRotation = function (mouse) {
  if (currentTan === -1) {
    return;
  }
  let tanCenter = gameOutline[currentTan].center();
  /*Difference between angle before rotation started and now*/
  let currentAngle = _tangramHelpers.clipAngle(lastAngle - new _tangramLineSegement.LineSegment(tanCenter, gameOutline[currentTan].anchor).angleTo(new _tangramLineSegement.LineSegment(tanCenter, mouse)));
  currentAngle = Math.round(currentAngle / 45);
  gameOutline[currentTan].orientation = (gameOutline[currentTan].orientation + currentAngle) % _tangramDirections.numOrientations;
  gameOutline[currentTan].anchor.subtract(tanCenter).rotate(45 * currentAngle).add(tanCenter);
  rotations++;
  updateTanPiece(currentTan);
};
/*Game logic - Update the svg of the tan with the given index, so that the svg
* matches the internal representation (again)*/
let updateTanPiece = function (tanIndex) {
  if (tanIndex < 0) {
    return;
  }
  let tanId = "piece" + tanIndex;
  document.getElementById(tanId).setAttribute("points", gameOutline[tanIndex].toSVG());
};
/*Game logic - Update the svg of the tan with the given index during rotation,
* since angles other than multiples of 45 degrees occur, the internal tan
* representation with just anchor and orientation can not be used and the points
* have to be calculated from the points at the last orientation which are then
* rotated*/
let updateTanPieceRotation = function (tanIndex, angle) {
  if (tanIndex < 0) {
    return;
  }
  let tanId = "piece" + tanIndex;
  let tanCenter = gameOutline[tanIndex].center();
  let tan = document.getElementById(tanId);
  let points = gameOutline[tanIndex].getPoints();
  let pointsString = "";
  for (let pointId = 0; pointId < points.length; pointId++) {
    points[pointId].subtract(tanCenter).rotate(angle).add(tanCenter);
    pointsString += points[pointId].toFloatX() + ", " + points[pointId].toFloatY() + " ";
  }
  tan.setAttributeNS(null, "points", pointsString);
};
/*Game logic - Increase the orientation of the tan for which the event fired, if
* the mouse coordinates have changed only very little since the selection (mousedown)*/
let rotateTan = function (event) {
  let target = event.currentTarget;
  let tanIndex = parseInt(target.id[target.id.length - 1]);
  // console.log("clicked: " + tanIndex);
  let mouse = getMouseCoordinates(event);
  let mouseMove = lastMouse.dup().subtract(mouse);
  if (Math.abs(mouseMove.toFloatX()) < 0.25 && Math.abs(mouseMove.toFloatY()) < 0.25) {
    /*console.log("rotated: " + tanIndex);*/
    gameOutline[tanIndex].orientation = (gameOutline[tanIndex].orientation + 1) % _tangramDirections.numOrientations;
    gameOutline[tanIndex].anchor.subtract(mouse).rotate(45).add(mouse);
    updateTanPiece(tanIndex);
    rotations++;
  }
};
/*Game logic - Select a tan as the current one, which is then moved/rotated if
* the mouse moves (mousedown), update all "last states" in this function*/
let selectTan = function (event) {
  let target = event.currentTarget;
  let tanIndex = parseInt(target.id[target.id.length - 1]);
  /*Show that this tan is active by "removing" border*/
  document.getElementById("piece" + tanIndex).setAttributeNS(null, "stroke-width", "0.22");
  // document.getElementById("piece" + tanIndex).setAttributeNS(null, "opacity", "0.7");
  // console.log("selected: " + tanIndex);
  currentTan = tanIndex;
  let mouse = getMouseCoordinates(event);
  lastMouse = mouse.dup();
  let tanCenter = gameOutline[currentTan].center();
  lastAngle = new _tangramLineSegement.LineSegment(tanCenter, gameOutline[currentTan].anchor).angleTo(new _tangramLineSegement.LineSegment(tanCenter, lastMouse));
  mouseOffset = mouse.subtract(gameOutline[tanIndex].anchor);
};
/*Game logic - Deselect a tan when finishing a move/rotate action, snapping to
* rotations/points is handled here*/
let deselectTan = function (event) {
  if (!move) {
    snapToClosestRotation(getMouseCoordinates(event));
  } else {
    translations += 1;
  }
  if (currentTan !== -1) {
    snapped[currentTan] = false;
    /*Show that tan is not active anymore*/
    document.getElementById("piece" + currentTan).setAttributeNS(null, "stroke-width", "0.1");
  }
  snapToClosePoints();
  currentTan = -1;
  mouseOffset = new _tangramPoint.Point(new _tangramIntadjoinsqrt.IntAdjoinSqrt2(0, 0), new _tangramIntadjoinsqrt.IntAdjoinSqrt2(0, 0));
  checkSolved();
  /*Do not fire deselect on parent element as well*/
  event.stopPropagation();
};
/*Game logic - move or rotate tan (mousemove)*/
let moveTan = function (event) {
  let mouse = getMouseCoordinates(event);
  if (currentTan > -1) {
    if (move) {
      gameOutline[currentTan].anchor = mouse.subtract(mouseOffset);
      updateTanPiece(currentTan);
    } else {
      let tanCenter = gameOutline[currentTan].center();
      let currentAngle = _tangramHelpers.clipAngle(lastAngle - new _tangramLineSegement.LineSegment(tanCenter, gameOutline[currentTan].anchor).angleTo(new _tangramLineSegement.LineSegment(tanCenter, mouse)));
      updateTanPieceRotation(currentTan, currentAngle);
    }
  }
};
/*Watch - stop watch -> cancel callback*/
let stopWatch = function () {
  clearTimeout(timer);
};
/*Watch - Increase seconds and update watch text*/
let updateWatch = function (hintTime, solTime) {
  seconds++;
  if (seconds >= 60) {
    seconds = 0;
    minutes++;
  }
  let watch = document.getElementById("watch");
  watch.textContent = "\uf017  " + (minutes ? minutes > 9 ? minutes : "0" + minutes : "00") + ":" + (seconds > 9 ? seconds : "0" + seconds);
  const totalTime = minutes * 60 + seconds;
  if (totalTime >= hintTime && hintTime > 0) {
    hint();
    hintTime = 0;
  }
  if (totalTime >= solTime && solTime > 0) {
    setToSol();
    stopWatch();
    return;
  }
  /*Update watch again in one second*/
  timer = setTimeout(() => updateWatch(hintTime, solTime), 1000);
};
/*Watch - Start watch -> set seconds and minutes to 0*/
let startWatch = async function () {
  let watch = document.getElementById("watch");
  watch.textContent = "\uf017  " + "00:00";
  minutes = 0;
  seconds = 0;
  const options = await _optionsOptionsStorageDefault.default.getAll();
  const hintTime = options.hintTime;
  const solTime = options.solutionTime;
  /*Update watch again in one second*/
  timer = setTimeout(() => updateWatch(hintTime, solTime), 1000);
};
/*Game logic - Show the tan pieces and add touch and mouse event listeners to
* the tans*/
let addTangramPieces = function () {
  for (let tanIndex = 0; tanIndex < gameOutline.length; tanIndex++) {
    let shape = document.createElementNS("http://www.w3.org/2000/svg", "polygon");
    let id = "piece" + tanIndex;
    shape.setAttributeNS(null, "id", id);
    shape.setAttributeNS(null, "class", "tan");
    shape.setAttributeNS(null, "points", gameOutline[tanIndex].toSVG());
    shape.setAttributeNS(null, "fill", '#FF9900');
    shape.setAttributeNS(null, "opacity", "0.8");
    shape.setAttributeNS(null, "stroke", "#000000");
    shape.setAttributeNS(null, "stroke-width", "0.1");
    document.getElementById("game").appendChild(shape);
  }
  let tangramPieces = document.getElementsByClassName("tan");
  for (let tanIndex = 0; tanIndex < tangramPieces.length; tanIndex++) {
    tangramPieces[tanIndex].addEventListener('click', rotateTan);
    tangramPieces[tanIndex].addEventListener('mousedown', selectTan);
    tangramPieces[tanIndex].addEventListener('mouseup', deselectTan);
    tangramPieces[tanIndex].addEventListener('mouseover', showAction);
    tangramPieces[tanIndex].addEventListener('mousemove', showAction);
    tangramPieces[tanIndex].addEventListener('mouseout', function () {
      if (currentTan === -1) changeIconVisibility(false, false);
    });
    tangramPieces[tanIndex].addEventListener('touchstart', function (event) {
      selectTan(event);
      showAction(event);
    });
    tangramPieces[tanIndex].addEventListener('touchend', function (event) {
      // event.preventDefault();
      deselectTan(event);
    });
    tangramPieces[tanIndex].addEventListener('touchmove', function (event) {
      event.preventDefault();
      moveTan(event);
    });
  }
  document.getElementById("game").addEventListener('mousemove', moveTan);
  document.getElementById("game").addEventListener('mouseup', deselectTan);
  /*Prevent other touch events on game (that are not inside a tan*/
  document.getElementById("game").addEventListener('touchmove', function (event) {
    event.preventDefault();
  });
};
/*Game logic - Add icons for showing current action and watch*/
let addIcons = function () {
  let moveIcon = document.createElementNS("http://www.w3.org/2000/svg", "text");
  moveIcon.setAttributeNS(null, "x", "69");
  moveIcon.setAttributeNS(null, "y", "57.9");
  moveIcon.setAttributeNS(null, "font-size", "2.7");
  moveIcon.setAttributeNS(null, "fill", "#E9E9E9");
  moveIcon.setAttributeNS(null, "id", "move");
  moveIcon.setAttributeNS(null, "display", "none");
  moveIcon.textContent = "\uf047";
  document.getElementById("game").appendChild(moveIcon);
  let rotateIcon = document.createElementNS("http://www.w3.org/2000/svg", "text");
  rotateIcon.setAttributeNS(null, "x", "69");
  rotateIcon.setAttributeNS(null, "y", "57.9");
  rotateIcon.setAttributeNS(null, "font-size", "2.7");
  rotateIcon.setAttributeNS(null, "fill", "#E9E9E9");
  rotateIcon.setAttributeNS(null, "id", "rotate");
  rotateIcon.setAttributeNS(null, "display", "none");
  rotateIcon.textContent = "\uf01e";
  document.getElementById("game").appendChild(rotateIcon);
  let watch = document.createElementNS("http://www.w3.org/2000/svg", "text");
  watch.setAttributeNS(null, "x", "3");
  watch.setAttributeNS(null, "y", "57.9");
  watch.setAttributeNS(null, "fill", "#f9f9f9");
  watch.setAttributeNS(null, "id", "watch");
  watch.setAttributeNS(null, "font-size", "2.7");
  watch.textContent = "\uf017  " + "00:00";
  document.getElementById("game").appendChild(watch);
};
/*Game logic - Add button for flipping parallelogram*/
let addFlipButton = function () {
  let button = document.createElementNS("http://www.w3.org/2000/svg", "g");
  button.setAttributeNS(null, "class", "flip");
  button.setAttributeNS(null, "transform", "translate (" + 70.5 + ", " + 52.5 + ")" + "scale(" + 0.3 + "," + 0.3 + ")");
  let background = document.createElementNS("http://www.w3.org/2000/svg", "rect");
  background.setAttributeNS(null, "x", "10.5");
  background.setAttributeNS(null, "y", "10.5");
  background.setAttributeNS(null, "width", "45");
  background.setAttributeNS(null, "height", "9");
  background.setAttributeNS(null, "rx", "3.0");
  background.setAttributeNS(null, "ry", "3.0");
  background.setAttributeNS(null, "fill", '#E9E9E9');
  button.appendChild(background);
  let arrow = document.createElementNS("http://www.w3.org/2000/svg", "polygon");
  arrow.setAttributeNS(null, "points", "30,15 31.5,13.5, 31.5,14.4, 34.5,14.4, " + "34.5,13.5, 36,15, 34.5,16.5, 34.5,15.6 31.5,15.6 31.5,16.5");
  arrow.setAttributeNS(null, "fill", '#BCBCBC');
  button.appendChild(arrow);
  let anchorL = new _tangramPoint.Point(new _tangramIntadjoinsqrt.IntAdjoinSqrt2(12, 0), new _tangramIntadjoinsqrt.IntAdjoinSqrt2(18, 0));
  let parallelogramL = new _tangramTan.Tan(5, anchorL, 0);
  let parallelogramElementL = document.createElementNS("http://www.w3.org/2000/svg", "polygon");
  parallelogramElementL.setAttributeNS(null, "points", parallelogramL.toSVG());
  parallelogramElementL.setAttributeNS(null, "fill", '#BCBCBC');
  parallelogramElementL.setAttributeNS(null, "stroke", "#BCBCBC");
  parallelogramElementL.setAttributeNS(null, "stroke-width", "0.3");
  button.appendChild(parallelogramElementL);
  let anchorR = new _tangramPoint.Point(new _tangramIntadjoinsqrt.IntAdjoinSqrt2(36, 0), new _tangramIntadjoinsqrt.IntAdjoinSqrt2(12, 0));
  let parallelogramR = new _tangramTan.Tan(4, anchorR, 0);
  let parallelogramElementR = document.createElementNS("http://www.w3.org/2000/svg", "polygon");
  parallelogramElementR.setAttributeNS(null, "points", parallelogramR.toSVG());
  parallelogramElementR.setAttributeNS(null, "fill", '#BCBCBC');
  parallelogramElementR.setAttributeNS(null, "stroke", "#BCBCBC");
  parallelogramElementR.setAttributeNS(null, "stroke-width", "0.3");
  button.appendChild(parallelogramElementR);
  document.getElementById("game").appendChild(button);
  let flipElements = document.getElementsByClassName("flip")[0].childNodes;
  for (let flipIndex = 0; flipIndex < flipElements.length; flipIndex++) {
    flipElements[flipIndex].addEventListener("click", flipParallelogram);
    /*Change color on hover*/
    flipElements[flipIndex].addEventListener("mouseover", function () {
      // ("mousein");
      document.getElementsByClassName("flip")[0].firstElementChild.setAttributeNS(null, "fill", '#666666');
    });
    flipElements[flipIndex].addEventListener("mouseout", function () {
      // console.log("mouseOut");
      document.getElementsByClassName("flip")[0].firstElementChild.setAttributeNS(null, "fill", '#E9E9E9');
    });
  }
};
/*Game logic - flip parallelogram (triggered by click on button)*/
let flipParallelogram = function () {
  /*Parallelogram has index 6, (5 - tan type) is 0 or 1*/
  gameOutline[6].anchor = gameOutline[6].anchor.add(_tangramDirections.FlipDirections[5 - gameOutline[6].tanType][gameOutline[6].orientation]);
  gameOutline[6].tanType = gameOutline[6].tanType === 4 ? 5 : 4;
  /*Orientation 0 stays 0, all other change to 8 - current orientation*/
  gameOutline[6].orientation = gameOutline[6].orientation === 0 ? 0 : 8 - gameOutline[6].orientation;
  updateTanPiece(6);
  checkSolved();
};
/*Parse jsonString of an array of tans into a tangram*/
let parseTanArray = function (jsonString) {
  let tangram = JSON.parse(jsonString);
  let tans = [];
  for (let index = 0; index < 7; index++) {
    let currentTan = tangram[index];
    let anchor = new _tangramPoint.Point(new _tangramIntadjoinsqrt.IntAdjoinSqrt2(currentTan.anchor.x.coeffInt, currentTan.anchor.x.coeffSqrt), new _tangramIntadjoinsqrt.IntAdjoinSqrt2(currentTan.anchor.y.coeffInt, currentTan.anchor.y.coeffSqrt));
    tans.push(new _tangramTan.Tan(currentTan.tanType, anchor, currentTan.orientation));
  }
  return new _tangramTangram.Tangram(tans);
};
// FUCKING HELL
let changeTangramVisibility = function (hide) {
  let tangramClass = document.getElementsByClassName("tangram");
  for (let i = 0; i < tangramClass.length; i++) {
    tangramClass[i].style.display = hide ? 'none' : 'block';
  }
  if (!_tangramHelpers.evalVal) {
    /*Show game buttons when hiding tangrams and regenerate button otherwise*/
    document.getElementById("generate").style.display = hide ? 'none' : 'inline-block';
    // document.getElementById("select").style.display = hide ? 'inline-block' : 'none';
    document.getElementById("set").style.display = hide ? 'inline-block' : 'none';
  }
};
/*After generating is finished: show the first 6 tangrams*/
let addTangrams = function () {
  /*let failTangram = '[{"tanType":0,"anchor":{"x":{"coeffInt":39,"coeffSqrt":-12},"y":{"coeffInt":39,"coeffSqrt":0}},"orientation":6},{"tanType":0,"anchor":{"x":{"coeffInt":21,"coeffSqrt":0},"y":{"coeffInt":21,"coeffSqrt":0}},"orientation":7},{"tanType":1,"anchor":{"x":{"coeffInt":33,"coeffSqrt":0},"y":{"coeffInt":21,"coeffSqrt":0}},"orientation":6},{"tanType":2,"anchor":{"x":{"coeffInt":33,"coeffSqrt":0},"y":{"coeffInt":45,"coeffSqrt":0}},"orientation":5},{"tanType":2,"anchor":{"x":{"coeffInt":21,"coeffSqrt":0},"y":{"coeffInt":45,"coeffSqrt":0}},"orientation":5},{"tanType":3,"anchor":{"x":{"coeffInt":33,"coeffSqrt":0},"y":{"coeffInt":45,"coeffSqrt":0}},"orientation":3},{"tanType":5,"anchor":{"x":{"coeffInt":33,"coeffSqrt":0},"y":{"coeffInt":21,"coeffSqrt":0}},"orientation":2}]';
  failTangram = parseTanArray(failTangram);
  generated[0] = failTangram;*/
  /*Center the tangrams*/
  for (let tanId = 0; tanId < 6; tanId++) {
    generated[tanId].positionCentered();
  }
  generated[0].toSVGOutline("first0");
  generated[1].toSVGOutline("second1");
  generated[2].toSVGOutline("third2");
  generated[3].toSVGOutline("fourth3");
  generated[4].toSVGOutline("fifth4");
  generated[5].toSVGOutline("sixth5");
};
/*Start generating process in a web worker*/
let startGenerator = function () {
  // 1
  const before = performance.now();
  const jsonTans = _tangramGenerator.generateTangrams(50);
  const after = performance.now();
  console.log(after - before + "ms to generate");
  // 2
  _tangramHelpers.generating.val = false;
  jsonTans.forEach(el => generated.push(parseTanArray(el)));
  // 3
  addTangrams();
  firstGeneration = false;
};
window.onload = function () {
  const modal = _optionsOptionsStorageDefault.default.getAll().then(data => {
    const idate = new Date(data.installDate);
    const fbm = new _WebWebExtAsk4rating1DistTscDefault.default({
      window: window,
      headline: "Enjoying PuzzleBlocker?",
      text: `<div class="fbm-custom-text">
						<p>Do you enjoy using PuzzleBlocker or have <br>some suggestions to improve it?</p> 
						<p>Give us your feedback and a rating by visiting the link below.</p> 
						<p>Thank you!</p>
						</div>`,
      installDate: idate,
      frequency: 2,
      theme: "light",
      timeout: 2000,
      logo: _urlLogoPngDefault.default,
      storeLinks: {
        chrome: "https://chrome.google.com/webstore/detail/puzzleblocker/naomldldmhjaaomjbgldgefgjcidhbki",
        firefox: "https://addons.mozilla.org/de/firefox/addon/puzzleblocker/"
      }
    });
  }).catch(error => console.log(error));
  /*Provide fallBack if Workers or inline SVG are not supported*/
  if (typeof SVGRect === "undefined" || !window.Worker) {
    /*Show Browser fallback PNG*/
    return;
  }
  // addLoading();
  chosen = 0;
  resetPieces();
  startGenerator();
  changeTangramVisibility(false);
  /*Show larger version of the chosen tangram*/
  let tangramClass = document.getElementsByClassName("tangram");
  for (let i = 0; i < tangramClass.length; i++) {
    tangramClass[i].addEventListener('click', function (event) {
      changeTangramVisibility(true);
      let sourceId;
      let target = event.currentTarget;
      sourceId = target.id;
      /*Prevent error when click event fires on content (?)*/
      if (sourceId === 'content') {
        return;
      }
      // console.log(event.currentTarget)
      chosen = i;
      generated[i].toSVGOutline("game");
      // generated[chosen].toSVGTans("game");
      document.getElementById("game").style.display = "block";
      addTangramPieces();
      addFlipButton();
      addIcons();
      rotations = 0;
      translations = 0;
      startWatch();
    });
  }
  document.getElementById("generate").addEventListener('click', function () {
    /*Hide tangrams and generate new tangrams*/
    changeTangramVisibility(false);
    generated = [];
    // addLoading();
    startGenerator();
    resetPieces();
  });
  document.getElementById("select").addEventListener('click', function () {
    document.getElementById("game").style.display = 'none';
    let gameNode = document.getElementById('game');
    while (gameNode.firstChild) {
      gameNode.removeChild(gameNode.firstChild);
    }
    /*Show tangrams again and resest game letiables*/
    changeTangramVisibility(false);
    resetPieces();
    stopWatch();
    hints = [0, 1, 2, 3, 4, 5, 6];
    numHints = 0;
    snapped = [false, false, false, false, false, false, false];
  });
  document.getElementById("set").addEventListener('click', function () {
    /*Reset everything*/
    resetPieces();
    for (let tanIndex = 0; tanIndex < gameOutline.length; tanIndex++) {
      updateTanPiece(tanIndex);
    }
    rotations = 0;
    translations = 0;
    hints = [0, 1, 2, 3, 4, 5, 6];
    numHints = 0;
    snapped = [false, false, false, false, false, false, false];
    let hintElements = document.getElementsByClassName("hint");
    while (hintElements.length > 0) {
      hintElements[0].parentNode.removeChild(hintElements[0]);
    }
    let tangramPieces = document.getElementsByClassName("tan");
    for (let tanIndex = 0; tanIndex < tangramPieces.length; tanIndex++) {
      tangramPieces[tanIndex].setAttributeNS(null, "fill", "#FF9900");
      tangramPieces[tanIndex].setAttributeNS(null, "opacity", "0.8");
    }
  });
  document.getElementById("hint").addEventListener('click', function () {
    hint();
  });
  document.getElementById("sol").addEventListener('click', function () {
    setToSol();
    /*Change color of the tan pieces*/
    let tangramPieces = document.getElementsByClassName("tan");
    for (let tanIndex = 0; tanIndex < tangramPieces.length; tanIndex++) {
      tangramPieces[tanIndex].setAttributeNS(null, "fill", "#3299BB");
      tangramPieces[tanIndex].setAttributeNS(null, "opacity", "1.0");
    }
    /*Hide watch*/
    stopWatch();
    let watch = document.getElementById("watch");
    while (watch.firstChild) {
      watch.removeChild(watch.firstChild);
    }
  });
  new _tangramIntadjoinsqrt.IntAdjoinSqrt2(42, 6).compare(new _tangramIntadjoinsqrt.IntAdjoinSqrt2(30, 12));
};
const sendMessage = async function () {
  const tab = await _webextensionPolyfillDefault.default.tabs.getCurrent();
  const msg = _webextensionPolyfillDefault.default.runtime.sendMessage(tab.id).then(console.log).catch(console.log);
};

},{"webextension-polyfill":"ZHCM0","./tangram/directions":"4qo9l","./tangram/helpers":"3Nu5P","./tangram/tangram":"1Ps4L","./tangram/intadjoinsqrt2":"6Swgg","./tangram/point":"3thPn","./tangram/tan":"59JXy","./tangram/lineSegement":"4rt7O","./tangram/generator":"oHYt4","./options/options-storage":"1iuiP","url:./logo.png":"3XOQn","../../../_Web/web-ext-ask4rating-1/dist/tsc/":"5LnPt","@parcel/transformer-js/lib/esmodule-helpers.js":"7jqoH"}],"ZHCM0":[function(require,module,exports) {
var define;
(function (global, factory) {
  if (typeof define === "function" && define.amd) {
    define("webextension-polyfill", ["module"], factory);
  } else if (typeof exports !== "undefined") {
    factory(module);
  } else {
    var mod = {
      exports: {}
    };
    factory(mod);
    global.browser = mod.exports;
  }
})(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : this, function (module) {
  /*webextension-polyfill - v0.7.0 - Tue Nov 10 2020 20:24:04*/
  /*-*- Mode: indent-tabs-mode: nil; js-indent-level: 2 -*-*/
  /*vim: set sts=2 sw=2 et tw=80:*/
  /*This Source Code Form is subject to the terms of the Mozilla Public
  * License, v. 2.0. If a copy of the MPL was not distributed with this
  * file, You can obtain one at http://mozilla.org/MPL/2.0/.*/
  "use strict";
  if (typeof browser === "undefined" || Object.getPrototypeOf(browser) !== Object.prototype) {
    const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
    const SEND_RESPONSE_DEPRECATION_WARNING = "Returning a Promise is the preferred way to send a reply from an onMessage/onMessageExternal listener, as the sendResponse will be removed from the specs (See https://developer.mozilla.org/docs/Mozilla/Add-ons/WebExtensions/API/runtime/onMessage)";
    // Wrapping the bulk of this polyfill in a one-time-use function is a minor
    // optimization for Firefox. Since Spidermonkey does not fully parse the
    // contents of a function until the first time it's called, and since it will
    // never actually need to be called, this allows the polyfill to be included
    // in Firefox nearly for free.
    const wrapAPIs = extensionAPIs => {
      // NOTE: apiMetadata is associated to the content of the api-metadata.json file
      // at build time by replacing the following "include" with the content of the
      // JSON file.
      const apiMetadata = {
        "alarms": {
          "clear": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "clearAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "get": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "bookmarks": {
          "create": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getChildren": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getRecent": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getSubTree": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTree": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "move": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeTree": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "browserAction": {
          "disable": {
            "minArgs": 0,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "enable": {
            "minArgs": 0,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "getBadgeBackgroundColor": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getBadgeText": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getPopup": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTitle": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "openPopup": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "setBadgeBackgroundColor": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setBadgeText": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setIcon": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "setPopup": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setTitle": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "browsingData": {
          "remove": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "removeCache": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeCookies": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeDownloads": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeFormData": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeHistory": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeLocalStorage": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removePasswords": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removePluginData": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "settings": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "commands": {
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "contextMenus": {
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "cookies": {
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAllCookieStores": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "set": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "devtools": {
          "inspectedWindow": {
            "eval": {
              "minArgs": 1,
              "maxArgs": 2,
              "singleCallbackArg": false
            }
          },
          "panels": {
            "create": {
              "minArgs": 3,
              "maxArgs": 3,
              "singleCallbackArg": true
            },
            "elements": {
              "createSidebarPane": {
                "minArgs": 1,
                "maxArgs": 1
              }
            }
          }
        },
        "downloads": {
          "cancel": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "download": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "erase": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getFileIcon": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "open": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "pause": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeFile": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "resume": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "show": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "extension": {
          "isAllowedFileSchemeAccess": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "isAllowedIncognitoAccess": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "history": {
          "addUrl": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "deleteAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "deleteRange": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "deleteUrl": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getVisits": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "i18n": {
          "detectLanguage": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAcceptLanguages": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "identity": {
          "launchWebAuthFlow": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "idle": {
          "queryState": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "management": {
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getSelf": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "setEnabled": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "uninstallSelf": {
            "minArgs": 0,
            "maxArgs": 1
          }
        },
        "notifications": {
          "clear": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "create": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getPermissionLevel": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "pageAction": {
          "getPopup": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTitle": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "hide": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setIcon": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "setPopup": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setTitle": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "show": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "permissions": {
          "contains": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "request": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "runtime": {
          "getBackgroundPage": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getPlatformInfo": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "openOptionsPage": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "requestUpdateCheck": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "sendMessage": {
            "minArgs": 1,
            "maxArgs": 3
          },
          "sendNativeMessage": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "setUninstallURL": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "sessions": {
          "getDevices": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getRecentlyClosed": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "restore": {
            "minArgs": 0,
            "maxArgs": 1
          }
        },
        "storage": {
          "local": {
            "clear": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "remove": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "set": {
              "minArgs": 1,
              "maxArgs": 1
            }
          },
          "managed": {
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            }
          },
          "sync": {
            "clear": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "remove": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "set": {
              "minArgs": 1,
              "maxArgs": 1
            }
          }
        },
        "tabs": {
          "captureVisibleTab": {
            "minArgs": 0,
            "maxArgs": 2
          },
          "create": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "detectLanguage": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "discard": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "duplicate": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "executeScript": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getCurrent": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getZoom": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getZoomSettings": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "goBack": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "goForward": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "highlight": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "insertCSS": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "move": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "query": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "reload": {
            "minArgs": 0,
            "maxArgs": 2
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeCSS": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "sendMessage": {
            "minArgs": 2,
            "maxArgs": 3
          },
          "setZoom": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "setZoomSettings": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "update": {
            "minArgs": 1,
            "maxArgs": 2
          }
        },
        "topSites": {
          "get": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "webNavigation": {
          "getAllFrames": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getFrame": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "webRequest": {
          "handlerBehaviorChanged": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "windows": {
          "create": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getCurrent": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getLastFocused": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        }
      };
      if (Object.keys(apiMetadata).length === 0) {
        throw new Error("api-metadata.json has not been included in browser-polyfill");
      }
      /**
      * A WeakMap subclass which creates and stores a value for any key which does
      * not exist when accessed, but behaves exactly as an ordinary WeakMap
      * otherwise.
      *
      * @param {function} createItem
      *        A function which will be called in order to create the value for any
      *        key which does not exist, the first time it is accessed. The
      *        function receives, as its only argument, the key being created.
      */
      class DefaultWeakMap extends WeakMap {
        constructor(createItem, items = undefined) {
          super(items);
          this.createItem = createItem;
        }
        get(key) {
          if (!this.has(key)) {
            this.set(key, this.createItem(key));
          }
          return super.get(key);
        }
      }
      /**
      * Returns true if the given object is an object with a `then` method, and can
      * therefore be assumed to behave as a Promise.
      *
      * @param {*} value The value to test.
      * @returns {boolean} True if the value is thenable.
      */
      const isThenable = value => {
        return value && typeof value === "object" && typeof value.then === "function";
      };
      /**
      * Creates and returns a function which, when called, will resolve or reject
      * the given promise based on how it is called:
      *
      * - If, when called, `chrome.runtime.lastError` contains a non-null object,
      *   the promise is rejected with that value.
      * - If the function is called with exactly one argument, the promise is
      *   resolved to that value.
      * - Otherwise, the promise is resolved to an array containing all of the
      *   function's arguments.
      *
      * @param {object} promise
      *        An object containing the resolution and rejection functions of a
      *        promise.
      * @param {function} promise.resolve
      *        The promise's resolution function.
      * @param {function} promise.rejection
      *        The promise's rejection function.
      * @param {object} metadata
      *        Metadata about the wrapped method which has created the callback.
      * @param {integer} metadata.maxResolvedArgs
      *        The maximum number of arguments which may be passed to the
      *        callback created by the wrapped async function.
      *
      * @returns {function}
      *        The generated callback function.
      */
      const makeCallback = (promise, metadata) => {
        return (...callbackArgs) => {
          if (extensionAPIs.runtime.lastError) {
            promise.reject(extensionAPIs.runtime.lastError);
          } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
            promise.resolve(callbackArgs[0]);
          } else {
            promise.resolve(callbackArgs);
          }
        };
      };
      const pluralizeArguments = numArgs => numArgs == 1 ? "argument" : "arguments";
      /**
      * Creates a wrapper function for a method with the given name and metadata.
      *
      * @param {string} name
      *        The name of the method which is being wrapped.
      * @param {object} metadata
      *        Metadata about the method being wrapped.
      * @param {integer} metadata.minArgs
      *        The minimum number of arguments which must be passed to the
      *        function. If called with fewer than this number of arguments, the
      *        wrapper will raise an exception.
      * @param {integer} metadata.maxArgs
      *        The maximum number of arguments which may be passed to the
      *        function. If called with more than this number of arguments, the
      *        wrapper will raise an exception.
      * @param {integer} metadata.maxResolvedArgs
      *        The maximum number of arguments which may be passed to the
      *        callback created by the wrapped async function.
      *
      * @returns {function(object, ...*)}
      *       The generated wrapper function.
      */
      const wrapAsyncFunction = (name, metadata) => {
        return function asyncFunctionWrapper(target, ...args) {
          if (args.length < metadata.minArgs) {
            throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
          }
          if (args.length > metadata.maxArgs) {
            throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
          }
          return new Promise((resolve, reject) => {
            if (metadata.fallbackToNoCallback) {
              // This API method has currently no callback on Chrome, but it return a promise on Firefox,
              // and so the polyfill will try to call it with a callback first, and it will fallback
              // to not passing the callback if the first call fails.
              try {
                target[name](...args, makeCallback({
                  resolve,
                  reject
                }, metadata));
              } catch (cbError) {
                console.warn(`${name} API method doesn't seem to support the callback parameter, ` + "falling back to call it without a callback: ", cbError);
                target[name](...args);
                // Update the API method metadata, so that the next API calls will not try to
                // use the unsupported callback anymore.
                metadata.fallbackToNoCallback = false;
                metadata.noCallback = true;
                resolve();
              }
            } else if (metadata.noCallback) {
              target[name](...args);
              resolve();
            } else {
              target[name](...args, makeCallback({
                resolve,
                reject
              }, metadata));
            }
          });
        };
      };
      /**
      * Wraps an existing method of the target object, so that calls to it are
      * intercepted by the given wrapper function. The wrapper function receives,
      * as its first argument, the original `target` object, followed by each of
      * the arguments passed to the original method.
      *
      * @param {object} target
      *        The original target object that the wrapped method belongs to.
      * @param {function} method
      *        The method being wrapped. This is used as the target of the Proxy
      *        object which is created to wrap the method.
      * @param {function} wrapper
      *        The wrapper function which is called in place of a direct invocation
      *        of the wrapped method.
      *
      * @returns {Proxy<function>}
      *        A Proxy object for the given method, which invokes the given wrapper
      *        method in its place.
      */
      const wrapMethod = (target, method, wrapper) => {
        return new Proxy(method, {
          apply(targetMethod, thisObj, args) {
            return wrapper.call(thisObj, target, ...args);
          }
        });
      };
      let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
      /**
      * Wraps an object in a Proxy which intercepts and wraps certain methods
      * based on the given `wrappers` and `metadata` objects.
      *
      * @param {object} target
      *        The target object to wrap.
      *
      * @param {object} [wrappers = {}]
      *        An object tree containing wrapper functions for special cases. Any
      *        function present in this object tree is called in place of the
      *        method in the same location in the `target` object tree. These
      *        wrapper methods are invoked as described in {@see wrapMethod}.
      *
      * @param {object} [metadata = {}]
      *        An object tree containing metadata used to automatically generate
      *        Promise-based wrapper functions for asynchronous. Any function in
      *        the `target` object tree which has a corresponding metadata object
      *        in the same location in the `metadata` tree is replaced with an
      *        automatically-generated wrapper function, as described in
      *        {@see wrapAsyncFunction}
      *
      * @returns {Proxy<object>}
      */
      const wrapObject = (target, wrappers = {}, metadata = {}) => {
        let cache = Object.create(null);
        let handlers = {
          has(proxyTarget, prop) {
            return (prop in target) || (prop in cache);
          },
          get(proxyTarget, prop, receiver) {
            if ((prop in cache)) {
              return cache[prop];
            }
            if (!((prop in target))) {
              return undefined;
            }
            let value = target[prop];
            if (typeof value === "function") {
              // This is a method on the underlying object. Check if we need to do
              // any wrapping.
              if (typeof wrappers[prop] === "function") {
                // We have a special-case wrapper for this method.
                value = wrapMethod(target, target[prop], wrappers[prop]);
              } else if (hasOwnProperty(metadata, prop)) {
                // This is an async method that we have metadata for. Create a
                // Promise wrapper for it.
                let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                value = wrapMethod(target, target[prop], wrapper);
              } else {
                // This is a method that we don't know or care about. Return the
                // original method, bound to the underlying object.
                value = value.bind(target);
              }
            } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
              // This is an object that we need to do some wrapping for the children
              // of. Create a sub-object wrapper for it with the appropriate child
              // metadata.
              value = wrapObject(value, wrappers[prop], metadata[prop]);
            } else if (hasOwnProperty(metadata, "*")) {
              // Wrap all properties in * namespace.
              value = wrapObject(value, wrappers[prop], metadata["*"]);
            } else {
              // We don't need to do any wrapping for this property,
              // so just forward all access to the underlying object.
              Object.defineProperty(cache, prop, {
                configurable: true,
                enumerable: true,
                get() {
                  return target[prop];
                },
                set(value) {
                  target[prop] = value;
                }
              });
              return value;
            }
            cache[prop] = value;
            return value;
          },
          set(proxyTarget, prop, value, receiver) {
            if ((prop in cache)) {
              cache[prop] = value;
            } else {
              target[prop] = value;
            }
            return true;
          },
          defineProperty(proxyTarget, prop, desc) {
            return Reflect.defineProperty(cache, prop, desc);
          },
          deleteProperty(proxyTarget, prop) {
            return Reflect.deleteProperty(cache, prop);
          }
        };
        // Per contract of the Proxy API, the "get" proxy handler must return the
        // original value of the target if that value is declared read-only and
        // non-configurable. For this reason, we create an object with the
        // prototype set to `target` instead of using `target` directly.
        // Otherwise we cannot return a custom object for APIs that
        // are declared read-only and non-configurable, such as `chrome.devtools`.
        // 
        // The proxy handlers themselves will still use the original `target`
        // instead of the `proxyTarget`, so that the methods and properties are
        // dereferenced via the original targets.
        let proxyTarget = Object.create(target);
        return new Proxy(proxyTarget, handlers);
      };
      /**
      * Creates a set of wrapper functions for an event object, which handles
      * wrapping of listener functions that those messages are passed.
      *
      * A single wrapper is created for each listener function, and stored in a
      * map. Subsequent calls to `addListener`, `hasListener`, or `removeListener`
      * retrieve the original wrapper, so that  attempts to remove a
      * previously-added listener work as expected.
      *
      * @param {DefaultWeakMap<function, function>} wrapperMap
      *        A DefaultWeakMap object which will create the appropriate wrapper
      *        for a given listener function when one does not exist, and retrieve
      *        an existing one when it does.
      *
      * @returns {object}
      */
      const wrapEvent = wrapperMap => ({
        addListener(target, listener, ...args) {
          target.addListener(wrapperMap.get(listener), ...args);
        },
        hasListener(target, listener) {
          return target.hasListener(wrapperMap.get(listener));
        },
        removeListener(target, listener) {
          target.removeListener(wrapperMap.get(listener));
        }
      });
      // Keep track if the deprecation warning has been logged at least once.
      let loggedSendResponseDeprecationWarning = false;
      const onMessageWrappers = new DefaultWeakMap(listener => {
        if (typeof listener !== "function") {
          return listener;
        }
        /**
        * Wraps a message listener function so that it may send responses based on
        * its return value, rather than by returning a sentinel value and calling a
        * callback. If the listener function returns a Promise, the response is
        * sent when the promise either resolves or rejects.
        *
        * @param {*} message
        *        The message sent by the other end of the channel.
        * @param {object} sender
        *        Details about the sender of the message.
        * @param {function(*)} sendResponse
        *        A callback which, when called with an arbitrary argument, sends
        *        that value as a response.
        * @returns {boolean}
        *        True if the wrapped listener returned a Promise, which will later
        *        yield a response. False otherwise.
        */
        return function onMessage(message, sender, sendResponse) {
          let didCallSendResponse = false;
          let wrappedSendResponse;
          let sendResponsePromise = new Promise(resolve => {
            wrappedSendResponse = function (response) {
              if (!loggedSendResponseDeprecationWarning) {
                console.warn(SEND_RESPONSE_DEPRECATION_WARNING, new Error().stack);
                loggedSendResponseDeprecationWarning = true;
              }
              didCallSendResponse = true;
              resolve(response);
            };
          });
          let result;
          try {
            result = listener(message, sender, wrappedSendResponse);
          } catch (err) {
            result = Promise.reject(err);
          }
          const isResultThenable = result !== true && isThenable(result);
          // If the listener didn't returned true or a Promise, or called
          // wrappedSendResponse synchronously, we can exit earlier
          // because there will be no response sent from this listener.
          if (result !== true && !isResultThenable && !didCallSendResponse) {
            return false;
          }
          // A small helper to send the message if the promise resolves
          // and an error if the promise rejects (a wrapped sendMessage has
          // to translate the message into a resolved promise or a rejected
          // promise).
          const sendPromisedResult = promise => {
            promise.then(msg => {
              // send the message value.
              sendResponse(msg);
            }, error => {
              // Send a JSON representation of the error if the rejected value
              // is an instance of error, or the object itself otherwise.
              let message;
              if (error && (error instanceof Error || typeof error.message === "string")) {
                message = error.message;
              } else {
                message = "An unexpected error occurred";
              }
              sendResponse({
                __mozWebExtensionPolyfillReject__: true,
                message
              });
            }).catch(err => {
              // Print an error on the console if unable to send the response.
              console.error("Failed to send onMessage rejected reply", err);
            });
          };
          // If the listener returned a Promise, send the resolved value as a
          // result, otherwise wait the promise related to the wrappedSendResponse
          // callback to resolve and send it as a response.
          if (isResultThenable) {
            sendPromisedResult(result);
          } else {
            sendPromisedResult(sendResponsePromise);
          }
          // Let Chrome know that the listener is replying.
          return true;
        };
      });
      const wrappedSendMessageCallback = ({reject, resolve}, reply) => {
        if (extensionAPIs.runtime.lastError) {
          // Detect when none of the listeners replied to the sendMessage call and resolve
          // the promise to undefined as in Firefox.
          // See https://github.com/mozilla/webextension-polyfill/issues/130
          if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
            resolve();
          } else {
            reject(extensionAPIs.runtime.lastError);
          }
        } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
          // Convert back the JSON representation of the error into
          // an Error instance.
          reject(new Error(reply.message));
        } else {
          resolve(reply);
        }
      };
      const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
        if (args.length < metadata.minArgs) {
          throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
        }
        if (args.length > metadata.maxArgs) {
          throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
        }
        return new Promise((resolve, reject) => {
          const wrappedCb = wrappedSendMessageCallback.bind(null, {
            resolve,
            reject
          });
          args.push(wrappedCb);
          apiNamespaceObj.sendMessage(...args);
        });
      };
      const staticWrappers = {
        runtime: {
          onMessage: wrapEvent(onMessageWrappers),
          onMessageExternal: wrapEvent(onMessageWrappers),
          sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
            minArgs: 1,
            maxArgs: 3
          })
        },
        tabs: {
          sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
            minArgs: 2,
            maxArgs: 3
          })
        }
      };
      const settingMetadata = {
        clear: {
          minArgs: 1,
          maxArgs: 1
        },
        get: {
          minArgs: 1,
          maxArgs: 1
        },
        set: {
          minArgs: 1,
          maxArgs: 1
        }
      };
      apiMetadata.privacy = {
        network: {
          "*": settingMetadata
        },
        services: {
          "*": settingMetadata
        },
        websites: {
          "*": settingMetadata
        }
      };
      return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
    };
    if (typeof chrome != "object" || !chrome || !chrome.runtime || !chrome.runtime.id) {
      throw new Error("This script should only be loaded in a browser extension.");
    }
    // The build process adds a UMD wrapper around this file, which makes the
    // `module` variable available.
    module.exports = wrapAPIs(chrome);
  } else {
    module.exports = browser;
  }
});

},{}],"4qo9l":[function(require,module,exports) {
var _parcelHelpers = require("@parcel/transformer-js/lib/esmodule-helpers.js");
_parcelHelpers.defineInteropFlag(exports);
_parcelHelpers.export(exports, "Directions", function () {
  return Directions;
});
_parcelHelpers.export(exports, "InsideDirections", function () {
  return InsideDirections;
});
_parcelHelpers.export(exports, "SegmentDirections", function () {
  return SegmentDirections;
});
_parcelHelpers.export(exports, "numOrientations", function () {
  return numOrientations;
});
_parcelHelpers.export(exports, "FlipDirections", function () {
  return FlipDirections;
});
var _point = require("./point");
var _intadjoinsqrt = require("./intadjoinsqrt2");
let Directions = [];
let InsideDirections = [];
let SegmentDirections = [];
let numOrientations = 8;
/*Create Array for each tan piece*/
for (let index = 0; index <= 5; index++) {
  InsideDirections[index] = [];
  Directions[index] = [];
  SegmentDirections[index] = [];
}
/*Fill the first entry of each array with the direction vectors for when
* a piece is not rotated*/
Directions[0][0] = [new _point.Point(new _intadjoinsqrt.IntAdjoinSqrt2(0, 12), new _intadjoinsqrt.IntAdjoinSqrt2(0, 0)), new _point.Point(new _intadjoinsqrt.IntAdjoinSqrt2(0, 0), new _intadjoinsqrt.IntAdjoinSqrt2(0, 12))];
Directions[1][0] = [new _point.Point(new _intadjoinsqrt.IntAdjoinSqrt2(12, 0), new _intadjoinsqrt.IntAdjoinSqrt2(0, 0)), new _point.Point(new _intadjoinsqrt.IntAdjoinSqrt2(0, 0), new _intadjoinsqrt.IntAdjoinSqrt2(12, 0))];
Directions[2][0] = [new _point.Point(new _intadjoinsqrt.IntAdjoinSqrt2(0, 6), new _intadjoinsqrt.IntAdjoinSqrt2(0, 0)), new _point.Point(new _intadjoinsqrt.IntAdjoinSqrt2(0, 0), new _intadjoinsqrt.IntAdjoinSqrt2(0, 6))];
Directions[3][0] = [new _point.Point(new _intadjoinsqrt.IntAdjoinSqrt2(0, 6), new _intadjoinsqrt.IntAdjoinSqrt2(0, 0)), new _point.Point(new _intadjoinsqrt.IntAdjoinSqrt2(0, 6), new _intadjoinsqrt.IntAdjoinSqrt2(0, 6)), new _point.Point(new _intadjoinsqrt.IntAdjoinSqrt2(0, 0), new _intadjoinsqrt.IntAdjoinSqrt2(0, 6))];
Directions[4][0] = [new _point.Point(new _intadjoinsqrt.IntAdjoinSqrt2(12, 0), new _intadjoinsqrt.IntAdjoinSqrt2(0, 0)), new _point.Point(new _intadjoinsqrt.IntAdjoinSqrt2(18, 0), new _intadjoinsqrt.IntAdjoinSqrt2(6, 0)), new _point.Point(new _intadjoinsqrt.IntAdjoinSqrt2(6, 0), new _intadjoinsqrt.IntAdjoinSqrt2(6, 0))];
Directions[5][0] = [new _point.Point(new _intadjoinsqrt.IntAdjoinSqrt2(12, 0), new _intadjoinsqrt.IntAdjoinSqrt2(0, 0)), new _point.Point(new _intadjoinsqrt.IntAdjoinSqrt2(18, 0), new _intadjoinsqrt.IntAdjoinSqrt2(-6, 0)), new _point.Point(new _intadjoinsqrt.IntAdjoinSqrt2(6, 0), new _intadjoinsqrt.IntAdjoinSqrt2(-6, 0))];
/*Calculate some direction vectors to points that lie inside each tan, for fast
* overlap rejection, this includes the center of each tan, for four-sided tans
* the center of three out of four vertices and for medium and large triangles
* the center in each half of the triangle*/
for (let tanTypeId = 0; tanTypeId <= 5; tanTypeId++) {
  const centerPoint = new _point.Point();
  for (let pointId = 0; pointId < Directions[tanTypeId][0].length; pointId++) {
    centerPoint.add(Directions[tanTypeId][0][pointId]);
  }
  centerPoint.scale(1 / (Directions[tanTypeId][0].length + 1));
  InsideDirections[tanTypeId][0] = [];
  InsideDirections[tanTypeId][0][0] = centerPoint;
}
let insidePoint1;
let insidePoint2;
for (let tanTypeId = 0; tanTypeId <= 1; tanTypeId++) {
  const middle1 = Directions[tanTypeId][0][0].dup().add(Directions[tanTypeId][0][1]).scale(0.5);
  insidePoint1 = Directions[tanTypeId][0][0].dup().add(middle1);
  insidePoint2 = Directions[tanTypeId][0][1].dup().add(middle1);
  insidePoint1.scale(1 / Directions[tanTypeId][0].length);
  InsideDirections[tanTypeId][0][1] = insidePoint1;
  insidePoint2.scale(1 / Directions[tanTypeId][0].length);
  InsideDirections[tanTypeId][0][2] = insidePoint2;
  /*Add center of a triangle formed by the anchor and the middle of the two
  * adjacent segments for the large triangle tan*/
  if (tanTypeId === 0) {
    const middle2 = Directions[tanTypeId][0][0].dup().scale(0.5);
    const middle3 = Directions[tanTypeId][0][1].dup().scale(0.5);
    const insidePoint3 = middle2.add(middle3);
    insidePoint3.scale(1 / Directions[tanTypeId][0].length);
    insidePoint3.scale(1 / Directions[tanTypeId][0].length);
  }
}
for (let tanTypeId = 3; tanTypeId <= 5; tanTypeId++) {
  insidePoint1 = new _point.Point();
  insidePoint2 = new _point.Point();
  for (let pointId = 0; pointId < Directions[tanTypeId][0].length; pointId++) {
    if (pointId != Directions[tanTypeId][0].length - 1) {
      insidePoint1.add(Directions[tanTypeId][0][pointId]);
    }
    insidePoint2.add(Directions[tanTypeId][0][pointId]);
  }
  insidePoint1.scale(1 / Directions[tanTypeId][0].length);
  InsideDirections[tanTypeId][0][1] = insidePoint1;
  insidePoint2.scale(1 / Directions[tanTypeId][0].length);
  InsideDirections[tanTypeId][0][2] = insidePoint2;
}
/*Matrix for rotating by 45 degrees*/
const rotationMatrix = [[new _intadjoinsqrt.IntAdjoinSqrt2(0, 0.5), new _intadjoinsqrt.IntAdjoinSqrt2(0, -0.5), new _intadjoinsqrt.IntAdjoinSqrt2(0, 0)], [new _intadjoinsqrt.IntAdjoinSqrt2(0, 0.5), new _intadjoinsqrt.IntAdjoinSqrt2(0, 0.5), new _intadjoinsqrt.IntAdjoinSqrt2(0, 0)], [new _intadjoinsqrt.IntAdjoinSqrt2(0, 0), new _intadjoinsqrt.IntAdjoinSqrt2(0, 0), new _intadjoinsqrt.IntAdjoinSqrt2(1, 0)]];
/*For each type, rotate the direction vectors of orientation orientId by 45
* degrees to get the direction vectors for orientation orientId+1*/
for (let tanTypeId = 0; tanTypeId <= 5; tanTypeId++) {
  for (let orientId = 0; orientId < 7; orientId++) {
    Directions[tanTypeId][orientId + 1] = [];
    InsideDirections[tanTypeId][orientId + 1] = [];
    for (let pointId = 0; pointId < InsideDirections[tanTypeId][orientId].length; pointId++) {
      InsideDirections[tanTypeId][orientId + 1][pointId] = InsideDirections[tanTypeId][orientId][pointId].dup().transform(rotationMatrix);
    }
    for (let dir = 0; dir < Directions[tanTypeId][0].length; dir++) {
      Directions[tanTypeId][orientId + 1][dir] = Directions[tanTypeId][orientId][dir].dup().transform(rotationMatrix);
    }
  }
}
/*Pre-calculate the directions of the segments from each point to avoid
* calculating them over and over again*/
for (let tanTypeId = 0; tanTypeId <= 5; tanTypeId++) {
  for (let orientId = 0; orientId <= 7; orientId++) {
    SegmentDirections[tanTypeId][orientId] = [];
    /*Anchor point, take first and last direction*/
    SegmentDirections[tanTypeId][orientId][0] = [Directions[tanTypeId][orientId][0].dup(), Directions[tanTypeId][orientId][tanTypeId < 3 ? 1 : 2].dup()];
    /*First point, take negated direction to the point from the anchor, for
    * the second segment, add Direction to the second point to the direction
    * for the first segment*/
    SegmentDirections[tanTypeId][orientId][1] = [Directions[tanTypeId][orientId][0].dup().neg(), Directions[tanTypeId][orientId][0].dup().neg().add(Directions[tanTypeId][orientId][1].dup())];
    /*Second point, calculation depends on tan type, for three-sided tans
    * handle the same way as first point, for four-sided tans first calculate
    * direction to the anchor, then add respective direction vectors*/
    if (tanTypeId < 3) {
      SegmentDirections[tanTypeId][orientId][2] = [Directions[tanTypeId][orientId][1].dup().neg(), Directions[tanTypeId][orientId][1].dup().neg().add(Directions[tanTypeId][orientId][0].dup())];
    } else {
      const toAnchor = Directions[tanTypeId][orientId][1].dup().neg();
      SegmentDirections[tanTypeId][orientId][2] = [Directions[tanTypeId][orientId][0].dup().add(toAnchor), Directions[tanTypeId][orientId][2].dup().add(toAnchor)];
      /*Third point, handled the same way as second point for three-sided*/
      SegmentDirections[tanTypeId][orientId][3] = [Directions[tanTypeId][orientId][2].dup().neg(), Directions[tanTypeId][orientId][2].dup().neg().add(Directions[tanTypeId][orientId][1].dup())];
    }
  }
}
const FlipDirections = [[new _point.Point(new _intadjoinsqrt.IntAdjoinSqrt2(0, 0), new _intadjoinsqrt.IntAdjoinSqrt2(-6, 0)), /*0*/
new _point.Point(new _intadjoinsqrt.IntAdjoinSqrt2(0, 0), new _intadjoinsqrt.IntAdjoinSqrt2(0, 6)), /*1*/
new _point.Point(new _intadjoinsqrt.IntAdjoinSqrt2(0, 0), new _intadjoinsqrt.IntAdjoinSqrt2(18, 0)), /*2*/
new _point.Point(new _intadjoinsqrt.IntAdjoinSqrt2(0, 0), new _intadjoinsqrt.IntAdjoinSqrt2(0, 12)), /*3*/
new _point.Point(new _intadjoinsqrt.IntAdjoinSqrt2(0, 0), new _intadjoinsqrt.IntAdjoinSqrt2(6, 0)), /*4*/
new _point.Point(new _intadjoinsqrt.IntAdjoinSqrt2(0, 0), new _intadjoinsqrt.IntAdjoinSqrt2(0, -6)), /*5*/
new _point.Point(new _intadjoinsqrt.IntAdjoinSqrt2(0, 0), new _intadjoinsqrt.IntAdjoinSqrt2(-18, 0)), /*6*/
new _point.Point(new _intadjoinsqrt.IntAdjoinSqrt2(0, 0), new _intadjoinsqrt.IntAdjoinSqrt2(0, -12))], /*7*/
[new _point.Point(new _intadjoinsqrt.IntAdjoinSqrt2(0, 0), new _intadjoinsqrt.IntAdjoinSqrt2(6, 0)), /*0*/
new _point.Point(new _intadjoinsqrt.IntAdjoinSqrt2(0, 0), new _intadjoinsqrt.IntAdjoinSqrt2(0, 12)), /*1*/
new _point.Point(new _intadjoinsqrt.IntAdjoinSqrt2(0, 0), new _intadjoinsqrt.IntAdjoinSqrt2(18, 0)), /*2*/
new _point.Point(new _intadjoinsqrt.IntAdjoinSqrt2(0, 0), new _intadjoinsqrt.IntAdjoinSqrt2(0, 6)), /*3*/
new _point.Point(new _intadjoinsqrt.IntAdjoinSqrt2(0, 0), new _intadjoinsqrt.IntAdjoinSqrt2(-6, 0)), /*4*/
new _point.Point(new _intadjoinsqrt.IntAdjoinSqrt2(0, 0), new _intadjoinsqrt.IntAdjoinSqrt2(0, -12)), /*5*/
new _point.Point(new _intadjoinsqrt.IntAdjoinSqrt2(0, 0), new _intadjoinsqrt.IntAdjoinSqrt2(-18, 0)), /*6*/
new _point.Point(new _intadjoinsqrt.IntAdjoinSqrt2(0, 0), new _intadjoinsqrt.IntAdjoinSqrt2(0, -6))]];

},{"./point":"3thPn","./intadjoinsqrt2":"6Swgg","@parcel/transformer-js/lib/esmodule-helpers.js":"7jqoH"}],"3thPn":[function(require,module,exports) {
var _parcelHelpers = require("@parcel/transformer-js/lib/esmodule-helpers.js");
_parcelHelpers.defineInteropFlag(exports);
_parcelHelpers.export(exports, "Point", function () {
  return Point;
});
_parcelHelpers.export(exports, "relativeOrientation", function () {
  return relativeOrientation;
});
_parcelHelpers.export(exports, "bothPointsMultipleTimes", function () {
  return bothPointsMultipleTimes;
});
var _intadjoinsqrt = require("./intadjoinsqrt2");
var _helpers = require("./helpers");
function _defineProperty(obj, key, value) {
  if ((key in obj)) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }
  return obj;
}
class Point {
  constructor(x, y) {
    _defineProperty(this, "dup", function () {
      return new Point(this.x.dup(), this.y.dup());
    });
    _defineProperty(this, "toFloatX", function () {
      return this.x.toFloat();
    });
    _defineProperty(this, "toFloatY", function () {
      return this.y.toFloat();
    });
    _defineProperty(this, "compare", function (other) {
      const xCompare = this.x.compare(other.x);
      const yCompare = this.y.compare(other.y);
      if (xCompare != 0) {
        return xCompare;
      } else {
        return yCompare;
      }
    });
    _defineProperty(this, "compareYX", function (other) {
      const xCompare = this.x.compare(other.x);
      const yCompare = this.y.compare(other.y);
      if (yCompare != 0) {
        return yCompare;
      } else {
        return xCompare;
      }
    });
    _defineProperty(this, "multipleOf", function (other) {
      /*Direction vectors are a multiple of each other if they either are both
      * equal to (0,0), if they both have the form (0,a) or (a,0) where the a has
      * has the same sign in both cases or (a,b) = s*(c,d)*/
      const sameSignX = this.x.sameSign(other.x);
      const sameSignY = this.y.sameSign(other.y);
      if (!(sameSignX && sameSignY)) return false;
      if (this.x.isZero() && other.x.isZero()) {
        if (this.y.isZero() && other.y.isZero()) {
          return true;
        } else {
          return sameSignY;
        }
      } else if (this.y.isZero() && other.y.isZero()) {
        return sameSignX;
      } else {
        const xFactor = this.x.dup().div(other.x);
        const yFactor = this.y.dup().div(other.y);
        if (typeof xFactor === 'undefined' || typeof yFactor === 'undefined') {
          console.log("Undefined");
          console.log(this.x.coeffInt + "," + this.x.coeffSqrt + " - " + this.y.coeffInt + "," + this.y.coeffSqrt);
          console.log(other.x.coeffInt + "," + other.x.coeffSqrt + " - " + other.y.coeffInt + "," + other.y.coeffSqrt);
          return false;
        } else {
          /*var res = xFactor.eq(yFactor);
          if (res) {
          console.log("True");
          console.log(this.x.coeffInt + "," + this.x.coeffSqrt + " - "  + this.y.coeffInt + "," + this.y.coeffSqrt);
          console.log(other.x.coeffInt + "," + other.x.coeffSqrt + " - "  + other.y.coeffInt + "," + other.y.coeffSqrt);
          }*/
          return xFactor.eq(yFactor);
        }
      }
    });
    _defineProperty(this, "eq", function (other) {
      return this.x.eq(other.x) && this.y.eq(other.y);
    });
    _defineProperty(this, "isZero", function () {
      return this.x.isZero() && this.y.isZero();
    });
    _defineProperty(this, "length", function () {
      return Math.sqrt(this.dotProduct(this).toFloat());
    });
    _defineProperty(this, "neg", function () {
      this.x.neg();
      this.y.neg();
      return this;
    });
    _defineProperty(this, "angle", function () {
      if (this.isZero()) {
        return 0;
      }
      let angle = Math.atan2(this.toFloatY(), this.toFloatX());
      angle = _helpers.clipAngle(_helpers.toDegrees(angle));
      /*(Angles should be multiples of 45 degrees, so this shouldn't cause problems*/
      return Math.round(angle);
    });
    _defineProperty(this, "distance", function (other) {
      const toOther = other.dup().subtract(this);
      return toOther.length();
    });
    _defineProperty(this, "angleTo", function (other) {
      /*The angle is calculated with atan2, which is not defined for (0,0).
      * Therefore, handle cases where one point is (0,0) first*/
      if (this.isZero()) {
        return other.angle();
      }
      if (other.isZero()) {
        return this.angle();
      }
      let angle = 360 - (other.angle() - this.angle());
      angle = _helpers.clipAngle(angle);
      return angle;
    });
    _defineProperty(this, "add", function (other) {
      this.x.add(other.x);
      this.y.add(other.y);
      return this;
    });
    _defineProperty(this, "middle", function (other) {
      const result = new Point();
      result.add(this);
      result.add(other);
      result.scale(0.5);
      return result;
    });
    _defineProperty(this, "subtract", function (other) {
      this.x.subtract(other.x);
      this.y.subtract(other.y);
      return this;
    });
    _defineProperty(this, "normalize", function () {
      const length = this.length();
      if (_helpers.numberNEq(length, 0)) {
        this.x.scale(1 / length);
        this.y.scale(1 / length);
      }
      return this;
    });
    _defineProperty(this, "dotProduct", function (other) {
      /*Multiplication of respective coordinates then summation of those products*/
      return this.x.dup().multiply(other.x).add(this.y.dup().multiply(other.y));
    });
    _defineProperty(this, "determinant", function (other) {
      /*In 2D, the cross product corresponds to the determinant of the matrix with the
      * two points as rows or columns*/
      return this.x.dup().multiply(other.y).subtract(this.y.dup().multiply(other.x));
    });
    _defineProperty(this, "transform", function (transMatrix) {
      if (transMatrix.length != 3) {
        console.log("Matrix seems to have the wrong dimension!");
        return;
      }
      let z = new _intadjoinsqrt.IntAdjoinSqrt2(1, 0);
      const copy = this.dup();
      this.x = copy.x.dup().multiply(transMatrix[0][0]);
      this.x.add(copy.y.dup().multiply(transMatrix[0][1]));
      this.x.add(z.dup().multiply(transMatrix[0][2]));
      this.y = copy.x.dup().multiply(transMatrix[1][0]);
      this.y.add(copy.y.dup().multiply(transMatrix[1][1]));
      this.y.add(z.dup().multiply(transMatrix[1][2]));
      const zCopy = z.dup();
      z = copy.x.dup().multiply(transMatrix[2][0]);
      z.add(copy.y.dup().multiply(transMatrix[2][1]));
      z.add(zCopy.dup().multiply(transMatrix[2][2]));
      if (_helpers.numberNEq(z, 1) && _helpers.numberNEq(z, 0)) {
        this.x.div(z);
        this.y.div(z);
      }
      return this;
    });
    _defineProperty(this, "translate", function (transX, transY) {
      const translationMatrix = [[new _intadjoinsqrt.IntAdjoinSqrt2(1, 0), new _intadjoinsqrt.IntAdjoinSqrt2(0, 0), transX], [new _intadjoinsqrt.IntAdjoinSqrt2(0, 0), new _intadjoinsqrt.IntAdjoinSqrt2(1, 0), transY], [new _intadjoinsqrt.IntAdjoinSqrt2(0, 0), new _intadjoinsqrt.IntAdjoinSqrt2(0, 0), new _intadjoinsqrt.IntAdjoinSqrt2(1, 0)]];
      return this.transform(translationMatrix);
    });
    _defineProperty(this, "rotate", function (angle) {
      /*Transform angle to that it falls in the interval [0;360]*/
      angle = _helpers.clipAngle(angle);
      let cos;
      let sin;
      /*Handle cases where the angle is a multiple of 45 degrees first*/
      /*If angle is not a multiple of 45 degrees*/
      if (angle % 45 != 0) {
        cos = new _intadjoinsqrt.IntAdjoinSqrt2(Math.cos(_helpers.toRadians(angle)), 0);
        sin = new _intadjoinsqrt.IntAdjoinSqrt2(Math.sin(_helpers.toRadians(angle)), 0);
      } else {
        /*Determine value of sin and cos*/
        if (angle % 90 != 0) {
          cos = new _intadjoinsqrt.IntAdjoinSqrt2(0, 0.5);
          sin = new _intadjoinsqrt.IntAdjoinSqrt2(0, 0.5);
        } else if (angle % 180 != 0) {
          cos = new _intadjoinsqrt.IntAdjoinSqrt2(0, 0);
          sin = new _intadjoinsqrt.IntAdjoinSqrt2(1, 0);
        } else {
          cos = new _intadjoinsqrt.IntAdjoinSqrt2(1, 0);
          sin = new _intadjoinsqrt.IntAdjoinSqrt2(0, 0);
        }
        /*Determine the sign of sin and cos*/
        if (angle > 180 && angle < 360) {
          sin.neg();
        }
        if (angle > 90 && angle < 270) {
          cos.neg();
        }
      }
      const rotationMatrix = [[cos, sin.dup().neg(), new _intadjoinsqrt.IntAdjoinSqrt2(0, 0)], [sin, cos, new _intadjoinsqrt.IntAdjoinSqrt2(0, 0)], [new _intadjoinsqrt.IntAdjoinSqrt2(0, 0), new _intadjoinsqrt.IntAdjoinSqrt2(0, 0), new _intadjoinsqrt.IntAdjoinSqrt2(1, 0)]];
      this.transform(rotationMatrix);
      return this;
    });
    _defineProperty(this, "scale", function (factor) {
      if (_helpers.numberEq(0, factor)) {
        console.log("Attempt to scale by 0!");
        /*Somehow this fixes strange Safari error ??*/
        console.log(JSON.stringify(this));
        return;
      }
      this.x.scale(factor);
      this.y.scale(factor);
      return this;
    });
    if (typeof x === 'undefined') {
      this.x = new _intadjoinsqrt.IntAdjoinSqrt2(0, 0);
    } else {
      this.x = x;
    }
    if (typeof y === 'undefined') {
      this.y = new _intadjoinsqrt.IntAdjoinSqrt2(0, 0);
    } else {
      this.y = y;
    }
  }
}
_defineProperty(Point, "comparePoints", function (pointA, pointB) {
  return pointA.compare(pointB);
});
_defineProperty(Point, "comparePointsYX", function (pointA, pointB) {
  return pointA.compareYX(pointB);
});
_defineProperty(Point, "closePoint", function (pointA, pointB, range) {
  return pointA.x.closeNumbers(pointB.x, range) && pointA.y.closeNumbers(pointB.y, range);
});
const relativeOrientation = function (pointA, pointB, pointC) {
  const determinant = pointA.dup().subtract(pointC).determinant(pointB.dup().subtract(pointC));
  if (determinant.isZero()) {
    return 0;
  } else {
    return determinant.toFloat() > 0 ? 1 : -1;
  }
};
const bothPointsMultipleTimes = function (pointArray, pointA, pointB) {
  const occurrenceA = [];
  const occurrenceB = [];
  for (let pointId = 0; pointId < pointArray.length; pointId++) {
    if (pointArray[pointId].eq(pointA)) {
      occurrenceA.push(pointId);
    }
    if (pointArray[pointId].eq(pointB)) {
      occurrenceB.push(pointId);
    }
  }
  return occurrenceA.length >= 2 && occurrenceB.length >= 2;
};

},{"./intadjoinsqrt2":"6Swgg","./helpers":"3Nu5P","@parcel/transformer-js/lib/esmodule-helpers.js":"7jqoH"}],"6Swgg":[function(require,module,exports) {
var _parcelHelpers = require("@parcel/transformer-js/lib/esmodule-helpers.js");
_parcelHelpers.defineInteropFlag(exports);
_parcelHelpers.export(exports, "IntAdjoinSqrt2", function () {
  return IntAdjoinSqrt2;
});
var _helpers = require("./helpers");
function _defineProperty(obj, key, value) {
  if ((key in obj)) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }
  return obj;
}
class IntAdjoinSqrt2 {
  constructor(coeffInt, coeffSqrt) {
    _defineProperty(this, "dup", function () {
      return new IntAdjoinSqrt2(this.coeffInt, this.coeffSqrt);
    });
    _defineProperty(this, "toFloat", function () {
      return this.coeffInt + this.coeffSqrt * Math.SQRT2;
    });
    _defineProperty(this, "eq", function (other) {
      if (_helpers.generating.val) {
        return this.coeffInt === other.coeffInt && this.coeffSqrt === other.coeffSqrt;
      } else {
        return _helpers.numberEq(this.coeffInt, other.coeffInt) && _helpers.numberEq(this.coeffSqrt, other.coeffSqrt);
      }
    });
    _defineProperty(this, "sameSign", function (other) {
      const zero = new IntAdjoinSqrt2(0, 0);
      return zero.compare(this) === zero.compare(other);
    });
    _defineProperty(this, "compare", function (other) {
      if (this.eq(other)) {
        return 0;
      } else {
        const floatThis = this.toFloat();
        const floatOther = other.toFloat();
        if (floatThis < floatOther) {
          return -1;
        } else {
          return 1;
        }
      }
    });
    _defineProperty(this, "distance", function (other) {
      const result = this.dup();
      result.subtract(other);
      return result.abs();
    });
    _defineProperty(this, "closeNumbers", function (other, range) {
      return _helpers.numberRange(this.toFloat(), other.toFloat(), range);
    });
    _defineProperty(this, "isZero", function () {
      if (_helpers.generating.val) {
        return this.coeffInt === 0 && this.coeffSqrt === 0;
      } else {
        return _helpers.numberEq(this.coeffInt, 0) && _helpers.numberEq(this.coeffSqrt, 0);
      }
    });
    _defineProperty(this, "add", function (other) {
      this.coeffInt += other.coeffInt;
      this.coeffSqrt += other.coeffSqrt;
      return this;
    });
    _defineProperty(this, "subtract", function (other) {
      this.coeffInt -= other.coeffInt;
      this.coeffSqrt -= other.coeffSqrt;
      return this;
    });
    _defineProperty(this, "multiply", function (other) {
      /*(a + bx)*(c + dx) = (ac + bdxx) + (ad + bc)*x where x = sqrt(2)*/
      const coeffIntCopy = this.coeffInt;
      this.coeffInt = coeffIntCopy * other.coeffInt + 2 * this.coeffSqrt * other.coeffSqrt;
      this.coeffSqrt = coeffIntCopy * other.coeffSqrt + this.coeffSqrt * other.coeffInt;
      return this;
    });
    _defineProperty(this, "div", function (other) {
      const denominator = other.coeffInt * other.coeffInt - 2 * other.coeffSqrt * other.coeffSqrt;
      if (_helpers.numberEq(denominator, 0)) {
        // console.log("Division by 0 is not possible!");
        return;
      }
      /*(a + bx)/(c + dx) = ((a + bx)*(c - dx))/((c + dx)*(c - dx)) with x = sqrt(2)
      * = (ac- 2bd)/(cc - ddxx) + (bc- ad)*x/(cc - ddxx)*/
      const coeffIntCopy = this.coeffInt;
      this.coeffInt = coeffIntCopy * other.coeffInt - 2 * this.coeffSqrt * other.coeffSqrt;
      this.coeffSqrt = this.coeffSqrt * other.coeffInt - coeffIntCopy * other.coeffSqrt;
      return this;
    });
    _defineProperty(this, "neg", function () {
      this.coeffInt = -this.coeffInt;
      this.coeffSqrt = -this.coeffSqrt;
      return this;
    });
    _defineProperty(this, "abs", function () {
      if (this.toFloat() < 0) {
        this.coeffInt = -this.coeffInt;
        this.coeffSqrt = -this.coeffSqrt;
      }
      return this;
    });
    _defineProperty(this, "scale", function (factor) {
      if (_helpers.numberEq(factor, 0)) {
        console.log("Scaling by 0 is not possible!");
        /*Somehow this fixes strange Safari error ??*/
        console.log(JSON.stringify(this));
        return;
      }
      this.coeffInt *= factor;
      this.coeffSqrt *= factor;
      return this;
    });
    this.coeffInt = coeffInt;
    this.coeffSqrt = coeffSqrt;
  }
}
_defineProperty(IntAdjoinSqrt2, "compareIntAdjoinSqrt2s", function (numberA, numberB) {
  return numberA.compare(numberB);
});
_defineProperty(IntAdjoinSqrt2, "IntAdjoinSqrt2Min", function (a, b) {
  const compare = a.compare(b);
  if (compare <= 0) {
    return a;
  } else {
    return b;
  }
});
_defineProperty(IntAdjoinSqrt2, "IntAdjoinSqrt2Max", function (a, b) {
  const compare = a.compare(b);
  if (compare >= 0) {
    return a;
  } else {
    return b;
  }
});

},{"./helpers":"3Nu5P","@parcel/transformer-js/lib/esmodule-helpers.js":"7jqoH"}],"3Nu5P":[function(require,module,exports) {
var _parcelHelpers = require("@parcel/transformer-js/lib/esmodule-helpers.js");
_parcelHelpers.defineInteropFlag(exports);
_parcelHelpers.export(exports, "generating", function () {
  return generating;
});
_parcelHelpers.export(exports, "evalVal", function () {
  return evalVal;
});
_parcelHelpers.export(exports, "toRadians", function () {
  return toRadians;
});
_parcelHelpers.export(exports, "toDegrees", function () {
  return toDegrees;
});
_parcelHelpers.export(exports, "clipAngle", function () {
  return clipAngle;
});
_parcelHelpers.export(exports, "numberEq", function () {
  return numberEq;
});
_parcelHelpers.export(exports, "numberRange", function () {
  return numberRange;
});
_parcelHelpers.export(exports, "numberNEq", function () {
  return numberNEq;
});
_parcelHelpers.export(exports, "crossProduct3D", function () {
  return crossProduct3D;
});
_parcelHelpers.export(exports, "shuffleArray", function () {
  return shuffleArray;
});
_parcelHelpers.export(exports, "eliminateDuplicates", function () {
  return eliminateDuplicates;
});
_parcelHelpers.export(exports, "arrayEq", function () {
  return arrayEq;
});
_parcelHelpers.export(exports, "numUniqueElements", function () {
  return numUniqueElements;
});
let generating = {
  val: true
};
let evalVal = false;
const toRadians = function (degrees) {
  return degrees * Math.PI / 180.0;
};
const toDegrees = function (radians) {
  return radians * 180.0 / Math.PI;
};
const clipAngle = function (angle) {
  if (angle < 0) {
    while (angle < 0) {
      angle += 360;
    }
  } else if (angle >= 360) {
    while (angle >= 360) {
      angle -= 360;
    }
  }
  return angle;
};
const numberEq = function (a, b) {
  return Math.abs(a - b) < 0.000000000001;
};
const numberRange = function (a, b, range) {
  return Math.abs(a - b) < range;
};
const numberNEq = function (a, b) {
  return !numberEq(a, b);
};
const crossProduct3D = function (a, b) {
  if (a.length != 3 || b.length != 3) {
    return [0, 0, 0];
  }
  let result = [];
  result[0] = a[1] * b[2] - a[2] * b[1];
  result[1] = a[2] * b[0] - a[0] * b[2];
  result[2] = a[0] * b[1] - a[1] * b[0];
  return result;
};
const shuffleArray = function (array) {
  let elementsLeft = array.length;
  let elementCopy, index;
  /*while there are still element left*/
  while (elementsLeft) {
    /*Pick one of the remaining elements (index between 0 and elementsLeft -1*/
    index = Math.floor(Math.random() * elementsLeft);
    elementsLeft--;
    /*Switch the chosen element with the one at index elementsLeft, this
    * results in filling the array with randomly chosen elements from the back*/
    elementCopy = array[elementsLeft];
    array[elementsLeft] = array[index];
    array[index] = elementCopy;
  }
  return array;
};
const eliminateDuplicates = function (array, compareFunction, keepDoubles) {
  array = array.sort(compareFunction);
  const newArray = [array[0]];
  for (let index = 1; index < array.length; index++) {
    newArray.push(array[index]);
    if (compareFunction(array[index], array[index - 1]) === 0) {
      newArray.pop();
      /*Throw the other part of the duplicate away as well*/
      if (!keepDoubles) {
        newArray.pop();
      }
    }
  }
  return newArray;
};
const arrayEq = function (arrayA, arrayB, compareFunction) {
  if (arrayA.length != arrayB.length) {
    return false;
  }
  arrayA = arrayA.slice(0).sort(compareFunction);
  arrayB = arrayB.slice(0).sort(compareFunction);
  for (let index = 0; index < arrayA.length; index++) {
    if (compareFunction(arrayA[index], arrayB[index]) != 0) {
      return false;
    }
  }
  return true;
};
const numUniqueElements = function (array, compareFunction) {
  const unique = eliminateDuplicates(array.slice(0), compareFunction, true);
  return unique.length;
};

},{"@parcel/transformer-js/lib/esmodule-helpers.js":"7jqoH"}],"7jqoH":[function(require,module,exports) {
"use strict";

exports.interopDefault = function (a) {
  return a && a.__esModule ? a : {
    default: a
  };
};

exports.defineInteropFlag = function (a) {
  Object.defineProperty(a, '__esModule', {
    value: true
  });
};

exports.exportAll = function (source, dest) {
  Object.keys(source).forEach(function (key) {
    if (key === 'default' || key === '__esModule') {
      return;
    } // Skip duplicate re-exports when they have the same value.


    if (key in dest && dest[key] === source[key]) {
      return;
    }

    Object.defineProperty(dest, key, {
      enumerable: true,
      get: function () {
        return source[key];
      }
    });
  });
  return dest;
};

exports.export = function (dest, destName, get) {
  Object.defineProperty(dest, destName, {
    enumerable: true,
    get: get
  });
};
},{}],"1Ps4L":[function(require,module,exports) {
var _parcelHelpers = require("@parcel/transformer-js/lib/esmodule-helpers.js");
_parcelHelpers.defineInteropFlag(exports);
_parcelHelpers.export(exports, "Tangram", function () {
  return Tangram;
});
_parcelHelpers.export(exports, "compareTangrams", function () {
  return compareTangrams;
});
var _point = require("./point");
var _intadjoinsqrt = require("./intadjoinsqrt2");
var _tan = require("./tan");
var _evaluation = require("./evaluation");
function _defineProperty(obj, key, value) {
  if ((key in obj)) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }
  return obj;
}
class Tangram {
  constructor(tans) {
    _defineProperty(this, "center", function () {
      const center = new _point.Point();
      const boundingBox = _tan.computeBoundingBox(this.tans, this.outline);
      center.x = boundingBox[0].dup().add(boundingBox[2]).scale(0.5);
      center.y = boundingBox[1].dup().add(boundingBox[3]).scale(0.5);
      return center;
    });
    _defineProperty(this, "positionCentered", function () {
      const center = new _point.Point(new _intadjoinsqrt.IntAdjoinSqrt2(30, 0), new _intadjoinsqrt.IntAdjoinSqrt2(30, 0));
      center.subtract(this.center());
      for (let tansId = 0; tansId < this.tans.length; tansId++) {
        this.tans[tansId].anchor.translate(center.x, center.y);
      }
      this.outline = _tan.computeOutline(this.tans, true);
    });
    _defineProperty(this, "toSVGOutline", function (elementName) {
      let pointId;
      const tangramSVG = document.createElementNS("http://www.w3.org/2000/svg", "g");
      const shape = document.createElementNS("http://www.w3.org/2000/svg", "path");
      /*Add each outline point to the path*/
      let pathdata = "M " + this.outline[0][0].toFloatX() + ", " + this.outline[0][0].toFloatY() + " ";
      for (pointId = 1; pointId < this.outline[0].length; pointId++) {
        pathdata += "L " + this.outline[0][pointId].toFloatX() + ", " + this.outline[0][pointId].toFloatY() + " ";
      }
      pathdata += "Z ";
      // Tangram Outline Color
      shape.setAttributeNS(null, "fill", '#666666');
      for (let outlineId = 1; outlineId < this.outline.length; outlineId++) {
        pathdata += "M " + this.outline[outlineId][0].toFloatX() + ", " + this.outline[outlineId][0].toFloatY() + " ";
        for (pointId = 1; pointId < this.outline[outlineId].length; pointId++) {
          pathdata += "L " + this.outline[outlineId][pointId].toFloatX() + ", " + this.outline[outlineId][pointId].toFloatY() + " ";
        }
        pathdata += "Z";
      }
      shape.setAttributeNS(null, "d", pathdata);
      /*Set fill-rule for correctly displayed holes*/
      shape.setAttributeNS(null, "fill-rule", "evenodd");
      tangramSVG.appendChild(shape);
      /*Test convex hull*/
      /*var allPoints = getAllPoints(this.tans);
      allPoints = allPoints.sort(comparePointsYX);
      var convexHull = this.evaluation.computeConvexHull(this.outline[0],allPoints[0]);
      var pathdataHull = "M " + convexHull[0].toFloatX() + ", " + convexHull[0].toFloatY() + " ";
      for (var i = 1; i < convexHull.length; i++) {
      pathdataHull += "L " + convexHull[i].toFloatX() + ", " + convexHull[i].toFloatY() + " ";
      }
      pathdataHull += "Z ";
      var hull = document.createElementNS("http://www.w3.org/2000/svg", "path");
      hull.setAttributeNS(null, "stroke", '#FF9900');
      hull.setAttributeNS(null, "stroke-width", '0.45');
      hull.setAttributeNS(null, "fill", 'none');
      hull.setAttributeNS(null, "d", pathdataHull);
      tangramSVG.appendChild(hull);*/
      /*Clear old content*/
      const element = document.getElementById(elementName);
      while (element.firstChild) {
        element.removeChild(element.firstChild);
      }
      /*Add new tangram*/
      element.appendChild(tangramSVG);
    });
    _defineProperty(this, "toSVGTans", function (elementName) {
      const tangramSVG = document.createElementNS("http://www.w3.org/2000/svg", "g");
      for (let i = 0; i < this.tans.length; i++) {
        const shape = document.createElementNS("http://www.w3.org/2000/svg", "polygon");
        shape.setAttributeNS(null, "points", this.tans[i].toSVG());
        shape.setAttributeNS(null, "fill", '#FF9900');
        shape.setAttributeNS(null, "stroke", "#3299BB");
        shape.setAttributeNS(null, "stroke-width", "0.05");
        tangramSVG.appendChild(shape);
      }
      document.getElementById(elementName).appendChild(tangramSVG);
    });
    this.tans = tans.sort(function (a, b) {
      return a.tanType - b.tanType;
    });
    /*Outline is an array of points describing the outline of the tangram*/
    this.outline = _tan.computeOutline(this.tans, true);
    if (typeof this.outline != 'undefined') {
      this.evaluation = new _evaluation.Evaluation(this.tans, this.outline);
    }
  }
}
const compareTangrams = function (tangramA, tangramB) {
  return tangramA.evaluation.getValue() - tangramB.evaluation.getValue();
};

},{"./point":"3thPn","./intadjoinsqrt2":"6Swgg","./tan":"59JXy","./evaluation":"2pFgu","@parcel/transformer-js/lib/esmodule-helpers.js":"7jqoH"}],"59JXy":[function(require,module,exports) {
var _parcelHelpers = require("@parcel/transformer-js/lib/esmodule-helpers.js");
_parcelHelpers.defineInteropFlag(exports);
_parcelHelpers.export(exports, "Tan", function () {
  return Tan;
});
_parcelHelpers.export(exports, "getAllPoints", function () {
  return getAllPoints;
});
_parcelHelpers.export(exports, "outlineArea", function () {
  return outlineArea;
});
_parcelHelpers.export(exports, "computeSegments", function () {
  return computeSegments;
});
_parcelHelpers.export(exports, "computeOutline", function () {
  return computeOutline;
});
_parcelHelpers.export(exports, "computeBoundingBox", function () {
  return computeBoundingBox;
});
_parcelHelpers.export(exports, "containsPoint", function () {
  return containsPoint;
});
var _point = require("./point");
var _intadjoinsqrt = require("./intadjoinsqrt2");
var _helpers = require("./helpers");
var _directions = require("./directions");
var _lineSegement = require("./lineSegement");
function _defineProperty(obj, key, value) {
  if ((key in obj)) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }
  return obj;
}
/** Class for a Tan*/
const areaSum = new _intadjoinsqrt.IntAdjoinSqrt2(576, 0);
class Tan {
  constructor(tanType, anchor, orientation) {
    _defineProperty(this, "dup", function () {
      return new Tan(this.tanType, this.anchor.dup(), this.orientation);
    });
    _defineProperty(this, "area", function () {
      const areas = [96, 48, 24, 48, 48, 48];
      return areas[this.tanType];
    });
    _defineProperty(this, "getPoints", function () {
      if (_helpers.generating.val && typeof this.points != 'undefined') {
        return this.points;
      }
      const points = [];
      points[0] = this.anchor.dup();
      const directions = _directions.Directions[this.tanType][this.orientation];
      for (let dirId = 0; dirId < directions.length; dirId++) {
        const current = this.anchor.dup();
        current.add(directions[dirId]);
        points[dirId + 1] = current;
      }
      return points;
    });
    _defineProperty(this, "getSegments", function () {
      let pointId;
      if (_helpers.generating.val && typeof this.segments != 'undefined') {
        return this.segments;
      }
      const segments = [];
      const points = this.getPoints();
      for (pointId = 0; pointId < points.length - 1; pointId++) {
        segments[pointId] = new _lineSegement.LineSegment(points[pointId], points[pointId + 1]);
      }
      segments[pointId] = new _lineSegement.LineSegment(points[pointId], points[0]);
      return segments;
    });
    _defineProperty(this, "center", function () {
      return this.anchor.dup().add(_directions.InsideDirections[this.tanType][this.orientation][0]);
    });
    _defineProperty(this, "getInsidePoints", function () {
      if (_helpers.generating.val && typeof this.insidePoints != 'undefined') {
        return this.insidePoints;
      }
      const insidePoints = [];
      const numInsidePoints = _directions.InsideDirections[this.tanType][this.orientation].length;
      for (let pointId = 0; pointId < numInsidePoints; pointId++) {
        insidePoints.push(this.anchor.dup().add(_directions.InsideDirections[this.tanType][this.orientation][pointId]));
      }
      return insidePoints;
    });
    _defineProperty(this, "toSVG", function () {
      const a = Math.random();
      let points = this.getPoints();
      let pointsString = "";
      for (let i = 0; i < points.length; i++) {
        pointsString += points[i].toFloatX() + ", " + points[i].toFloatY() + " ";
      }
      return pointsString;
    });
    this.tanType = tanType;
    this.anchor = anchor;
    this.orientation = orientation;
    if (!(typeof _helpers.generating.val === 'undefined') && _helpers.generating) {
      this.points = this.getPoints();
      this.segments = this.getSegments();
      this.insidePoints = this.getInsidePoints();
    }
  }
}
const getAllPoints = function (tans) {
  let points = [];
  /*Add points of each tan*/
  for (let i = 0; i < tans.length; i++) {
    const currentPoints = tans[i].getPoints();
    points = points.concat(currentPoints);
  }
  /*Eliminate duplicates*/
  points = _helpers.eliminateDuplicates(points, _point.Point.comparePoints, true);
  return points;
};
const outlineArea = function (outline) {
  let pointId;
  const area = new _intadjoinsqrt.IntAdjoinSqrt2(0, 0);
  for (pointId = 0; pointId < outline.length - 1; pointId++) {
    /*Calculate the cross product of consecutive points. This corresponds
    * to twice the area of the triangle (0,0) - vertices[p] -
    * vertices[(p+1)%num_vertices]. This area is positive if the vertices
    * of that triangle are arranged in a counterclockwise order and negative
    * if the vertices are arranged in a clockwise order
    */
    area.add(outline[pointId].determinant(outline[pointId + 1]));
  }
  area.add(outline[pointId].determinant(outline[0]));
  area.abs();
  return area.scale(0.5);
};
const tanSumArea = function (tans) {
  let area = 0;
  for (let tanId = 0; tanId < tans.length; tanId++) {
    area += tans[tanId].area();
  }
  return area;
};
/*Check if a given outline contains all the given points*/
const outlineContainsAll = function (outline, allPoints) {
  for (let pointId = 0; pointId < allPoints.length; pointId++) {
    const contains = containsPoint(outline, allPoints[pointId]);
    if (contains === -1) {
      return false;
    }
  }
  return true;
};
const computeSegments = function (allPoints, tans) {
  /*First calculate all line segments involved in the tangram. These line
  * segments are the segments of each individual tan however split up at points
  * from other tans*/
  let allSegments = [];
  let currentSegments;
  for (let tanId = 0; tanId < tans.length; tanId++) {
    /*For the line segment of each tan, check if there exists points from
    * other tans on the segment, if that is the case, split the segment at
    * these points*/
    currentSegments = tans[tanId].getSegments();
    for (let segmentId = 0; segmentId < currentSegments.length; segmentId++) {
      const splitPoints = [];
      for (let pointId = 0; pointId < allPoints.length; pointId++) {
        if (currentSegments[segmentId].onSegment(allPoints[pointId])) {
          splitPoints.push(allPoints[pointId]);
        }
      }
      allSegments = allSegments.concat(currentSegments[segmentId].split(splitPoints));
    }
  }
  /*Throw out all line segments that occur twice (they will not be part of
  * the outline anyways*/
  allSegments = _helpers.eliminateDuplicates(allSegments, _lineSegement.LineSegment.compareLineSegments, false);
  return allSegments;
};
/*Find segment with minimum angle to a given lastSegment*/
const findMinSegments = function (lastSegment, segments) {
  let minAngle = 360;
  let minIndex = -1;
  for (let segmentId = 0; segmentId < segments.length; segmentId++) {
    const currentAngle = segments[segmentId].angleTo(lastSegment);
    if (currentAngle < minAngle) {
      minIndex = segmentId;
      minAngle = currentAngle;
    }
  }
  return [minIndex, minAngle];
};
/*Find segment with maximum angle to a given lastSegment*/
const findMaxSegments = function (lastSegment, segments) {
  let maxAngle = 0;
  let maxIndex = -1;
  for (let segmentId = 0; segmentId < segments.length; segmentId++) {
    const currentAngle = segments[segmentId].angleTo(lastSegment);
    if (currentAngle > maxAngle) {
      maxIndex = segmentId;
      maxAngle = currentAngle;
    }
  }
  return [maxIndex, maxAngle];
};
const computeOutlinePart = function (allPoints, allSegments, angleFinder, hole, reduce) {
  if (allPoints.length === 0 || allSegments.length === 0) {
    return;
  }
  allPoints.sort(_point.Point.comparePoints);
  let lastPoint = allPoints[0];
  const helperPoint = lastPoint.dup();
  /*First last segment is a downwards horizontal segment*/
  helperPoint.subtract(new _point.Point(new _intadjoinsqrt.IntAdjoinSqrt2(0, 0), new _intadjoinsqrt.IntAdjoinSqrt2(1, 0)));
  const outline = [];
  outline.push(lastPoint);
  let lastSegment = new _lineSegement.LineSegment(helperPoint, lastPoint);
  let firstSegment = true;
  do {
    /*Get all segments that are adjacent to the lastPoint and find the segment
    * with maximum or minimum angle*/
    const currentSegments = allSegments.filter(function (element) {
      return !lastSegment.eq(element) && (element.point1.eq(lastPoint) || element.point2.eq(lastPoint));
    });
    let foundAngle;
    /*On the first segment, always use the segment with maximum angle, so
    * that all outline parts are traversed anti-clockwise*/
    if (firstSegment) {
      foundAngle = findMaxSegments(lastSegment, currentSegments);
    } else {
      foundAngle = angleFinder(lastSegment, currentSegments);
    }
    const index = foundAngle[0];
    const angle = foundAngle[1];
    if (index === -1) {
      break;
    }
    /*If the found segment continues in the same direction, remove the last
    * point, since it provides no additional information - taken out since
    * this complicates computation in evaluation*/
    if (angle === 180 && !firstSegment && reduce) {
      outline.pop();
    }
    /*Add the other point of the found segment to the outline*/
    if (currentSegments[index].point1.eq(lastPoint)) {
      outline.push(currentSegments[index].point2);
      lastPoint = currentSegments[index].point2;
    } else {
      outline.push(currentSegments[index].point1);
      lastPoint = currentSegments[index].point1;
    }
    lastSegment = currentSegments[index];
    allSegments = allSegments.filter(function (element) {
      return !lastSegment.eq(element);
    });
    if (firstSegment) {
      firstSegment = false;
    }
  } while (!lastPoint.eq(allPoints[0]) || !outlineContainsAll(outline, allPoints) && !hole);
  /*When the last point is equal to the first it can be deleted*/
  outline.pop();
  return [outline, allSegments];
};
const computeHole = function (allPoints, allSegments, reduce) {
  const remainingPoints = [];
  if (allPoints.length === 0 || allSegments.length === 0) {
    return;
  }
  /*Filter out all points and segment that cannot be part of a closed sequence
  * of line segments anymore (all holes consist of such a sequence*/
  let numPointsBefore = allSegments.length * 2;
  let numPointsAfter = 0;
  while (numPointsBefore != numPointsAfter) {
    numPointsBefore = allSegments.length * 2;
    for (let segmentsId = 0; segmentsId < allSegments.length; segmentsId++) {
      remainingPoints.push(allSegments[segmentsId].point1);
      remainingPoints.push(allSegments[segmentsId].point2);
    }
    /*Throw out segments where the endpoint occurs just once*/
    allSegments = allSegments.filter(function (element) {
      return _point.bothPointsMultipleTimes(remainingPoints, element.point1, element.point2);
    });
    /*Number of Points to consider changed if numPointsAfter is smaller
    * before*/
    numPointsAfter = allSegments.length * 2;
  }
  allPoints = _helpers.eliminateDuplicates(remainingPoints, _point.Point.comparePoints, true);
  /*Use a minimum angle for holes*/
  return computeOutlinePart(allPoints, allSegments, findMinSegments, true, reduce);
};
const computeOutline = function (tans, reduce) {
  /*First calculate all line segments involved in the tangram. These line
  * segments are the segments of each individual tan however split up at points
  * from other tans*/
  const outline = [];
  let outlineId = 0;
  const allPoints = getAllPoints(tans);
  let allSegments = computeSegments(allPoints, tans);
  let outlinePart = computeOutlinePart(allPoints, allSegments, findMaxSegments, false, reduce);
  outline[outlineId] = outlinePart[0];
  allSegments = outlinePart[1];
  const area = outlineArea(outline[0]);
  /*Compute possible holes*/
  while (!area.eq(areaSum) && area.toFloat() > 576 || !outlineContainsAll(outline[0], allPoints)) {
    outlineId++;
    outlinePart = computeHole(allPoints, allSegments, findMinSegments);
    if (typeof outlinePart === 'undefined') {
      /*Occurs for tangrams that consists of not connected, thus should
      * only occur when placing tans, and the result is not connected yet*/
      return;
    }
    outline[outlineId] = outlinePart[0];
    allSegments = outlinePart[1];
    area.subtract(outlineArea(outline[outlineId]));
  }
  return outline;
};
const computeBoundingBox = function (tans, outline) {
  if (typeof outline === "undefined") {
    outline = getAllPoints(tans);
  } else {
    outline = outline[0];
  }
  let minX = new _intadjoinsqrt.IntAdjoinSqrt2(100, 0);
  let minY = new _intadjoinsqrt.IntAdjoinSqrt2(100, 0);
  let maxX = new _intadjoinsqrt.IntAdjoinSqrt2(-100, 0);
  let maxY = new _intadjoinsqrt.IntAdjoinSqrt2(-100, 0);
  /*Find min and max x and y coordinates*/
  for (let pointId = 0; pointId < outline.length; pointId++) {
    const currentX = outline[pointId].x;
    const currentY = outline[pointId].y;
    if (currentX.compare(minX) < 0) minX = currentX;
    if (currentY.compare(minY) < 0) minY = currentY;
    if (currentX.compare(maxX) > 0) maxX = currentX;
    if (currentY.compare(maxY) > 0) maxY = currentY;
  }
  return [minX, minY, maxX, maxY];
};
const containsPoint = function (outline, point) {
  /*Compute the winding number for the given point and the polygon, which
  * counts how often the polygon "winds" around the point. The point lies
  * outside, only when the winding number is 0*/
  let winding = 0;
  for (let pointId = 0; pointId < outline.length; pointId++) {
    const firstPoint = outline[pointId];
    const secondPoint = pointId === outline.length - 1 ? outline[0] : outline[pointId + 1];
    /*Check each segment for containment*/
    if (point.eq(firstPoint) || point.eq(secondPoint) || new _lineSegement.LineSegment(firstPoint, secondPoint).onSegment(point)) {
      return 0;
    }
    /*Line segments are only considered if they are either pointing upward or
    * downward (therefore excluding horizontal lines) and if the intersection
    * point is strictly to the right of the point, for upwards segments,
    * this means that the point must lie to the left of the segment for downwards
    * segments, this means that the point must lie to the right of the segment
    * (when looking into the segment direction)*/
    if (outline[pointId].y.compare(point.y) <= 0) {
      /*Upwards edge*/
      if (secondPoint.y.compare(point.y) === 1 && _point.relativeOrientation(secondPoint, point, firstPoint) > 0) {
        winding++;
      }
    } else {
      /*Downwards edge*/
      if (secondPoint.y.compare(point.y) <= 0 && _point.relativeOrientation(secondPoint, point, firstPoint) < 0) {
        winding--;
      }
    }
  }
  return winding === 0 ? -1 : 1;
};

},{"./point":"3thPn","./intadjoinsqrt2":"6Swgg","./helpers":"3Nu5P","./directions":"4qo9l","./lineSegement":"4rt7O","@parcel/transformer-js/lib/esmodule-helpers.js":"7jqoH"}],"4rt7O":[function(require,module,exports) {
var _parcelHelpers = require("@parcel/transformer-js/lib/esmodule-helpers.js");
_parcelHelpers.defineInteropFlag(exports);
_parcelHelpers.export(exports, "LineSegment", function () {
  return LineSegment;
});
var _point = require("./point");
function _defineProperty(obj, key, value) {
  if ((key in obj)) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }
  return obj;
}
class LineSegment {
  constructor(point1, point2) {
    _defineProperty(this, "dup", function () {
      return new LineSegment(this.point1.dup(), this.point2.dup());
    });
    _defineProperty(this, "length", function () {
      return this.point1.distance(this.point2);
    });
    _defineProperty(this, "direction", function () {
      return this.point2.dup().subtract(this.point1);
    });
    _defineProperty(this, "lineParameters", function () {
      /*For each point on a line segment the following equation holds: point_1 +
      * t*(point_2 - point_1). The points on the segment have t between 0 and 1,
      * for t outside that interval, the point lies only on the line formed by the
      * connection of the two points, not on the segment itself. By using one
      * equation for both x- and y-coordinates, solving for t and than setting the
      * two equations equal, the calculation below for the line parameters can be
      * derived. Cases where the line is parallel to either the x- or y-axis have
      * to be treated specially (as they would to lead to e.g. division by 0)*/
      const parameters = [];
      if (this.point1.x.eq(this.point2.x)) {
        parameters[0] = 1.0;
        parameters[1] = 0.0;
        parameters[2] = this.point1.x.dup().neg().toFloat();
      } else if (this.point1.y.eq(this.point2.y)) {
        parameters[0] = 0.0;
        parameters[1] = 1.0;
        parameters[2] = this.point1.y.dup().neg().toFloat();
      } else {
        /*Comes from line equations using points -> solve for t, set equal*/
        const direction = this.direction();
        parameters[0] = direction.toFloatX() / direction.toFloatY();
        parameters[1] = -1.0;
        parameters[2] = this.point2.determinant(this.point1).toFloat() / direction.toFloatX();
      }
      return parameters;
    });
    _defineProperty(this, "eq", function (other) {
      return this.point1.eq(other.point1) && this.point2.eq(other.point2) || this.point2.eq(other.point1) && this.point1.eq(other.point2);
    });
    _defineProperty(this, "compare", function (other) {
      const point1Compare = this.point1.compare(other.point1);
      const point2Compare = this.point2.compare(other.point2);
      if (point1Compare === 'undefined' || point2Compare === 'undefined') {
        console.log("Comparison between the segments is not possible!");
        return;
      }
      if (point1Compare != 0) {
        return point1Compare;
      } else {
        return point2Compare;
      }
    });
    _defineProperty(this, "split", function (splitPoints) {
      /*If no points are given, return this segment in an array*/
      if (splitPoints.length === 0) {
        return [this];
      }
      /*Sort points along segment*/
      splitPoints = splitPoints.sort(_point.Point.comparePoints);
      /*Create new segments - staring from the first point of this segment, all
      * following segments go from the last process point to the next split point*/
      const segments = [];
      segments[0] = new LineSegment(this.point1, splitPoints[0]);
      let i;
      for (i = 1; i < splitPoints.length; i++) {
        segments[i] = new LineSegment(splitPoints[i - 1], splitPoints[i]);
      }
      segments[i] = new LineSegment(splitPoints[i - 1], this.point2);
      return segments;
    });
    _defineProperty(this, "projectedParameter", function (point) {
      if (this.point1.eq(this.point2)) {
        return 1;
      }
      /*Projection of point onto line is the same as projection of the vector start
      * to point onto the direction vector. This projection vector p is parallel
      * to the direction vector (thus just a scaled version of it) => p = s *
      * normalized_direction. s is equal to the length of the vector to project
      * times the cos of the angle the two vectors enclose. This again is equal
      * to the dot product of the vector to project and the normalized other vector,
      * leading to the calculation below*/
      const startToPoint = point.dup().subtract(this.point1);
      const direction = this.direction();
      return startToPoint.dotProduct(direction).toFloat() / direction.dotProduct(direction).toFloat();
    });
    _defineProperty(this, "onSegment", function (point) {
      if (point.eq(this.point1) || point.eq(this.point2) || this.point1.eq(this.point2)) {
        return false;
      }
      /*Calculate twice the area of the triangle of the two segment points and the
      * given point, if the area is 0, the three points are collinear*/
      if (_point.relativeOrientation(this.point1, this.point2, point) === 0) {
        const parameter = this.projectedParameter(point);
        /*Check if parameter is so that the point lies within the two segment points*/
        return parameter >= 0 && parameter <= 1;
      }
      return false;
    });
    _defineProperty(this, "onSegmentIncludingEndpoints", function (point) {
      if (point.eq(this.point1) || point.eq(this.point2) || this.point1.eq(this.point2)) {
        return true;
      }
      /*Calculate twice the area of the triangle of the two segment points and the
      * given point, if the area is 0, the three points are collinear*/
      if (_point.relativeOrientation(this.point1, this.point2, point) === 0) {
        const parameter = this.projectedParameter(point);
        /*Check if parameter is so that the point lies within the two segment points*/
        return parameter >= 0 && parameter <= 1;
      }
      return false;
    });
    _defineProperty(this, "intersectsOrientations", function (other) {
      /*Find the four relative orientations for all combinations of one line segments
      * and one point from the respective other line segment*/
      const orient1 = _point.relativeOrientation(this.point1, this.point2, other.point1);
      const orient2 = _point.relativeOrientation(this.point1, this.point2, other.point2);
      const orient3 = _point.relativeOrientation(other.point1, other.point2, this.point1);
      const orient4 = _point.relativeOrientation(other.point1, other.point2, this.point2);
      /*The lines intersect if the points from one line segments do not lie on the
      * same side of the other line segment (and the other way around)*/
      return orient1 != orient2 && orient3 != orient4;
    });
    _defineProperty(this, "intersectsIncludingSegment", function (other) {
      if (this.point1.eq(other.point1) || this.point2.eq(other.point1) || this.point1.eq(other.point2) || this.point2.eq(other.point2)) {
        return false;
      }
      return this.intersectsOrientations(other);
    });
    _defineProperty(this, "intersects", function (other) {
      /*First check if any of the endpoints are contained in the respective other
      * segment*/
      if (this.onSegmentIncludingEndpoints(other.point1) || this.onSegmentIncludingEndpoints(other.point2) || other.onSegmentIncludingEndpoints(this.point1) || other.onSegmentIncludingEndpoints(this.point2)) {
        return false;
      }
      return this.intersectsOrientations(other);
    });
    _defineProperty(this, "angleTo", function (other) {
      /*Find common endpoint and calculate direction vectors from the common point
      * to two other points*/
      let thisDirection;
      let otherDirection;
      if (this.point1.eq(other.point1)) {
        thisDirection = this.direction();
        otherDirection = other.direction();
      } else if (this.point1.eq(other.point2)) {
        thisDirection = this.direction();
        otherDirection = other.direction().scale(-1);
      } else if (this.point2.eq(other.point1)) {
        thisDirection = this.direction().scale(-1);
        otherDirection = other.direction();
      } else if (this.point2.eq(other.point2)) {
        thisDirection = this.direction().scale(-1);
        otherDirection = other.direction().scale(-1);
      } else {
        /*No common point*/
        return;
      }
      /*Angle between those is Angle between the segments*/
      return thisDirection.angleTo(otherDirection);
    });
    if (point1 === 'undefined') {
      this.point1 = new _point.Point();
    } else {
      this.point1 = point1;
    }
    if (point2 === 'undefined') {
      this.point2 = new _point.Point();
    } else {
      this.point2 = point2;
    }
    /*Order the points so that the point with lower x and lower y values is
    * saved in point1*/
    if (!this.point1.isZero() && !this.point2.isZero() || this.point2.isZero() && !this.point1.isZero()) {
      const compare = this.point1.compare(this.point2);
      if (compare === 1) {
        const point1Copy = this.point1;
        this.point1 = this.point2;
        this.point2 = point1Copy;
      }
    }
  }
}
_defineProperty(LineSegment, "compareLineSegments", function (segmentA, segmentB) {
  return segmentA.compare(segmentB);
});

},{"./point":"3thPn","@parcel/transformer-js/lib/esmodule-helpers.js":"7jqoH"}],"2pFgu":[function(require,module,exports) {
var _parcelHelpers = require("@parcel/transformer-js/lib/esmodule-helpers.js");
_parcelHelpers.defineInteropFlag(exports);
_parcelHelpers.export(exports, "Evaluation", function () {
  return Evaluation;
});
var _helpers = require("./helpers");
var _tan = require("./tan");
var _intadjoinsqrt = require("./intadjoinsqrt2");
var _point = require("./point");
var _lineSegement = require("./lineSegement");
require("../options/options-storage");
function _defineProperty(obj, key, value) {
  if ((key in obj)) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }
  return obj;
}
const evaluationMode = Math.floor(Math.random() * 5);
const faculty = [1, 1, 2, 6, 24, 120, 720, 5040, 40320];
class Evaluation {
  constructor(_tans, _outline) {
    _defineProperty(this, "getValue", async function (mode) {
      if (typeof mode === 'undefined') {
        mode = 5;
      }
      let evaluation;
      switch (evaluationMode) {
        case 0:
          /*Order according to a high convex percentage*/
          evaluation = 1.0 - this.convexPercentage;
          break;
        case 1:
          /*Order according to a low number of outline vertices*/
          evaluation = this.outlineVertices;
          break;
        case 2:
          /*Order according to a low number of outer Outline vertices*/
          evaluation = this.outerOutlineVertices;
          break;
        case 3:
          /*Order according to a small perimeter*/
          evaluation = this.perimeter;
          break;
        case 4:
          /*Order according to a high number of matched Vertices*/
          evaluation = -this.matchedVertices;
          break;
        case 5:
          /*Order according to both a low number of outer outline vertices
          * and a high convex percentage*/
          evaluation = (this.outerOutlineVertices - 3) / 26 + 1.0 - this.convexPercentage;
          break;
        default:
          evaluation = 0;
      }
      return evaluation;
    });
    _defineProperty(this, "computeConvexHullLess3Points", function (points) {
      if (points.length <= 1) {
        return points;
      }
      if (points[0].eq(points[1])) {
        points.pop();
      }
      return points;
    });
    _defineProperty(this, "computeConvexHull", function (points, upperLeft) {
      let pointId;
      if (points.length <= 2) {
        return this.computeConvexHullLess3Points(points);
      }
      /*Sort all points according to their polar angle to the most upper left most point*/
      points = points.sort(function (pointA, pointB) {
        const angleA = _helpers.clipAngle(pointA.dup().subtract(upperLeft).angle());
        var angleB = _helpers.clipAngle(pointB.dup().subtract(upperLeft).angle());
        /*Put the one with the smaller angle first, if the angle is the same, put
        * the one with the smaller distance to*/
        const equal = _helpers.numberEq(angleA, angleB);
        const distanceA = pointA.distance(upperLeft);
        const distanceB = pointB.distance(upperLeft);
        if (equal && _helpers.numberEq(distanceA, distanceB)) {
          return 0;
        } else if (!equal && angleA < angleB || equal && distanceA < distanceB) {
          return -1;
        } else {
          return 1;
        }
      });
      const filteredPoints = [points[0]];
      /*Remove all points with the same polar angle (except the one furthest away
      * from upperLeft*/
      for (pointId = 1; pointId < points.length - 1; pointId++) {
        filteredPoints.push(points[pointId]);
        if (_helpers.numberEq(points[pointId].dup().subtract(upperLeft).angle(), points[pointId + 1].dup().subtract(upperLeft).angle())) {
          filteredPoints.pop();
        }
      }
      filteredPoints.push(points[pointId]);
      if (filteredPoints.length <= 2) {
        return this.computeConvexHullLess3Points(filteredPoints);
      }
      const convexHull = [];
      convexHull.push(filteredPoints[0]);
      convexHull.push(filteredPoints[1]);
      /*Check if adding the next point leads to a concave path (last added point
      * is left of segment between the second to last added point and the new point*/
      for (pointId = 2; pointId < filteredPoints.length; pointId++) {
        while (convexHull.length > 1 && _point.relativeOrientation(convexHull[convexHull.length - 1], filteredPoints[pointId], convexHull[convexHull.length - 2]) <= 0) {
          convexHull.pop();
        }
        convexHull.push(filteredPoints[pointId]);
      }
      return convexHull;
    });
    _defineProperty(this, "horizontalCompare", function (center) {
      return function (pointA, pointB) {
        const distanceA = pointA.y.distance(center.y);
        const distanceB = pointB.y.distance(center.y);
        const compareDistance = distanceA.compare(distanceB);
        if (compareDistance === 0) {
          return pointA.x.compare(pointB.x);
        } else {
          return compareDistance;
        }
      };
    });
    _defineProperty(this, "verticalCompare", function (center) {
      return function (pointA, pointB) {
        const distanceA = pointA.x.distance(center.x);
        const distanceB = pointB.x.distance(center.x);
        const compareDistance = distanceA.compare(distanceB);
        if (compareDistance === 0) {
          return pointA.y.compare(pointB.y);
        } else {
          return compareDistance;
        }
      };
    });
    _defineProperty(this, "computeEvaluation", function (tans, outline) {
      let outlineId;
      let outerPointId;
      let pointId;
      /*Number of vertices in the outer outline is given by the first outline in
      * the outline array, this counts vertices that occur multiple times also
      * multiple times*/
      this.outerOutlineVertices = outline[0].length;
      /*If there are holes, they are saved in the outline array starting at index
      * 1, if there are none, the length of the outline array is 1*/
      this.numHoles = outline.length - 1;
      for (outlineId = 0; outlineId < outline.length; outlineId++) {
        if (outlineId != 0) {
          this.holeArea += _tan.outlineArea(outline[outlineId]).toFloat();
          this.holeVertices += outline[outlineId].length;
        }
        this.outlineVertices += outline[outlineId].length;
      }
      /*Longest and shortest edge in the outer outline*/
      this.longestEdge = -1;
      this.shortestEdge = 60;
      let currentEdge;
      for (outerPointId = 0; outerPointId < outline[0].length; outerPointId++) {
        if (outerPointId != outline[0].length - 1) {
          currentEdge = outline[0][outerPointId].distance(outline[0][outerPointId + 1]);
        } else {
          currentEdge = outline[0][outerPointId].distance(outline[0][0]);
        }
        if (currentEdge > this.longestEdge) {
          this.longestEdge = currentEdge;
        }
        if (currentEdge < this.shortestEdge) {
          this.shortestEdge = currentEdge;
        }
        this.perimeter += currentEdge;
      }
      const unreducedOutline = _tan.computeOutline(tans, false)[0];
      for (outerPointId = 0; outerPointId < unreducedOutline[0].length; outerPointId++) {
        if (unreducedOutline[outerPointId].eq(unreducedOutline[outerPointId + 1])) {
          this.hangingPieces++;
        }
      }
      for (outlineId = 1; outlineId < unreducedOutline.length; outlineId++) {
        let innerTouch = false;
        for (let innerPointId = 0; innerPointId < unreducedOutline[outlineId].length; innerPointId++) {
          for (outerPointId = 0; outerPointId < unreducedOutline[0].length; outerPointId++) {
            innerTouch = innerTouch || unreducedOutline[0][outerPointId].eq(unreducedOutline[outlineId][innerPointId]);
          }
          if (innerTouch) {
            break;
          }
        }
        switch (this.holeType) {
          case 0:
            if (innerTouch) {
              this.holeType = 2;
            } else {
              this.holeType = 1;
            }
            break;
          case 1:
            if (innerTouch) {
              this.holeType = 3;
            }
            break;
          case 2:
            if (!innerTouch) {
              this.holeType = 3;
            }
            break;
          default:
            break;
        }
      }
      const boundingBox = _tan.computeBoundingBox(tans, outline);
      this.rangeX = boundingBox[2].dup().subtract(boundingBox[0]).toFloat();
      this.rangeY = boundingBox[3].dup().subtract(boundingBox[1]).toFloat();
      const center = new _point.Point();
      center.x = boundingBox[0].dup().add(boundingBox[2]).scale(0.5);
      center.y = boundingBox[1].dup().add(boundingBox[3]).scale(0.5);
      const upperPoints = [];
      const lowerPoints = [];
      const leftPoints = [];
      const rightPoints = [];
      for (outerPointId = 0; outerPointId < outline[0].length; outerPointId++) {
        const compareX = outline[0][outerPointId].x.compare(center.x);
        const compareY = outline[0][outerPointId].y.compare(center.y);
        if (compareX < 0) {
          leftPoints.push(outline[0][outerPointId]);
        } else if (compareX > 0) {
          rightPoints.push(outline[0][outerPointId]);
        }
        if (compareY < 0) {
          upperPoints.push(outline[0][outerPointId]);
        } else if (compareY > 0) {
          lowerPoints.push(outline[0][outerPointId]);
        }
      }
      upperPoints.sort(this.horizontalCompare(center));
      lowerPoints.sort(this.horizontalCompare(center));
      leftPoints.sort(this.verticalCompare(center));
      rightPoints.sort(this.verticalCompare(center));
      let symmetryReject = false;
      if (upperPoints.length == lowerPoints.length) {
        for (pointId = 0; pointId < upperPoints.length; pointId++) {
          if (!upperPoints[pointId].x.eq(lowerPoints[pointId].x) || !upperPoints[pointId].y.distance(center.y).eq(lowerPoints[pointId].y.distance(center.y))) {
            symmetryReject = true;
            break;
          }
        }
      } else {
        symmetryReject = true;
      }
      if (!symmetryReject) {
        this.symmetry++;
      }
      symmetryReject = false;
      if (leftPoints.length == rightPoints.length) {
        for (pointId = 0; pointId < leftPoints.length; pointId++) {
          if (!leftPoints[pointId].y.eq(rightPoints[pointId].y) || !leftPoints[pointId].x.distance(center.x).eq(rightPoints[pointId].x.distance(center.x))) {
            symmetryReject = true;
            break;
          }
        }
      } else {
        symmetryReject = true;
      }
      if (!symmetryReject) {
        this.symmetry++;
      }
      /*Similar to segments computation in outline computation*/
      const allPoints = _tan.getAllPoints(tans);
      const occurrences = [];
      for (pointId = 0; pointId < allPoints.length; pointId++) {
        occurrences.push(0);
      }
      let allSegments = [];
      let currentSegments;
      let currentPoints;
      for (let tanId = 0; tanId < tans.length; tanId++) {
        /*For the line segment of each tan, check if there exist points from
        * other tans on the segment, if that is the case, split the segment at
        * these points*/
        currentSegments = tans[tanId].getSegments();
        for (let segmentId = 0; segmentId < currentSegments.length; segmentId++) {
          const splitPoints = [];
          for (pointId = 0; pointId < allPoints.length; pointId++) {
            if (currentSegments[segmentId].onSegment(allPoints[pointId])) {
              splitPoints.push(allPoints[pointId]);
            }
            if (currentSegments[segmentId].point1.eq(allPoints[pointId]) || currentSegments[segmentId].point2.eq(allPoints[pointId])) {
              occurrences[pointId]++;
            }
          }
          allSegments = allSegments.concat(currentSegments[segmentId].split(splitPoints));
        }
      }
      /*Count pairs of points that coincide*/
      for (pointId = 0; pointId < allPoints.length; pointId++) {
        occurrences[pointId] /= 2;
        if (occurrences[pointId] > 1) {
          this.matchedVertices += faculty[occurrences[pointId] - 1];
        }
      }
      const numSegmentsBefore = allSegments.length;
      /*Throw out all line segments that occur twice*/
      allSegments = _helpers.eliminateDuplicates(allSegments, _lineSegement.LineSegment.compareLineSegments, false);
      this.matchedEdges = (numSegmentsBefore - allSegments.length) / 2;
      const convexHull = this.computeConvexHull(outline[0], allPoints.sort(_intadjoinsqrt.IntAdjoinSqrt2.comparePointsYX)[0]);
      this.convexHullArea = _tan.outlineArea(convexHull).toFloat();
      this.convexPercentage = 576 / this.convexHullArea;
    });
    /*Vertices of the whole outline: between 3 and 29 (23+6))*/
    this.outlineVertices = 0;
    /*Vertices of the outer outline (not including holes): between 3 and 29 (23+6)*/
    this.outerOutlineVertices = 0;
    /*Number of Holes: between 0 and 3*/
    this.numHoles = 0;
    /*Area of all holes: between 0 and ?*/
    this.holeArea = 0;
    /*Number of vertices of the holes: between*/
    this.holeVertices = 0;
    /*Type of the holes: 0 if there are no holes, 1 if all holes are inner holes
    * (their vertices do not touch the outer outline, 2 if all holes are touch
    * the outer outline and 3 in a mixed case*/
    this.holeType = 0;
    /*Perimeter of the outer outline*/
    this.perimeter = 0;
    /*Longest edge of the outer outline, can be at 24 max since outline points
    * on segments that continue are kept -> does not matter since shortest
    * longest Edge is interesting (?)*/
    this.longestEdge = 0;
    /*Shortest edge of the outer outline*/
    this.shortestEdge = 0;
    /*Range in x and y*/
    this.rangeX = 0;
    this.rangeY = 0;
    /*Percentage of how much area the tangram covers of the convex hull*/
    this.convexPercentage = 0;
    /*Size of the convex hull*/
    this.convexHullArea = 0;
    /*Number of symmetry axes (x/y-axes): between 0 and 2*/
    this.symmetry = 0;
    /*Parts of the outline that are attached to the remainder only by one
    * other point: between 0 and 6*/
    this.hangingPieces = 0;
    /*Number of Edges that occur twice*/
    this.matchedEdges = 0;
    /*Number of pairs of vertices in the same place*/
    this.matchedVertices = 0;
    // this.finalEvaluation = 0;
    this.computeEvaluation(_tans, _outline);
  }
}

},{"./helpers":"3Nu5P","./tan":"59JXy","./intadjoinsqrt2":"6Swgg","./point":"3thPn","./lineSegement":"4rt7O","../options/options-storage":"1iuiP","@parcel/transformer-js/lib/esmodule-helpers.js":"7jqoH"}],"1iuiP":[function(require,module,exports) {
var _parcelHelpers = require("@parcel/transformer-js/lib/esmodule-helpers.js");
_parcelHelpers.defineInteropFlag(exports);
var _webextOptionsSync = require('webext-options-sync');
var _webextOptionsSyncDefault = _parcelHelpers.interopDefault(_webextOptionsSync);
exports.default = new _webextOptionsSyncDefault.default({
  defaults: {
    enabled: true,
    blacklist: "facebook.com\ntwitter.com\ninstagram.com\nyoutube.com",
    difficulty: "hard",
    embedded: false,
    hintTime: 0,
    solutionTime: 0,
    cacheTime: 10
  },
  migrations: [_webextOptionsSyncDefault.default.migrations.removeUnused],
  logging: true
});

},{"webext-options-sync":"5gExX","@parcel/transformer-js/lib/esmodule-helpers.js":"7jqoH"}],"5gExX":[function(require,module,exports) {
var _parcelHelpers = require("@parcel/transformer-js/lib/esmodule-helpers.js");
_parcelHelpers.defineInteropFlag(exports);
var _webextDetectPage = require("webext-detect-page");
function throttle(delay, noTrailing, callback, debounceMode) {
  var timeoutID;
  var cancelled = false;
  var lastExec = 0;
  function clearExistingTimeout() {
    timeoutID && clearTimeout(timeoutID);
  }
  if ("boolean" != typeof noTrailing) {
    debounceMode = callback;
    callback = noTrailing;
    noTrailing = void 0;
  }
  function wrapper() {
    for (var _len = arguments.length, arguments_ = new Array(_len), _key = 0; _key < _len; _key++) arguments_[_key] = arguments[_key];
    var self = this;
    var elapsed = Date.now() - lastExec;
    if (!cancelled) {
      debounceMode && !timeoutID && exec();
      clearExistingTimeout();
      void 0 === debounceMode && elapsed > delay ? exec() : true !== noTrailing && (timeoutID = setTimeout(debounceMode ? clear : exec, void 0 === debounceMode ? delay - elapsed : delay));
    }
    function exec() {
      lastExec = Date.now();
      callback.apply(self, arguments_);
    }
    function clear() {
      timeoutID = void 0;
    }
  }
  wrapper.cancel = function () {
    clearExistingTimeout();
    cancelled = true;
  };
  return wrapper;
}
class TypeRegistry {
  constructor(initial = {}) {
    this.registeredTypes = initial;
  }
  get(type) {
    return void 0 !== this.registeredTypes[type] ? this.registeredTypes[type] : this.registeredTypes.default;
  }
  register(type, item) {
    void 0 === this.registeredTypes[type] && (this.registeredTypes[type] = item);
  }
  registerDefault(item) {
    this.register("default", item);
  }
}
class KeyExtractors extends TypeRegistry {
  constructor(options) {
    super(options);
    this.registerDefault(el => el.getAttribute("name") || "");
  }
}
class InputReaders extends TypeRegistry {
  constructor(options) {
    super(options);
    this.registerDefault(el => el.value);
    this.register("checkbox", el => null !== el.getAttribute("value") ? el.checked ? el.getAttribute("value") : null : el.checked);
    this.register("select", el => (function (elem) {
      var value, option, i;
      var options = elem.options;
      var index = elem.selectedIndex;
      var one = "select-one" === elem.type;
      var values = one ? null : [];
      var max = one ? index + 1 : options.length;
      i = index < 0 ? max : one ? index : 0;
      for (; i < max; i++) if (((option = options[i]).selected || i === index) && !option.disabled && !(option.parentNode.disabled && "optgroup" === option.parentNode.tagName.toLowerCase())) {
        value = option.value;
        if (one) return value;
        values.push(value);
      }
      return values;
    })(el));
  }
}
class KeyAssignmentValidators extends TypeRegistry {
  constructor(options) {
    super(options);
    this.registerDefault(() => true);
    this.register("radio", el => el.checked);
  }
}
function keySplitter(key) {
  let matches = key.match(/[^[\]]+/g);
  let lastKey;
  if (key.length > 1 && key.indexOf("[]") === key.length - 2) {
    lastKey = matches.pop();
    matches.push([lastKey]);
  }
  return matches;
}
var proto = "undefined" != typeof Element ? Element.prototype : {};
var vendor = proto.matches || proto.matchesSelector || proto.webkitMatchesSelector || proto.mozMatchesSelector || proto.msMatchesSelector || proto.oMatchesSelector;
var matchesSelector = function (el, selector) {
  if (!el || 1 !== el.nodeType) return false;
  if (vendor) return vendor.call(el, selector);
  var nodes = el.parentNode.querySelectorAll(selector);
  for (var i = 0; i < nodes.length; i++) if (nodes[i] == el) return true;
  return false;
};
function getElementType(el) {
  let typeAttr;
  let tagName = el.tagName;
  let type = tagName;
  if ("input" === tagName.toLowerCase()) {
    typeAttr = el.getAttribute("type");
    type = typeAttr || "text";
  }
  return type.toLowerCase();
}
function getInputElements(element, options) {
  return Array.prototype.filter.call(element.querySelectorAll("input,select,textarea"), el => {
    if ("input" === el.tagName.toLowerCase() && ("submit" === el.type || "reset" === el.type)) return false;
    let myType = getElementType(el);
    let identifier = options.keyExtractors.get(myType)(el);
    let foundInInclude = -1 !== (options.include || []).indexOf(identifier);
    let foundInExclude = -1 !== (options.exclude || []).indexOf(identifier);
    let foundInIgnored = false;
    let reject = false;
    if (options.ignoredTypes) for (let selector of options.ignoredTypes) matchesSelector(el, selector) && (foundInIgnored = true);
    reject = !foundInInclude && (!!options.include || (foundInExclude || foundInIgnored));
    return !reject;
  });
}
function assignKeyValue(obj, keychain, value) {
  if (!keychain) return obj;
  var key = keychain.shift();
  obj[key] || (obj[key] = Array.isArray(key) ? [] : {});
  0 === keychain.length && (Array.isArray(obj[key]) ? null !== value && obj[key].push(value) : obj[key] = value);
  keychain.length > 0 && assignKeyValue(obj[key], keychain, value);
  return obj;
}
function serialize(element, options = {}) {
  let data = {};
  options.keySplitter = options.keySplitter || keySplitter;
  options.keyExtractors = new KeyExtractors(options.keyExtractors || ({}));
  options.inputReaders = new InputReaders(options.inputReaders || ({}));
  options.keyAssignmentValidators = new KeyAssignmentValidators(options.keyAssignmentValidators || ({}));
  Array.prototype.forEach.call(getInputElements(element, options), el => {
    let type = getElementType(el);
    let key = options.keyExtractors.get(type)(el);
    let value = options.inputReaders.get(type)(el);
    if (options.keyAssignmentValidators.get(type)(el, key, value)) {
      let keychain = options.keySplitter(key);
      data = assignKeyValue(data, keychain, value);
    }
  });
  return data;
}
class InputWriters extends TypeRegistry {
  constructor(options) {
    super(options);
    this.registerDefault((el, value) => {
      el.value = value;
    });
    this.register("checkbox", (el, value) => {
      null === value ? el.indeterminate = true : el.checked = Array.isArray(value) ? -1 !== value.indexOf(el.value) : value;
    });
    this.register("radio", function (el, value) {
      void 0 !== value && (el.checked = el.value === value.toString());
    });
    this.register("select", setSelectValue);
  }
}
function setSelectValue(elem, value) {
  var optionSet, option;
  var options = elem.options;
  var values = (function (arr) {
    var ret = [];
    null !== arr && (Array.isArray(arr) ? ret.push.apply(ret, arr) : ret.push(arr));
    return ret;
  })(value);
  var i = options.length;
  for (; i--; ) {
    option = options[i];
    if (values.indexOf(option.value) > -1) {
      option.setAttribute("selected", true);
      optionSet = true;
    }
  }
  optionSet || (elem.selectedIndex = -1);
}
function keyJoiner(parentKey, childKey) {
  return parentKey + "[" + childKey + "]";
}
function flattenData(data, parentKey, options = {}) {
  let flatData = {};
  let keyJoiner$1 = options.keyJoiner || keyJoiner;
  for (let keyName in data) {
    if (!data.hasOwnProperty(keyName)) continue;
    let value = data[keyName];
    let hash = {};
    parentKey && (keyName = keyJoiner$1(parentKey, keyName));
    if (Array.isArray(value)) {
      hash[keyName + "[]"] = value;
      hash[keyName] = value;
    } else "object" == typeof value ? hash = flattenData(value, keyName, options) : hash[keyName] = value;
    Object.assign(flatData, hash);
  }
  return flatData;
}
function deserialize(form, data, options = {}) {
  let flattenedData = flattenData(data, null, options);
  options.keyExtractors = new KeyExtractors(options.keyExtractors || ({}));
  options.inputWriters = new InputWriters(options.inputWriters || ({}));
  Array.prototype.forEach.call(getInputElements(form, options), el => {
    let type = getElementType(el);
    let key = options.keyExtractors.get(type)(el);
    options.inputWriters.get(type)(el, flattenedData[key]);
  });
}
var lzString = ((function (module) {
  var LZString = (function () {
    var f = String.fromCharCode;
    var keyStrBase64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
    var keyStrUriSafe = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+-$";
    var baseReverseDic = {};
    function getBaseValue(alphabet, character) {
      if (!baseReverseDic[alphabet]) {
        baseReverseDic[alphabet] = {};
        for (var i = 0; i < alphabet.length; i++) baseReverseDic[alphabet][alphabet.charAt(i)] = i;
      }
      return baseReverseDic[alphabet][character];
    }
    var LZString = {
      compressToBase64: function (input) {
        if (null == input) return "";
        var res = LZString._compress(input, 6, function (a) {
          return keyStrBase64.charAt(a);
        });
        switch (res.length % 4) {
          default:
          case 0:
            return res;
          case 1:
            return res + "===";
          case 2:
            return res + "==";
          case 3:
            return res + "=";
        }
      },
      decompressFromBase64: function (input) {
        return null == input ? "" : "" == input ? null : LZString._decompress(input.length, 32, function (index) {
          return getBaseValue(keyStrBase64, input.charAt(index));
        });
      },
      compressToUTF16: function (input) {
        return null == input ? "" : LZString._compress(input, 15, function (a) {
          return f(a + 32);
        }) + " ";
      },
      decompressFromUTF16: function (compressed) {
        return null == compressed ? "" : "" == compressed ? null : LZString._decompress(compressed.length, 16384, function (index) {
          return compressed.charCodeAt(index) - 32;
        });
      },
      compressToUint8Array: function (uncompressed) {
        var compressed = LZString.compress(uncompressed);
        var buf = new Uint8Array(2 * compressed.length);
        for (var i = 0, TotalLen = compressed.length; i < TotalLen; i++) {
          var current_value = compressed.charCodeAt(i);
          buf[2 * i] = current_value >>> 8;
          buf[2 * i + 1] = current_value % 256;
        }
        return buf;
      },
      decompressFromUint8Array: function (compressed) {
        if (null == compressed) return LZString.decompress(compressed);
        var buf = new Array(compressed.length / 2);
        for (var i = 0, TotalLen = buf.length; i < TotalLen; i++) buf[i] = 256 * compressed[2 * i] + compressed[2 * i + 1];
        var result = [];
        buf.forEach(function (c) {
          result.push(f(c));
        });
        return LZString.decompress(result.join(""));
      },
      compressToEncodedURIComponent: function (input) {
        return null == input ? "" : LZString._compress(input, 6, function (a) {
          return keyStrUriSafe.charAt(a);
        });
      },
      decompressFromEncodedURIComponent: function (input) {
        if (null == input) return "";
        if ("" == input) return null;
        input = input.replace(/ /g, "+");
        return LZString._decompress(input.length, 32, function (index) {
          return getBaseValue(keyStrUriSafe, input.charAt(index));
        });
      },
      compress: function (uncompressed) {
        return LZString._compress(uncompressed, 16, function (a) {
          return f(a);
        });
      },
      _compress: function (uncompressed, bitsPerChar, getCharFromInt) {
        if (null == uncompressed) return "";
        var i, value, ii, context_dictionary = {}, context_dictionaryToCreate = {}, context_c = "", context_wc = "", context_w = "", context_enlargeIn = 2, context_dictSize = 3, context_numBits = 2, context_data = [], context_data_val = 0, context_data_position = 0;
        for (ii = 0; ii < uncompressed.length; ii += 1) {
          context_c = uncompressed.charAt(ii);
          if (!Object.prototype.hasOwnProperty.call(context_dictionary, context_c)) {
            context_dictionary[context_c] = context_dictSize++;
            context_dictionaryToCreate[context_c] = true;
          }
          context_wc = context_w + context_c;
          if (Object.prototype.hasOwnProperty.call(context_dictionary, context_wc)) context_w = context_wc; else {
            if (Object.prototype.hasOwnProperty.call(context_dictionaryToCreate, context_w)) {
              if (context_w.charCodeAt(0) < 256) {
                for (i = 0; i < context_numBits; i++) {
                  context_data_val <<= 1;
                  if (context_data_position == bitsPerChar - 1) {
                    context_data_position = 0;
                    context_data.push(getCharFromInt(context_data_val));
                    context_data_val = 0;
                  } else context_data_position++;
                }
                value = context_w.charCodeAt(0);
                for (i = 0; i < 8; i++) {
                  context_data_val = context_data_val << 1 | 1 & value;
                  if (context_data_position == bitsPerChar - 1) {
                    context_data_position = 0;
                    context_data.push(getCharFromInt(context_data_val));
                    context_data_val = 0;
                  } else context_data_position++;
                  value >>= 1;
                }
              } else {
                value = 1;
                for (i = 0; i < context_numBits; i++) {
                  context_data_val = context_data_val << 1 | value;
                  if (context_data_position == bitsPerChar - 1) {
                    context_data_position = 0;
                    context_data.push(getCharFromInt(context_data_val));
                    context_data_val = 0;
                  } else context_data_position++;
                  value = 0;
                }
                value = context_w.charCodeAt(0);
                for (i = 0; i < 16; i++) {
                  context_data_val = context_data_val << 1 | 1 & value;
                  if (context_data_position == bitsPerChar - 1) {
                    context_data_position = 0;
                    context_data.push(getCharFromInt(context_data_val));
                    context_data_val = 0;
                  } else context_data_position++;
                  value >>= 1;
                }
              }
              if (0 == --context_enlargeIn) {
                context_enlargeIn = Math.pow(2, context_numBits);
                context_numBits++;
              }
              delete context_dictionaryToCreate[context_w];
            } else {
              value = context_dictionary[context_w];
              for (i = 0; i < context_numBits; i++) {
                context_data_val = context_data_val << 1 | 1 & value;
                if (context_data_position == bitsPerChar - 1) {
                  context_data_position = 0;
                  context_data.push(getCharFromInt(context_data_val));
                  context_data_val = 0;
                } else context_data_position++;
                value >>= 1;
              }
            }
            if (0 == --context_enlargeIn) {
              context_enlargeIn = Math.pow(2, context_numBits);
              context_numBits++;
            }
            context_dictionary[context_wc] = context_dictSize++;
            context_w = String(context_c);
          }
        }
        if ("" !== context_w) {
          if (Object.prototype.hasOwnProperty.call(context_dictionaryToCreate, context_w)) {
            if (context_w.charCodeAt(0) < 256) {
              for (i = 0; i < context_numBits; i++) {
                context_data_val <<= 1;
                if (context_data_position == bitsPerChar - 1) {
                  context_data_position = 0;
                  context_data.push(getCharFromInt(context_data_val));
                  context_data_val = 0;
                } else context_data_position++;
              }
              value = context_w.charCodeAt(0);
              for (i = 0; i < 8; i++) {
                context_data_val = context_data_val << 1 | 1 & value;
                if (context_data_position == bitsPerChar - 1) {
                  context_data_position = 0;
                  context_data.push(getCharFromInt(context_data_val));
                  context_data_val = 0;
                } else context_data_position++;
                value >>= 1;
              }
            } else {
              value = 1;
              for (i = 0; i < context_numBits; i++) {
                context_data_val = context_data_val << 1 | value;
                if (context_data_position == bitsPerChar - 1) {
                  context_data_position = 0;
                  context_data.push(getCharFromInt(context_data_val));
                  context_data_val = 0;
                } else context_data_position++;
                value = 0;
              }
              value = context_w.charCodeAt(0);
              for (i = 0; i < 16; i++) {
                context_data_val = context_data_val << 1 | 1 & value;
                if (context_data_position == bitsPerChar - 1) {
                  context_data_position = 0;
                  context_data.push(getCharFromInt(context_data_val));
                  context_data_val = 0;
                } else context_data_position++;
                value >>= 1;
              }
            }
            if (0 == --context_enlargeIn) {
              context_enlargeIn = Math.pow(2, context_numBits);
              context_numBits++;
            }
            delete context_dictionaryToCreate[context_w];
          } else {
            value = context_dictionary[context_w];
            for (i = 0; i < context_numBits; i++) {
              context_data_val = context_data_val << 1 | 1 & value;
              if (context_data_position == bitsPerChar - 1) {
                context_data_position = 0;
                context_data.push(getCharFromInt(context_data_val));
                context_data_val = 0;
              } else context_data_position++;
              value >>= 1;
            }
          }
          if (0 == --context_enlargeIn) {
            context_enlargeIn = Math.pow(2, context_numBits);
            context_numBits++;
          }
        }
        value = 2;
        for (i = 0; i < context_numBits; i++) {
          context_data_val = context_data_val << 1 | 1 & value;
          if (context_data_position == bitsPerChar - 1) {
            context_data_position = 0;
            context_data.push(getCharFromInt(context_data_val));
            context_data_val = 0;
          } else context_data_position++;
          value >>= 1;
        }
        for (; ; ) {
          context_data_val <<= 1;
          if (context_data_position == bitsPerChar - 1) {
            context_data.push(getCharFromInt(context_data_val));
            break;
          }
          context_data_position++;
        }
        return context_data.join("");
      },
      decompress: function (compressed) {
        return null == compressed ? "" : "" == compressed ? null : LZString._decompress(compressed.length, 32768, function (index) {
          return compressed.charCodeAt(index);
        });
      },
      _decompress: function (length, resetValue, getNextValue) {
        var i, w, bits, resb, maxpower, power, c, dictionary = [], enlargeIn = 4, dictSize = 4, numBits = 3, entry = "", result = [], data = {
          val: getNextValue(0),
          position: resetValue,
          index: 1
        };
        for (i = 0; i < 3; i += 1) dictionary[i] = i;
        bits = 0;
        maxpower = Math.pow(2, 2);
        power = 1;
        for (; power != maxpower; ) {
          resb = data.val & data.position;
          data.position >>= 1;
          if (0 == data.position) {
            data.position = resetValue;
            data.val = getNextValue(data.index++);
          }
          bits |= (resb > 0 ? 1 : 0) * power;
          power <<= 1;
        }
        switch (bits) {
          case 0:
            bits = 0;
            maxpower = Math.pow(2, 8);
            power = 1;
            for (; power != maxpower; ) {
              resb = data.val & data.position;
              data.position >>= 1;
              if (0 == data.position) {
                data.position = resetValue;
                data.val = getNextValue(data.index++);
              }
              bits |= (resb > 0 ? 1 : 0) * power;
              power <<= 1;
            }
            c = f(bits);
            break;
          case 1:
            bits = 0;
            maxpower = Math.pow(2, 16);
            power = 1;
            for (; power != maxpower; ) {
              resb = data.val & data.position;
              data.position >>= 1;
              if (0 == data.position) {
                data.position = resetValue;
                data.val = getNextValue(data.index++);
              }
              bits |= (resb > 0 ? 1 : 0) * power;
              power <<= 1;
            }
            c = f(bits);
            break;
          case 2:
            return "";
        }
        dictionary[3] = c;
        w = c;
        result.push(c);
        for (; ; ) {
          if (data.index > length) return "";
          bits = 0;
          maxpower = Math.pow(2, numBits);
          power = 1;
          for (; power != maxpower; ) {
            resb = data.val & data.position;
            data.position >>= 1;
            if (0 == data.position) {
              data.position = resetValue;
              data.val = getNextValue(data.index++);
            }
            bits |= (resb > 0 ? 1 : 0) * power;
            power <<= 1;
          }
          switch (c = bits) {
            case 0:
              bits = 0;
              maxpower = Math.pow(2, 8);
              power = 1;
              for (; power != maxpower; ) {
                resb = data.val & data.position;
                data.position >>= 1;
                if (0 == data.position) {
                  data.position = resetValue;
                  data.val = getNextValue(data.index++);
                }
                bits |= (resb > 0 ? 1 : 0) * power;
                power <<= 1;
              }
              dictionary[dictSize++] = f(bits);
              c = dictSize - 1;
              enlargeIn--;
              break;
            case 1:
              bits = 0;
              maxpower = Math.pow(2, 16);
              power = 1;
              for (; power != maxpower; ) {
                resb = data.val & data.position;
                data.position >>= 1;
                if (0 == data.position) {
                  data.position = resetValue;
                  data.val = getNextValue(data.index++);
                }
                bits |= (resb > 0 ? 1 : 0) * power;
                power <<= 1;
              }
              dictionary[dictSize++] = f(bits);
              c = dictSize - 1;
              enlargeIn--;
              break;
            case 2:
              return result.join("");
          }
          if (0 == enlargeIn) {
            enlargeIn = Math.pow(2, numBits);
            numBits++;
          }
          if (dictionary[c]) entry = dictionary[c]; else {
            if (c !== dictSize) return null;
            entry = w + w.charAt(0);
          }
          result.push(entry);
          dictionary[dictSize++] = w + entry.charAt(0);
          w = entry;
          if (0 == --enlargeIn) {
            enlargeIn = Math.pow(2, numBits);
            numBits++;
          }
        }
      }
    };
    return LZString;
  })();
  null != module && (module.exports = LZString);
})(module = {
  exports: {}
}, module.exports), module.exports);
var module;
class OptionsSync {
  constructor({defaults: defaults = {}, storageName: storageName = "options", migrations: migrations = [], logging: logging = true} = {}) {
    Object.defineProperty(this, "storageName", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "defaults", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "_form", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "_migrations", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    this.storageName = storageName;
    this.defaults = defaults;
    this._handleFormInput = (delay = 300, atBegin = this._handleFormInput.bind(this), void 0 === callback ? throttle(delay, atBegin, false) : throttle(delay, callback, false !== atBegin));
    var delay, atBegin, callback;
    this._handleStorageChangeOnForm = this._handleStorageChangeOnForm.bind(this);
    logging || (this._log = () => {});
    this._migrations = this._runMigrations(migrations);
  }
  async getAll() {
    await this._migrations;
    return this._getAll();
  }
  async setAll(newOptions) {
    await this._migrations;
    return this._setAll(newOptions);
  }
  async set(newOptions) {
    return this.setAll({
      ...await this.getAll(),
      ...newOptions
    });
  }
  async syncForm(form) {
    this._form = form instanceof HTMLFormElement ? form : document.querySelector(form);
    this._form.addEventListener("input", this._handleFormInput);
    this._form.addEventListener("submit", this._handleFormSubmit);
    chrome.storage.onChanged.addListener(this._handleStorageChangeOnForm);
    this._updateForm(this._form, await this.getAll());
  }
  async stopSyncForm() {
    if (this._form) {
      this._form.removeEventListener("input", this._handleFormInput);
      this._form.removeEventListener("submit", this._handleFormSubmit);
      chrome.storage.onChanged.removeListener(this._handleStorageChangeOnForm);
      delete this._form;
    }
  }
  _log(method, ...args) {
    console[method](...args);
  }
  async _getAll() {
    return new Promise((resolve, reject) => {
      chrome.storage.sync.get(this.storageName, result => {
        chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(this._decode(result[this.storageName]));
      });
    });
  }
  async _setAll(newOptions) {
    this._log("log", "Saving options", newOptions);
    return new Promise((resolve, reject) => {
      chrome.storage.sync.set({
        [this.storageName]: this._encode(newOptions)
      }, () => {
        chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve();
      });
    });
  }
  _encode(options) {
    const thinnedOptions = {
      ...options
    };
    for (const [key, value] of Object.entries(thinnedOptions)) this.defaults[key] === value && delete thinnedOptions[key];
    this._log("log", "Without the default values", thinnedOptions);
    return lzString.compressToEncodedURIComponent(JSON.stringify(thinnedOptions));
  }
  _decode(options) {
    let decompressed = options;
    "string" == typeof options && (decompressed = JSON.parse(lzString.decompressFromEncodedURIComponent(options)));
    return {
      ...this.defaults,
      ...decompressed
    };
  }
  async _runMigrations(migrations) {
    if (0 === migrations.length || !_webextDetectPage.isBackgroundPage() || !await (async function () {
      return new Promise(resolve => {
        var _a;
        const callback = installType => {
          if ("development" !== installType) {
            chrome.runtime.onInstalled.addListener(() => resolve(true));
            setTimeout(resolve, 500, false);
          } else resolve(true);
        };
        (null === (_a = chrome.management) || void 0 === _a ? void 0 : _a.getSelf) ? chrome.management.getSelf(({installType: installType}) => callback(installType)) : callback("unknown");
      });
    })()) return;
    const options = await this._getAll();
    const initial = JSON.stringify(options);
    this._log("log", "Found these stored options", {
      ...options
    });
    this._log("info", "Will run", migrations.length, 1 === migrations.length ? "migration" : " migrations");
    migrations.forEach(migrate => migrate(options, this.defaults));
    initial !== JSON.stringify(options) && await this._setAll(options);
  }
  async _handleFormInput({target: target}) {
    const field = target;
    if (field.name) {
      await this.set(this._parseForm(field.form));
      field.form.dispatchEvent(new CustomEvent("options-sync:form-synced", {
        bubbles: true
      }));
    }
  }
  _handleFormSubmit(event) {
    event.preventDefault();
  }
  _updateForm(form, options) {
    const currentFormState = this._parseForm(form);
    for (const [key, value] of Object.entries(options)) currentFormState[key] === value && delete options[key];
    const include = Object.keys(options);
    include.length > 0 && deserialize(form, options, {
      include: include
    });
  }
  _parseForm(form) {
    const include = [];
    for (const field of form.querySelectorAll("[name]")) field.validity.valid && !field.disabled && include.push(field.name.replace(/\[.*]/, ""));
    return serialize(form, {
      include: include
    });
  }
  _handleStorageChangeOnForm(changes, areaName) {
    "sync" !== areaName || !changes[this.storageName] || document.hasFocus() && this._form.contains(document.activeElement) || this._updateForm(this._form, this._decode(changes[this.storageName].newValue));
  }
}
Object.defineProperty(OptionsSync, "migrations", {
  enumerable: true,
  configurable: true,
  writable: true,
  value: {
    removeUnused(options, defaults) {
      for (const key of Object.keys(options)) (key in defaults) || delete options[key];
    }
  }
});
exports.default = OptionsSync;

},{"webext-detect-page":"74KI2","@parcel/transformer-js/lib/esmodule-helpers.js":"7jqoH"}],"74KI2":[function(require,module,exports) {
var _parcelHelpers = require("@parcel/transformer-js/lib/esmodule-helpers.js");
_parcelHelpers.defineInteropFlag(exports);
_parcelHelpers.export(exports, "isContentScript", function () {
  return isContentScript;
});
_parcelHelpers.export(exports, "isBackgroundPage", function () {
  return isBackgroundPage;
});
_parcelHelpers.export(exports, "isOptionsPage", function () {
  return isOptionsPage;
});
const isExtensionContext = typeof chrome === 'object' && chrome && typeof chrome.extension === 'object';
const globalWindow = typeof window === 'object' ? window : undefined;
const isWeb = typeof location === 'object' && location.protocol.startsWith('http');
function isContentScript() {
  return isExtensionContext && isWeb;
}
function isBackgroundPage() {
  var _a, _b;
  return isExtensionContext && (location.pathname === '/_generated_background_page.html' || ((_b = (_a = chrome.extension) === null || _a === void 0 ? void 0 : _a.getBackgroundPage) === null || _b === void 0 ? void 0 : _b.call(_a)) === globalWindow);
}
function isOptionsPage() {
  if (!isExtensionContext || !chrome.runtime.getManifest) {
    return false;
  }
  const {options_ui} = chrome.runtime.getManifest();
  if (typeof options_ui !== 'object' || typeof options_ui.page !== 'string') {
    return false;
  }
  const url = new URL(options_ui.page, location.origin);
  return url.pathname === location.pathname && url.origin === location.origin;
}

},{"@parcel/transformer-js/lib/esmodule-helpers.js":"7jqoH"}],"oHYt4":[function(require,module,exports) {
var _parcelHelpers = require("@parcel/transformer-js/lib/esmodule-helpers.js");
_parcelHelpers.defineInteropFlag(exports);
_parcelHelpers.export(exports, "generateTangrams", function () {
  return generateTangrams;
});
var _helpers = require("./helpers");
var _tan = require("./tan");
var _directions = require("./directions");
var _tangram = require("./tangram");
var _lineSegement = require("./lineSegement");
var _point = require("./point");
var _intadjoinsqrt = require("./intadjoinsqrt2");
/*Maximum range in x/y a tangram can have, maximum it should be set to is 60*/
const range = new _intadjoinsqrt.IntAdjoinSqrt2(50, 0);
/*Addend by which "probability" of an orientation is increased when segments
* align*/
// NOTE: Higher number -> Better connectivity
const increaseProbability = 500;
const checkNewTan = function (currentTans, newTan) {
  let contains;
  let tansId;
  /*For each point of the new piece, check if it overlaps with already placed
  * tans*/
  const points = newTan.getPoints();
  /*Use inside points to detect exact alignment of one piece in another*/
  const allTanPoints = points.concat(newTan.getInsidePoints());
  for (tansId = 0; tansId < currentTans.length; tansId++) {
    let pointId;
    let currentPoints = currentTans[tansId].getPoints();
    let onSegmentCounter = 0;
    for (pointId = 0; pointId < allTanPoints.length; pointId++) {
      contains = _tan.containsPoint(currentPoints, allTanPoints[pointId]);
      if (contains === 1) {
        return false;
      } else if (contains === 0) {
        onSegmentCounter++;
      }
    }
    /*If more than 3 points of the new tan lie on one of the already placed
    * tans, there must be an overlap*/
    if (onSegmentCounter >= 3) {
      return false;
    }
    /*Apply the same check the other way around: and already placed piece
    * lies inside the new piece*/
    onSegmentCounter = 0;
    currentPoints = currentPoints.concat(currentTans[tansId].getInsidePoints());
    for (pointId = 0; pointId < currentPoints.length; pointId++) {
      contains = _tan.containsPoint(points, currentPoints[pointId]);
      if (contains === 1) {
        return false;
      } else if (contains === 0) {
        onSegmentCounter++;
      }
    }
    if (onSegmentCounter >= 3) {
      return false;
    }
  }
  /*Check if any of the segments of the already placed tans  is intersected
  * by any of the line segments of the new tan*/
  const tanSegments = newTan.getSegments();
  for (let segmentId = 0; segmentId < tanSegments.length; segmentId++) {
    for (tansId = 0; tansId < currentTans.length; tansId++) {
      const otherSegments = currentTans[tansId].getSegments();
      for (let otherSegmentsId = 0; otherSegmentsId < otherSegments.length; otherSegmentsId++) {
        if (tanSegments[segmentId].intersects(otherSegments[otherSegmentsId])) {
          return false;
        }
      }
    }
  }
  /*Check if placement of newTan results in a tangram with a to large range
  * assuming that tangrams with a too large range are not interesting*/
  const newTans = currentTans.slice(0);
  newTans[currentTans.length] = newTan;
  const boundingBox = _tan.computeBoundingBox(newTans);
  if (boundingBox[2].dup().subtract(boundingBox[0]).compare(range) > 0 || boundingBox[3].dup().subtract(boundingBox[1]).compare(range) > 0) {
    return false;
  }
  return true;
};
/*Function to randomly generate a tangram by sampling orientation at the beginning*/
const generateTangram = function () {
  let tanId;
  /*Generate an order in which the tan pieces are to be placed and an orientation
  * for each piece*/
  const flipped = Math.floor(Math.random() * 2);
  let tanOrder = [0, 0, 1, 2, 2, 3, 4 + flipped];
  console.log(tanOrder);
  tanOrder = _helpers.shuffleArray(tanOrder);
  const orientations = [];
  for (tanId = 0; tanId < 7; tanId++) {
    orientations[tanId] = Math.floor(Math.random() * _directions.numOrientations);
  }
  /*Place the first tan, as defined in tanOrder, at the center the drawing space*/
  const tans = [];
  let anchor = new _point.Point(new _intadjoinsqrt.IntAdjoinSqrt2(30, 0), new _intadjoinsqrt.IntAdjoinSqrt2(30, 0));
  tans[0] = new _tan.Tan(tanOrder[0], anchor, orientations[0]);
  /*For each remaining piece to be placed, determine one of the points of the
  * outline of the already placed pieces as the connecting point to the new
  * piece*/
  for (tanId = 1; tanId < 7; tanId++) {
    const allPoints = _tan.getAllPoints(tans);
    let tanPlaced = false;
    let counter = 0;
    while (!tanPlaced) {
      anchor = allPoints[Math.floor(Math.random() * allPoints.length)].dup();
      /*Try each possible point of the new tan as a connecting points and
      * take the first one that does not result in an overlap*/
      let pointId = 0;
      let pointOrder = tanOrder[tanId] < 3 ? [0, 1, 2] : [0, 1, 2, 3];
      pointOrder = _helpers.shuffleArray(pointOrder);
      do {
        let newTan;
        /*If the connecting point is not the anchor, the anchor position
        * has to be calculated from the direction vectors for that tan
        * type and orientation*/
        if (pointOrder[pointId] === 0) {
          newTan = new _tan.Tan(tanOrder[tanId], anchor, orientations[tanId]);
        } else {
          const tanAnchor = anchor.dup().subtract(_directions.Directions[tanOrder[tanId]][orientations[tanId]][pointOrder[pointId] - 1]);
          newTan = new _tan.Tan(tanOrder[tanId], tanAnchor, orientations[tanId]);
        }
        /*Place the tan if it does not overlap with already placed tans*/
        if (checkNewTan(tans, newTan)) {
          tans[tanId] = newTan;
          tanPlaced = true;
        }
        pointId++;
      } while (!tanPlaced && pointId < (tanOrder[tanId] < 3 ? 3 : 4));
      /*Try again if process has run into infinity loop -> choose new
      * connecting point*/
      counter++;
      if (counter > 100) {
        console.log("Infinity loop!");
        return generateTangram();
      }
    }
  }
  return new _tangram.Tangram(tans);
};
/*Given an array of values, normalize the values so that sum of all values is 1*/
const normalizeProbability = function (distribution) {
  let index;
  let sum = 0;
  for (index = 0; index < distribution.length; index++) {
    sum += distribution[index];
  }
  if (_helpers.numberEq(sum, 0)) return;
  for (index = 0; index < distribution.length; index++) {
    distribution[index] /= sum;
  }
  return distribution;
};
/*For a given number of already placed tans and a point at which a new tan is
* supposed to be places, compute in which orientations segments align of already
* placed tans align with segments of the new tan and increase the probability
* of those tans accordingly*/
const computeOrientationProbability = function (tans, point, tanType, pointId, allSegments) {
  let segmentId;
  const distribution = [];
  const segmentDirections = [];
  /*Get directions of the segments that are adjacent with the given connecting
  * point in a way that the directions point to the respective other point*/
  for (segmentId = 0; segmentId < allSegments.length; segmentId++) {
    if (allSegments[segmentId].point1.eq(point)) {
      segmentDirections.push(allSegments[segmentId].direction());
    } else if (allSegments[segmentId].point2.eq(point)) {
      segmentDirections.push(allSegments[segmentId].direction().neg());
    }
  }
  /*Segments align is the direction vectors are a multiple of each other*/
  for (var orientId = 0; orientId < _directions.numOrientations; orientId++) {
    distribution.push(1);
    for (segmentId = 0; segmentId < segmentDirections.length; segmentId++) {
      if (segmentDirections[segmentId].multipleOf(_directions.SegmentDirections[tanType][orientId][pointId][0])) {
        distribution[orientId] += increaseProbability;
      }
      if (segmentDirections[segmentId].multipleOf(_directions.SegmentDirections[tanType][orientId][pointId][1])) {
        distribution[orientId] += increaseProbability;
      }
    }
  }
  return normalizeProbability(distribution);
};
/*Assumes that the sum of all values in distribution is 1*/
const sampleOrientation = function (distribution) {
  /*Generate value between 0 and 1*/
  const sample = Math.random();
  /*Successively compute accumulated distribution and return if sample is
  * smaller than the accumulated value -> then falls into the interval for
  * that index*/
  distribution = distribution.slice(0);
  if (sample < distribution[0]) return 0;
  for (let index = 1; index < _directions.numOrientations; index++) {
    distribution[index] += distribution[index - 1];
    if (sample <= distribution[index]) {
      return index;
    }
  }
  return _directions.numOrientations - 1;
};
/*Add the points of the new tan to an array of points of the already placed
* tans*/
const updatePoints = function (currentPoints, newTan) {
  const newPoints = newTan.getPoints();
  currentPoints = currentPoints.concat(newPoints);
  return _helpers.eliminateDuplicates(currentPoints, _point.Point.comparePoints, true);
};
/*Add the segments of the new tan to an array of segments of the already placed
* tans while also splitting the segments of points*/
const updateSegments = function (currentSegments, newTan) {
  /*Only the points of the new Tan can split any of the already present segments*/
  const newPoints = newTan.getPoints();
  let allSegments = [];
  /*Check for each segment if it should be split by any of the new points*/
  for (let segmentId = 0; segmentId < currentSegments.length; segmentId++) {
    const splitPoints = [];
    for (let pointId = 0; pointId < newPoints.length; pointId++) {
      if (currentSegments[segmentId].onSegment(newPoints[pointId])) {
        splitPoints.push(newPoints[pointId]);
      }
    }
    allSegments = allSegments.concat(currentSegments[segmentId].split(splitPoints));
  }
  /*Add the segments of the new tan and than delete duplicates*/
  allSegments = allSegments.concat(newTan.getSegments());
  allSegments = _helpers.eliminateDuplicates(allSegments, _lineSegement.LineSegment.compareLineSegments, true);
  return allSegments;
};
/*Function to randomly generate a tangram with more overlapping edges*/
const generateTangramEdges = function () {
  /*Generate an order in which the tan pieces are to be placed and decide on
  * whether the parallelogram is flipped or not*/
  const flipped = Math.floor(Math.random() * 2);
  let tanOrder = [0, 0, 1, 2, 2, 3, 4 + flipped];
  tanOrder = _helpers.shuffleArray(tanOrder);
  let orientation = Math.floor(Math.random() * _directions.numOrientations);
  /*Place the first tan, as defined in tanOrder, at the center the drawing space
  * with the just sampled orientation*/
  const tans = [];
  let anchor = new _point.Point(new _intadjoinsqrt.IntAdjoinSqrt2(30, 0), new _intadjoinsqrt.IntAdjoinSqrt2(30, 0));
  tans[0] = new _tan.Tan(tanOrder[0], anchor, orientation);
  let allPoints = tans[0].getPoints();
  let allSegments = tans[0].getSegments();
  for (let tanId = 1; tanId < 7; tanId++) {
    let tanPlaced = false;
    let counter = 0;
    while (!tanPlaced) {
      /*Choose point at which new tan is to be attached*/
      anchor = allPoints[Math.floor(Math.random() * allPoints.length)].dup();
      /*Choose point of the new tan that will be attached to that point*/
      let pointId = 0;
      let pointOrder = tanOrder[tanId] < 3 ? [0, 1, 2] : [0, 1, 2, 3];
      pointOrder = _helpers.shuffleArray(pointOrder);
      do {
        let newTan;
        /*Compute probability distribution for orientations*/
        let orientationDistribution = computeOrientationProbability(tans, anchor, tanOrder[tanId], pointOrder[pointId], allSegments);
        /*Sample a new orientation*/
        while (typeof orientationDistribution != 'undefined' && !tanPlaced) {
          orientation = sampleOrientation(orientationDistribution);
          if (pointOrder[pointId] === 0) {
            newTan = new _tan.Tan(tanOrder[tanId], anchor, orientation);
          } else {
            const tanAnchor = anchor.dup().subtract(_directions.Directions[tanOrder[tanId]][orientation][pointOrder[pointId] - 1]);
            newTan = new _tan.Tan(tanOrder[tanId], tanAnchor, orientation);
          }
          if (checkNewTan(tans, newTan)) {
            tans[tanId] = newTan;
            tanPlaced = true;
            allPoints = updatePoints(allPoints, newTan);
            allSegments = updateSegments(allSegments, newTan);
          }
          /*Set probability of the just failed orientation to 0, so it
          * is not chosen again*/
          orientationDistribution[orientation] = 0;
          orientationDistribution = normalizeProbability(orientationDistribution);
        }
        pointId++;
      } while (!tanPlaced && pointId < (tanOrder[tanId] < 3 ? 3 : 4));
      counter++;
      /*Try again - can this ever happen?*/
      if (counter > 100) {
        console.log("Infinity loop!");
        return generateTangramEdges();
      }
    }
  }
  return new _tangram.Tangram(tans);
};
const generateTangrams = function (number) {
  let generated = [];
  for (let index = 0; index < number; index++) {
    generated[index] = generateTangramEdges();
    /*Clean up objects - delete keys that have just been set to avoid
    * computing these properties multiple times*/
    for (let tanId = 0; tanId < 7; tanId++) {
      delete generated[index].tans[tanId].points;
      delete generated[index].tans[tanId].segments;
      delete generated[index].tans[tanId].insidePoints;
    }
  }
  // TODO: this (default) sorts tangrams by most difficult to solve (prob 1. or 2. tangram displayed)
  // use this for difficulty setting in the later stages of development
  if (!_helpers.evalVal) {
    console.log("sorting tangrams...");
    generated = generated.sort(_tangram.compareTangrams);
  }
  const jsonTans = [];
  for (let index = 0; index < number; index++) {
    jsonTans.push(JSON.stringify(generated[index].tans));
  }
  return jsonTans;
};

},{"./helpers":"3Nu5P","./tan":"59JXy","./directions":"4qo9l","./tangram":"1Ps4L","./lineSegement":"4rt7O","./point":"3thPn","./intadjoinsqrt2":"6Swgg","@parcel/transformer-js/lib/esmodule-helpers.js":"7jqoH"}],"3XOQn":[function(require,module,exports) {
module.exports = require('./bundle-url').getBundleURL() + "logo.608f831a.png";

},{"./bundle-url":"5fYKf"}],"5fYKf":[function(require,module,exports) {
"use strict";

/* globals document:readonly */
var bundleURL = null;

function getBundleURLCached() {
  if (!bundleURL) {
    bundleURL = getBundleURL();
  }

  return bundleURL;
}

function getBundleURL() {
  try {
    throw new Error();
  } catch (err) {
    var matches = ('' + err.stack).match(/(https?|file|ftp):\/\/[^)\n]+/g);

    if (matches) {
      return getBaseURL(matches[0]);
    }
  }

  return '/';
}

function getBaseURL(url) {
  return ('' + url).replace(/^((?:https?|file|ftp):\/\/.+)\/[^/]+$/, '$1') + '/';
} // TODO: Replace uses with `new URL(url).origin` when ie11 is no longer supported.


function getOrigin(url) {
  let matches = ('' + url).match(/(https?|file|ftp):\/\/[^/]+/);

  if (!matches) {
    throw new Error('Origin not found');
  }

  return matches[0];
}

exports.getBundleURL = getBundleURLCached;
exports.getBaseURL = getBaseURL;
exports.getOrigin = getOrigin;
},{}],"5LnPt":[function(require,module,exports) {
"use strict";
Object.defineProperty(exports, "__esModule", {
  value: true
});
const tslib_1 = require("tslib");
const detection_1 = tslib_1.__importDefault(require("./detection"));
const webextension_polyfill_ts_1 = require("webextension-polyfill-ts");
const chrome_icon = tslib_1.__importStar(require("url:./icons/chrome-logo.png"));
const safari_icon = tslib_1.__importStar(require("url:./icons/safari-logo.png"));
const edge_icon = tslib_1.__importStar(require("url:./icons/edge-logo.png"));
const firefox_icon = tslib_1.__importStar(require("url:./icons/firefox-logo.png"));
class WebExtFeedbackPrompt {
  /**
  * Constructor
  * @param param0 object (see the docs for parameters)
  */
  constructor({window, headline, text, installDate, storeLinks, logo, frequency, timeout, theme, onOpen, onClose}) {
    // Frontend modal features
    this._headline = "I'm waiting for your rating!";
    this._text = "";
    this._logo = "";
    // Timeout until modal is shown - in ms
    this._timeout = 0;
    // Manual Mode to control the modal manually (default: disabled)
    this._manual = false;
    // default: only show once
    this._frequency = 1;
    // Light/Dark Theme
    this._theme = "light";
    /**
    * Add the styles of the modal to <style> tag inserted into the document <head>
    * @param styleRules : string, CSS style rules
    */
    this.setStyle = styleRules => {
      const style = this.createElement("style");
      style.innerHTML = styleRules;
      this._document.head.appendChild(style);
    };
    /**
    * Add the default styles based on the chosen theme
    * @param theme "light" / "dark"
    */
    this.addDefaultStyles = theme => {
      const darkTheme = `
        .fbm-blur {
            position: fixed;
            z-index: 3;
        
            width: 100vw;
            height: 100vh;
        
            left: 0;
            top: 0;
            background-color: #00000080;
        }
        
        @keyframes modalAnimation {
            from {
                top: 45%;
            }
            to {
                top: 50%;
            }
        }
        .fbm-modal {
            position: absolute;
            top: 50%;
            left: 50%;
        
            transform: translate(-50%, -50%);
            animation-name: modalAnimation;
            animation-duration: 1.5s;
            animation-delay: 0.2s;
        
            background-color: #1D2D50;
            border-radius: 25px;
            padding: 15px;
        
            color: #F8F0E3;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: space-between;
        }
        .fbm-modal .fbm-headline {
            text-align: center;
            display: block;
            width: 100%;
            padding: 0 0 5px 15px;
            font-size: 1.4rem;
            font-family: inherit;
            margin: 0;
        }
        .fbm-modal .fbm-text {
            font-size: 1.1rem;
            line-height: 2;
            padding: 30px 15px;
        }
        .fbm-modal .fbm-button {
            background-position: 10px 10px;
            background-repeat: no-repeat;
            cursor: pointer;
            padding: 12px 20px;
            background-color: #3D517B;
            transition: 0.2s ease-in;
            color: white;
            border: none;
            display: flex;
            justify-content: center;
            align-items: center;
            width: 100%;
        }
        .fbm-modal .fbm-button:hover {
            background-color: #3D517B80;
        }
        .fbm-modal .fbm-button:focus {
            outline: none;
        }
        .fbm-modal .fbm-button img {
          margin-right: 7px;
        }
        .fbm-modal .fbm-logo {
            width: 50%;
            margin-bottom: 20px;
        }
        .fbm-modal .fbm-logo:focus {
            outline: none;
        }
    `;
      const lightTheme = `
        .fbm-blur {
            position: fixed;
            z-index: 3;
        
            width: 100vw;
            height: 100vh;
        
            left: 0;
            top: 0;
            background-color: #00000080;
        }
        @keyframes modalAnimation {
            from {
                top: 45%;
            }
            to {
                top: 50%;
            }
        }
        .fbm-modal {
            position: absolute;
            top: 50%;
            left: 50%;
        
            transform: translate(-50%, -50%);
            animation-name: modalAnimation;
            animation-duration: 1.5s;
            animation-delay: 0.2s;
        
            background-color: white;
            border-radius: 25px;
            padding: 15px;
        
            color: #111;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: space-between;
        }
        .fbm-modal .fbm-headline {
            text-align: center;
            display: block;
            width: 100%;
            padding: 0 0 5px 15px;
            font-size: 1.4rem;
            font-family: inherit;
            margin: 0;
        }
        .fbm-modal .fbm-text {
            font-size: 1.1rem;
            line-height: 2;
            padding: 30px 15px;
        }
        .fbm-modal .fbm-button {
            background-position: 10px 10px;
            background-repeat: no-repeat;
            cursor: pointer;
            padding: 12px 20px;
            background-color: #e1462c;
            transition: 0.2s ease-in;
            color: white;
            border: none;
            display: flex;
            justify-content: center;
            align-items: center;
            width: 100%;
            font-size: 1.1em;
        }
        .fbm-modal .fbm-button:hover {
            background-color: #e1462c80;
        }
        .fbm-modal .fbm-button:focus {
            outline: none;
        }
        .fbm-modal .fbm-button img {
          margin-right: 7px;
        }
        .fbm-modal .fbm-logo {
            width: 50%;
            margin-bottom: 20px;
        }
        .fbm-modal .fbm-logo:focus {
            outline: none;
        }
    `;
      const choice = theme === "dark" ? darkTheme : lightTheme;
      this.setStyle(choice);
    };
    // Add Modal to user-specified Document object
    this.addModalToDocument = () => {
      const blurEl = this.createElement("div");
      const modalEl = this.createElement("div");
      const headline = this.createElement("h3");
      const subtext = this.createElement("span");
      const logo = this.createLogo(this._logo);
      const button = this.createButton(this.getCorrectStoreLink(), this.getCorrectStoreButton());
      headline.classList.add("fbm-headline");
      headline.innerHTML = this._headline;
      subtext.classList.add("fbm-text");
      subtext.innerHTML = this._text;
      modalEl.classList.add("fbm-modal");
      modalEl.appendChild(logo);
      modalEl.appendChild(headline);
      modalEl.appendChild(subtext);
      modalEl.appendChild(button);
      // Do not close the Modal when clicked on the child element
      modalEl.addEventListener("click", ev => {
        ev.stopPropagation();
      });
      blurEl.classList.add("fbm-blur");
      blurEl.appendChild(modalEl);
      // Close the Modal when clicked anywhere outside the modal (aka the blur element)
      blurEl.addEventListener("click", () => {
        this.hideModal(blurEl);
      });
      // Append the modal to the document body.
      this._document.body.appendChild(blurEl);
    };
    /**
    * Returns an HTMLElement Button representation with a onClick redirect
    * @param link string: url the user get's redirected to on click
    * @param buttonContent Array: [store icon, store button text]
    * @returns HTMLElement : r2u button element
    */
    this.createButton = (link, buttonContent) => {
      const button = this.createElement("button");
      button.classList.add("fbm-button");
      const imgTag = `<img src="${buttonContent[0].default}"/>`;
      button.innerHTML = imgTag + buttonContent[1];
      button.addEventListener("click", () => this.redirectTo(link));
      return button;
    };
    // Create Logo Element from source
    this.createLogo = src => {
      const logo = this._document.createElement("img");
      logo.classList.add("fbm-logo");
      logo.src = src;
      return logo;
    };
    // Open a new tab after clicking the button
    this.redirectTo = link => {
      this._window.open(link, "_blank");
    };
    /**
    * Show the modal.
    */
    this.showModal = () => {
      this.addDefaultStyles(this._theme);
      this.addModalToDocument();
      this.addToCache();
      this.toggleBodyScroll();
      this._onOpen();
    };
    /**
    * Hide the modal.
    * @param element fbm-blur div as HTMLElement
    */
    this.hideModal = element => {
      this._document.body.removeChild(element);
      this.toggleBodyScroll();
      this._onClose();
    };
    /**
    * After opening the modal, add the timestamp to localStorage (for below checks)
    */
    this.addToCache = () => {
      webextension_polyfill_ts_1.browser.storage.local.get("feedbackprompt").then(data => {
        if (data.feedbackprompt && data.feedbackprompt.length > 0) {
          const times = data.feedbackprompt;
          times.push(Date.now());
          webextension_polyfill_ts_1.browser.storage.local.set({
            feedbackprompt: times
          });
        } else {
          const initialArr = [Date.now()];
          webextension_polyfill_ts_1.browser.storage.local.set({
            feedbackprompt: initialArr
          });
        }
      }).catch(error => console.log(error));
    };
    /**
    * Check if timeout has expired and modal can be shown
    * @returns Promise : true => show modal | false => don't show modal
    */
    this.isShowtime = () => tslib_1.__awaiter(this, void 0, void 0, function* () {
      return new Promise((resolve, reject) => {
        // If the modal is already shown use the last "shown" date, not the installDate
        webextension_polyfill_ts_1.browser.storage.local.get("feedbackprompt").then(data => {
          const now = new Date(Date.now());
          // Declaration if the modal hasn't been shown already.
          let lastDate = this._installDate.getTime();
          if (data.feedbackprompt && data.feedbackprompt.length > 0) {
            const times = data.feedbackprompt;
            lastDate = times[times.length - 1];
          }
          // Calculate the time passed to see if it's time to show the modal again
          const timePassed = now.getTime() - lastDate;
          if (timePassed > this._timeout) {
            resolve(true);
          } else {
            resolve(false);
          }
        }).catch(error => reject(error));
      });
    });
    // TODO : Forge these two functions together because of confusion and redundancy
    /**
    * Based on the specified frequency, show the modal yes(false)/no(true)
    * @returns Promise: true => don't show modal anymore | false => show it, has been shown less time than specified frequency
    */
    this.isShownEnoughTimes = () => tslib_1.__awaiter(this, void 0, void 0, function* () {
      return new Promise((resolve, reject) => {
        webextension_polyfill_ts_1.browser.storage.local.get("feedbackprompt").then(data => {
          if (data.feedbackprompt && data.feedbackprompt.length > 0) {
            const times = data.feedbackprompt;
            if (times.length >= this._frequency) {
              resolve(true);
              return;
            }
          }
          resolve(false);
          return;
        }).catch(error => reject(error));
      });
    });
    /**
    * Determines correct Store Link by looking at the users userAgent
    * @returns Either the corresponding link to the browser the user is using, or – if undefined – returns the first item in storeLinks
    */
    this.getCorrectStoreLink = () => {
      const browser = detection_1.default(navigator.userAgent);
      let resultBrowser = "chrome";
      // @ts-nolint-nextline
      const filter = Object.keys(browser).filter(el => browser[el] === true);
      if (filter.length === 0) {
        return "https://www.google.de";
      }
      // More than one engine was detected (i.e. Chrome -> Chrome + Webkit)
      if (filter.length > 1) {
        if (filter.includes("chrome")) {
          resultBrowser = "chrome";
        } else {
          resultBrowser = "chrome";
        }
              // Only one engine
} else // Only one engine
      {
        resultBrowser = filter[0];
      }
      return this._storeLinks[resultBrowser] || Object.values(this._storeLinks)[0];
    };
    /**
    * Returns the corresponding browser logo and button text
    * @returns [logo "image object"? (see imports), corresponding button text]
    */
    this.getCorrectStoreButton = () => {
      const browser = detection_1.default(navigator.userAgent);
      // @ts-nolint-nextline
      const filter = Object.keys(browser).filter(el => browser[el] === true);
      if (filter.includes("chrome")) {
        return [chrome_icon, "Visit the Chrome Web Store"];
      }
      if (filter.includes("firefox")) {
        return [firefox_icon, "Visit Firefox Addons"];
      }
      if (filter.includes("safari")) {
        return [safari_icon, "Visit the App Store"];
      }
      if (filter.includes("edge")) {
        return [edge_icon, "Visit the Microsoft Store"];
      }
      return chrome_icon;
    };
    /**
    * Toggles scrolling the body (on/off) when the modal is open or closed
    */
    this.toggleBodyScroll = () => {
      if (this._document.body.style.position === "fixed") {
        this._document.body.style.height = "100vh";
        this._document.body.style.overflowY = "hidden";
      } else {
        this._document.body.style.height = "";
        this._document.body.style.overflowY = "";
      }
    };
    this._document = window.document;
    this._window = window;
    this._headline = headline;
    this._text = text;
    this._logo = logo || "";
    this._timeout = timeout || 0;
    this._installDate = new Date(installDate) || Date.now();
    this._theme = theme || "light";
    this._storeLinks = storeLinks;
    this._frequency = frequency || 1;
    // eslint-disable-next-line @typescript-eslint/no-empty-function
    const noop = function () {};
    // use parameter function or do nothing
    this._onOpen = onOpen || noop;
    this._onClose = onClose || noop;
    // Show the modal if it's showtime and manual-mode is disabled (default)
    this.isShowtime().then(result => {
      if (result && !this._manual) {
        this.isShownEnoughTimes().then(result => {
          if (!result) this.showModal();
        });
      }
    });
  }
  /*Shortform create a HTMLElement*/
  createElement(tagName) {
    return this._document.createElement(tagName);
  }
  get timeout() {
    return this._timeout;
  }
  set timeout(value) {
    this._timeout = value;
  }
  get window() {
    return this._window;
  }
  set window(value) {
    this._window = value;
  }
  get installDate() {
    return this._installDate;
  }
  set installDate(value) {
    this._installDate = value;
  }
}
exports.default = WebExtFeedbackPrompt;

},{"tslib":"4zQDN","./detection":"T4Llq","webextension-polyfill-ts":"1HQou","url:./icons/chrome-logo.png":"3zMHZ","url:./icons/safari-logo.png":"2wNpg","url:./icons/edge-logo.png":"luw8z","url:./icons/firefox-logo.png":"57qR9"}],"4zQDN":[function(require,module,exports) {
var global = arguments[3];
var define;
/*! *****************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
******************************************************************************/
/*global global, define, System, Reflect, Promise*/
var __extends;
var __assign;
var __rest;
var __decorate;
var __param;
var __metadata;
var __awaiter;
var __generator;
var __exportStar;
var __values;
var __read;
var __spread;
var __spreadArrays;
var __await;
var __asyncGenerator;
var __asyncDelegator;
var __asyncValues;
var __makeTemplateObject;
var __importStar;
var __importDefault;
var __classPrivateFieldGet;
var __classPrivateFieldSet;
var __createBinding;
(function (factory) {
  var root = typeof global === "object" ? global : typeof self === "object" ? self : typeof this === "object" ? this : {};
  if (typeof define === "function" && define.amd) {
    define("tslib", ["exports"], function (exports) {
      factory(createExporter(root, createExporter(exports)));
    });
  } else if (typeof module === "object" && typeof module.exports === "object") {
    factory(createExporter(root, createExporter(module.exports)));
  } else {
    factory(createExporter(root));
  }
  function createExporter(exports, previous) {
    if (exports !== root) {
      if (typeof Object.create === "function") {
        Object.defineProperty(exports, "__esModule", {
          value: true
        });
      } else {
        exports.__esModule = true;
      }
    }
    return function (id, v) {
      return exports[id] = previous ? previous(id, v) : v;
    };
  }
})(function (exporter) {
  var extendStatics = Object.setPrototypeOf || ({
    __proto__: []
  }) instanceof Array && (function (d, b) {
    d.__proto__ = b;
  }) || (function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
  });
  __extends = function (d, b) {
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
  __assign = Object.assign || (function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  });
  __rest = function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
      if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
  };
  __decorate = function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc); else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return (c > 3 && r && Object.defineProperty(target, key, r), r);
  };
  __param = function (paramIndex, decorator) {
    return function (target, key) {
      decorator(target, key, paramIndex);
    };
  };
  __metadata = function (metadataKey, metadataValue) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
  };
  __awaiter = function (thisArg, _arguments, P, generator) {
    function adopt(value) {
      return value instanceof P ? value : new P(function (resolve) {
        resolve(value);
      });
    }
    return new (P || (P = Promise))(function (resolve, reject) {
      function fulfilled(value) {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      }
      function rejected(value) {
        try {
          step(generator["throw"](value));
        } catch (e) {
          reject(e);
        }
      }
      function step(result) {
        result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
      }
      step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
  };
  __generator = function (thisArg, body) {
    var _ = {
      label: 0,
      sent: function () {
        if (t[0] & 1) throw t[1];
        return t[1];
      },
      trys: [],
      ops: []
    }, f, y, t, g;
    return (g = {
      next: verb(0),
      "throw": verb(1),
      "return": verb(2)
    }, typeof Symbol === "function" && (g[Symbol.iterator] = function () {
      return this;
    }), g);
    function verb(n) {
      return function (v) {
        return step([n, v]);
      };
    }
    function step(op) {
      if (f) throw new TypeError("Generator is already executing.");
      while (_) try {
        if ((f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done)) return t;
        if ((y = 0, t)) op = [op[0] & 2, t.value];
        switch (op[0]) {
          case 0:
          case 1:
            t = op;
            break;
          case 4:
            _.label++;
            return {
              value: op[1],
              done: false
            };
          case 5:
            _.label++;
            y = op[1];
            op = [0];
            continue;
          case 7:
            op = _.ops.pop();
            _.trys.pop();
            continue;
          default:
            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
              _ = 0;
              continue;
            }
            if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
              _.label = op[1];
              break;
            }
            if (op[0] === 6 && _.label < t[1]) {
              _.label = t[1];
              t = op;
              break;
            }
            if (t && _.label < t[2]) {
              _.label = t[2];
              _.ops.push(op);
              break;
            }
            if (t[2]) _.ops.pop();
            _.trys.pop();
            continue;
        }
        op = body.call(thisArg, _);
      } catch (e) {
        op = [6, e];
        y = 0;
      } finally {
        f = t = 0;
      }
      if (op[0] & 5) throw op[1];
      return {
        value: op[0] ? op[1] : void 0,
        done: true
      };
    }
  };
  __createBinding = function (o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
  };
  __exportStar = function (m, exports) {
    for (var p in m) if (p !== "default" && !exports.hasOwnProperty(p)) exports[p] = m[p];
  };
  __values = function (o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
      next: function () {
        if (o && i >= o.length) o = void 0;
        return {
          value: o && o[i++],
          done: !o
        };
      }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
  };
  __read = function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
      while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    } catch (error) {
      e = {
        error: error
      };
    } finally {
      try {
        if (r && !r.done && (m = i["return"])) m.call(i);
      } finally {
        if (e) throw e.error;
      }
    }
    return ar;
  };
  __spread = function () {
    for (var ar = [], i = 0; i < arguments.length; i++) ar = ar.concat(__read(arguments[i]));
    return ar;
  };
  __spreadArrays = function () {
    for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
    for (var r = Array(s), k = 0, i = 0; i < il; i++) for (var a = arguments[i], j = 0, jl = a.length; j < jl; (j++, k++)) r[k] = a[j];
    return r;
  };
  __await = function (v) {
    return this instanceof __await ? (this.v = v, this) : new __await(v);
  };
  __asyncGenerator = function (thisArg, _arguments, generator) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var g = generator.apply(thisArg, _arguments || []), i, q = [];
    return (i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () {
      return this;
    }, i);
    function verb(n) {
      if (g[n]) i[n] = function (v) {
        return new Promise(function (a, b) {
          q.push([n, v, a, b]) > 1 || resume(n, v);
        });
      };
    }
    function resume(n, v) {
      try {
        step(g[n](v));
      } catch (e) {
        settle(q[0][3], e);
      }
    }
    function step(r) {
      r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r);
    }
    function fulfill(value) {
      resume("next", value);
    }
    function reject(value) {
      resume("throw", value);
    }
    function settle(f, v) {
      if ((f(v), q.shift(), q.length)) resume(q[0][0], q[0][1]);
    }
  };
  __asyncDelegator = function (o) {
    var i, p;
    return (i = {}, verb("next"), verb("throw", function (e) {
      throw e;
    }), verb("return"), i[Symbol.iterator] = function () {
      return this;
    }, i);
    function verb(n, f) {
      i[n] = o[n] ? function (v) {
        return (p = !p) ? {
          value: __await(o[n](v)),
          done: n === "return"
        } : f ? f(v) : v;
      } : f;
    }
  };
  __asyncValues = function (o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () {
      return this;
    }, i);
    function verb(n) {
      i[n] = o[n] && (function (v) {
        return new Promise(function (resolve, reject) {
          (v = o[n](v), settle(resolve, reject, v.done, v.value));
        });
      });
    }
    function settle(resolve, reject, d, v) {
      Promise.resolve(v).then(function (v) {
        resolve({
          value: v,
          done: d
        });
      }, reject);
    }
  };
  __makeTemplateObject = function (cooked, raw) {
    if (Object.defineProperty) {
      Object.defineProperty(cooked, "raw", {
        value: raw
      });
    } else {
      cooked.raw = raw;
    }
    return cooked;
  };
  __importStar = function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
  };
  __importDefault = function (mod) {
    return mod && mod.__esModule ? mod : {
      "default": mod
    };
  };
  __classPrivateFieldGet = function (receiver, privateMap) {
    if (!privateMap.has(receiver)) {
      throw new TypeError("attempted to get private field on non-instance");
    }
    return privateMap.get(receiver);
  };
  __classPrivateFieldSet = function (receiver, privateMap, value) {
    if (!privateMap.has(receiver)) {
      throw new TypeError("attempted to set private field on non-instance");
    }
    privateMap.set(receiver, value);
    return value;
  };
  exporter("__extends", __extends);
  exporter("__assign", __assign);
  exporter("__rest", __rest);
  exporter("__decorate", __decorate);
  exporter("__param", __param);
  exporter("__metadata", __metadata);
  exporter("__awaiter", __awaiter);
  exporter("__generator", __generator);
  exporter("__exportStar", __exportStar);
  exporter("__createBinding", __createBinding);
  exporter("__values", __values);
  exporter("__read", __read);
  exporter("__spread", __spread);
  exporter("__spreadArrays", __spreadArrays);
  exporter("__await", __await);
  exporter("__asyncGenerator", __asyncGenerator);
  exporter("__asyncDelegator", __asyncDelegator);
  exporter("__asyncValues", __asyncValues);
  exporter("__makeTemplateObject", __makeTemplateObject);
  exporter("__importStar", __importStar);
  exporter("__importDefault", __importDefault);
  exporter("__classPrivateFieldGet", __classPrivateFieldGet);
  exporter("__classPrivateFieldSet", __classPrivateFieldSet);
});

},{}],"T4Llq":[function(require,module,exports) {
"use strict";
Object.defineProperty(exports, "__esModule", {
  value: true
});
function detect(userAgent) {
  const browser = {
    webkit: false,
    chrome: false,
    firefox: false,
    safari: false,
    edge: false
  };
  if (!userAgent) {
    return browser;
  }
  const webkit = userAgent.match(/Web[kK]it[/]{0,1}([\d.]+)/);
  const chrome = userAgent.match(/Chrome\/([\d.]+)/) || userAgent.match(/CriOS\/([\d.]+)/);
  const firefox = userAgent.match(/Firefox\/([\d.]+)/);
  const safari = userAgent.match(/Version\/([\d.]+)([^S](Safari)|[^M]*(Mobile)[^S]*(Safari))/);
  const edge = userAgent.match(/Edge\/(\d{2,}\.[\d\w]+)$/);
  if (webkit && !edge) {
    browser.webkit = true;
  }
  if (chrome && !edge) {
    browser.chrome = true;
  }
  if (firefox && !edge) {
    browser.firefox = true;
  }
  if (safari) {
    browser.safari = true;
  }
  if (edge) {
    browser.edge = true;
  }
  return browser;
}
exports.default = detect;

},{}],"1HQou":[function(require,module,exports) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });

exports.browser = require("webextension-polyfill");

},{"webextension-polyfill":"1PbFA"}],"1PbFA":[function(require,module,exports) {
var define;
(function (global, factory) {
  if (typeof define === "function" && define.amd) {
    define("webextension-polyfill", ["module"], factory);
  } else if (typeof exports !== "undefined") {
    factory(module);
  } else {
    var mod = {
      exports: {}
    };
    factory(mod);
    global.browser = mod.exports;
  }
})(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : this, function (module) {
  /*webextension-polyfill - v0.8.0 - Tue Apr 20 2021 11:27:38*/
  /*-*- Mode: indent-tabs-mode: nil; js-indent-level: 2 -*-*/
  /*vim: set sts=2 sw=2 et tw=80:*/
  /*This Source Code Form is subject to the terms of the Mozilla Public
  * License, v. 2.0. If a copy of the MPL was not distributed with this
  * file, You can obtain one at http://mozilla.org/MPL/2.0/.*/
  "use strict";
  if (typeof browser === "undefined" || Object.getPrototypeOf(browser) !== Object.prototype) {
    const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
    const SEND_RESPONSE_DEPRECATION_WARNING = "Returning a Promise is the preferred way to send a reply from an onMessage/onMessageExternal listener, as the sendResponse will be removed from the specs (See https://developer.mozilla.org/docs/Mozilla/Add-ons/WebExtensions/API/runtime/onMessage)";
    // Wrapping the bulk of this polyfill in a one-time-use function is a minor
    // optimization for Firefox. Since Spidermonkey does not fully parse the
    // contents of a function until the first time it's called, and since it will
    // never actually need to be called, this allows the polyfill to be included
    // in Firefox nearly for free.
    const wrapAPIs = extensionAPIs => {
      // NOTE: apiMetadata is associated to the content of the api-metadata.json file
      // at build time by replacing the following "include" with the content of the
      // JSON file.
      const apiMetadata = {
        "alarms": {
          "clear": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "clearAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "get": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "bookmarks": {
          "create": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getChildren": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getRecent": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getSubTree": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTree": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "move": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeTree": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "browserAction": {
          "disable": {
            "minArgs": 0,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "enable": {
            "minArgs": 0,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "getBadgeBackgroundColor": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getBadgeText": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getPopup": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTitle": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "openPopup": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "setBadgeBackgroundColor": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setBadgeText": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setIcon": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "setPopup": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setTitle": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "browsingData": {
          "remove": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "removeCache": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeCookies": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeDownloads": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeFormData": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeHistory": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeLocalStorage": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removePasswords": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removePluginData": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "settings": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "commands": {
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "contextMenus": {
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "cookies": {
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAllCookieStores": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "set": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "devtools": {
          "inspectedWindow": {
            "eval": {
              "minArgs": 1,
              "maxArgs": 2,
              "singleCallbackArg": false
            }
          },
          "panels": {
            "create": {
              "minArgs": 3,
              "maxArgs": 3,
              "singleCallbackArg": true
            },
            "elements": {
              "createSidebarPane": {
                "minArgs": 1,
                "maxArgs": 1
              }
            }
          }
        },
        "downloads": {
          "cancel": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "download": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "erase": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getFileIcon": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "open": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "pause": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeFile": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "resume": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "show": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "extension": {
          "isAllowedFileSchemeAccess": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "isAllowedIncognitoAccess": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "history": {
          "addUrl": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "deleteAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "deleteRange": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "deleteUrl": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getVisits": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "i18n": {
          "detectLanguage": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAcceptLanguages": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "identity": {
          "launchWebAuthFlow": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "idle": {
          "queryState": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "management": {
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getSelf": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "setEnabled": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "uninstallSelf": {
            "minArgs": 0,
            "maxArgs": 1
          }
        },
        "notifications": {
          "clear": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "create": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getPermissionLevel": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "pageAction": {
          "getPopup": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTitle": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "hide": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setIcon": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "setPopup": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setTitle": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "show": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "permissions": {
          "contains": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "request": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "runtime": {
          "getBackgroundPage": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getPlatformInfo": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "openOptionsPage": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "requestUpdateCheck": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "sendMessage": {
            "minArgs": 1,
            "maxArgs": 3
          },
          "sendNativeMessage": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "setUninstallURL": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "sessions": {
          "getDevices": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getRecentlyClosed": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "restore": {
            "minArgs": 0,
            "maxArgs": 1
          }
        },
        "storage": {
          "local": {
            "clear": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "remove": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "set": {
              "minArgs": 1,
              "maxArgs": 1
            }
          },
          "managed": {
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            }
          },
          "sync": {
            "clear": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "remove": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "set": {
              "minArgs": 1,
              "maxArgs": 1
            }
          }
        },
        "tabs": {
          "captureVisibleTab": {
            "minArgs": 0,
            "maxArgs": 2
          },
          "create": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "detectLanguage": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "discard": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "duplicate": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "executeScript": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getCurrent": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getZoom": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getZoomSettings": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "goBack": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "goForward": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "highlight": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "insertCSS": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "move": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "query": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "reload": {
            "minArgs": 0,
            "maxArgs": 2
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeCSS": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "sendMessage": {
            "minArgs": 2,
            "maxArgs": 3
          },
          "setZoom": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "setZoomSettings": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "update": {
            "minArgs": 1,
            "maxArgs": 2
          }
        },
        "topSites": {
          "get": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "webNavigation": {
          "getAllFrames": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getFrame": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "webRequest": {
          "handlerBehaviorChanged": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "windows": {
          "create": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getCurrent": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getLastFocused": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        }
      };
      if (Object.keys(apiMetadata).length === 0) {
        throw new Error("api-metadata.json has not been included in browser-polyfill");
      }
      /**
      * A WeakMap subclass which creates and stores a value for any key which does
      * not exist when accessed, but behaves exactly as an ordinary WeakMap
      * otherwise.
      *
      * @param {function} createItem
      *        A function which will be called in order to create the value for any
      *        key which does not exist, the first time it is accessed. The
      *        function receives, as its only argument, the key being created.
      */
      class DefaultWeakMap extends WeakMap {
        constructor(createItem, items = undefined) {
          super(items);
          this.createItem = createItem;
        }
        get(key) {
          if (!this.has(key)) {
            this.set(key, this.createItem(key));
          }
          return super.get(key);
        }
      }
      /**
      * Returns true if the given object is an object with a `then` method, and can
      * therefore be assumed to behave as a Promise.
      *
      * @param {*} value The value to test.
      * @returns {boolean} True if the value is thenable.
      */
      const isThenable = value => {
        return value && typeof value === "object" && typeof value.then === "function";
      };
      /**
      * Creates and returns a function which, when called, will resolve or reject
      * the given promise based on how it is called:
      *
      * - If, when called, `chrome.runtime.lastError` contains a non-null object,
      *   the promise is rejected with that value.
      * - If the function is called with exactly one argument, the promise is
      *   resolved to that value.
      * - Otherwise, the promise is resolved to an array containing all of the
      *   function's arguments.
      *
      * @param {object} promise
      *        An object containing the resolution and rejection functions of a
      *        promise.
      * @param {function} promise.resolve
      *        The promise's resolution function.
      * @param {function} promise.reject
      *        The promise's rejection function.
      * @param {object} metadata
      *        Metadata about the wrapped method which has created the callback.
      * @param {boolean} metadata.singleCallbackArg
      *        Whether or not the promise is resolved with only the first
      *        argument of the callback, alternatively an array of all the
      *        callback arguments is resolved. By default, if the callback
      *        function is invoked with only a single argument, that will be
      *        resolved to the promise, while all arguments will be resolved as
      *        an array if multiple are given.
      *
      * @returns {function}
      *        The generated callback function.
      */
      const makeCallback = (promise, metadata) => {
        return (...callbackArgs) => {
          if (extensionAPIs.runtime.lastError) {
            promise.reject(new Error(extensionAPIs.runtime.lastError.message));
          } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
            promise.resolve(callbackArgs[0]);
          } else {
            promise.resolve(callbackArgs);
          }
        };
      };
      const pluralizeArguments = numArgs => numArgs == 1 ? "argument" : "arguments";
      /**
      * Creates a wrapper function for a method with the given name and metadata.
      *
      * @param {string} name
      *        The name of the method which is being wrapped.
      * @param {object} metadata
      *        Metadata about the method being wrapped.
      * @param {integer} metadata.minArgs
      *        The minimum number of arguments which must be passed to the
      *        function. If called with fewer than this number of arguments, the
      *        wrapper will raise an exception.
      * @param {integer} metadata.maxArgs
      *        The maximum number of arguments which may be passed to the
      *        function. If called with more than this number of arguments, the
      *        wrapper will raise an exception.
      * @param {boolean} metadata.singleCallbackArg
      *        Whether or not the promise is resolved with only the first
      *        argument of the callback, alternatively an array of all the
      *        callback arguments is resolved. By default, if the callback
      *        function is invoked with only a single argument, that will be
      *        resolved to the promise, while all arguments will be resolved as
      *        an array if multiple are given.
      *
      * @returns {function(object, ...*)}
      *       The generated wrapper function.
      */
      const wrapAsyncFunction = (name, metadata) => {
        return function asyncFunctionWrapper(target, ...args) {
          if (args.length < metadata.minArgs) {
            throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
          }
          if (args.length > metadata.maxArgs) {
            throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
          }
          return new Promise((resolve, reject) => {
            if (metadata.fallbackToNoCallback) {
              // This API method has currently no callback on Chrome, but it return a promise on Firefox,
              // and so the polyfill will try to call it with a callback first, and it will fallback
              // to not passing the callback if the first call fails.
              try {
                target[name](...args, makeCallback({
                  resolve,
                  reject
                }, metadata));
              } catch (cbError) {
                console.warn(`${name} API method doesn't seem to support the callback parameter, ` + "falling back to call it without a callback: ", cbError);
                target[name](...args);
                // Update the API method metadata, so that the next API calls will not try to
                // use the unsupported callback anymore.
                metadata.fallbackToNoCallback = false;
                metadata.noCallback = true;
                resolve();
              }
            } else if (metadata.noCallback) {
              target[name](...args);
              resolve();
            } else {
              target[name](...args, makeCallback({
                resolve,
                reject
              }, metadata));
            }
          });
        };
      };
      /**
      * Wraps an existing method of the target object, so that calls to it are
      * intercepted by the given wrapper function. The wrapper function receives,
      * as its first argument, the original `target` object, followed by each of
      * the arguments passed to the original method.
      *
      * @param {object} target
      *        The original target object that the wrapped method belongs to.
      * @param {function} method
      *        The method being wrapped. This is used as the target of the Proxy
      *        object which is created to wrap the method.
      * @param {function} wrapper
      *        The wrapper function which is called in place of a direct invocation
      *        of the wrapped method.
      *
      * @returns {Proxy<function>}
      *        A Proxy object for the given method, which invokes the given wrapper
      *        method in its place.
      */
      const wrapMethod = (target, method, wrapper) => {
        return new Proxy(method, {
          apply(targetMethod, thisObj, args) {
            return wrapper.call(thisObj, target, ...args);
          }
        });
      };
      let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
      /**
      * Wraps an object in a Proxy which intercepts and wraps certain methods
      * based on the given `wrappers` and `metadata` objects.
      *
      * @param {object} target
      *        The target object to wrap.
      *
      * @param {object} [wrappers = {}]
      *        An object tree containing wrapper functions for special cases. Any
      *        function present in this object tree is called in place of the
      *        method in the same location in the `target` object tree. These
      *        wrapper methods are invoked as described in {@see wrapMethod}.
      *
      * @param {object} [metadata = {}]
      *        An object tree containing metadata used to automatically generate
      *        Promise-based wrapper functions for asynchronous. Any function in
      *        the `target` object tree which has a corresponding metadata object
      *        in the same location in the `metadata` tree is replaced with an
      *        automatically-generated wrapper function, as described in
      *        {@see wrapAsyncFunction}
      *
      * @returns {Proxy<object>}
      */
      const wrapObject = (target, wrappers = {}, metadata = {}) => {
        let cache = Object.create(null);
        let handlers = {
          has(proxyTarget, prop) {
            return (prop in target) || (prop in cache);
          },
          get(proxyTarget, prop, receiver) {
            if ((prop in cache)) {
              return cache[prop];
            }
            if (!((prop in target))) {
              return undefined;
            }
            let value = target[prop];
            if (typeof value === "function") {
              // This is a method on the underlying object. Check if we need to do
              // any wrapping.
              if (typeof wrappers[prop] === "function") {
                // We have a special-case wrapper for this method.
                value = wrapMethod(target, target[prop], wrappers[prop]);
              } else if (hasOwnProperty(metadata, prop)) {
                // This is an async method that we have metadata for. Create a
                // Promise wrapper for it.
                let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                value = wrapMethod(target, target[prop], wrapper);
              } else {
                // This is a method that we don't know or care about. Return the
                // original method, bound to the underlying object.
                value = value.bind(target);
              }
            } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
              // This is an object that we need to do some wrapping for the children
              // of. Create a sub-object wrapper for it with the appropriate child
              // metadata.
              value = wrapObject(value, wrappers[prop], metadata[prop]);
            } else if (hasOwnProperty(metadata, "*")) {
              // Wrap all properties in * namespace.
              value = wrapObject(value, wrappers[prop], metadata["*"]);
            } else {
              // We don't need to do any wrapping for this property,
              // so just forward all access to the underlying object.
              Object.defineProperty(cache, prop, {
                configurable: true,
                enumerable: true,
                get() {
                  return target[prop];
                },
                set(value) {
                  target[prop] = value;
                }
              });
              return value;
            }
            cache[prop] = value;
            return value;
          },
          set(proxyTarget, prop, value, receiver) {
            if ((prop in cache)) {
              cache[prop] = value;
            } else {
              target[prop] = value;
            }
            return true;
          },
          defineProperty(proxyTarget, prop, desc) {
            return Reflect.defineProperty(cache, prop, desc);
          },
          deleteProperty(proxyTarget, prop) {
            return Reflect.deleteProperty(cache, prop);
          }
        };
        // Per contract of the Proxy API, the "get" proxy handler must return the
        // original value of the target if that value is declared read-only and
        // non-configurable. For this reason, we create an object with the
        // prototype set to `target` instead of using `target` directly.
        // Otherwise we cannot return a custom object for APIs that
        // are declared read-only and non-configurable, such as `chrome.devtools`.
        // 
        // The proxy handlers themselves will still use the original `target`
        // instead of the `proxyTarget`, so that the methods and properties are
        // dereferenced via the original targets.
        let proxyTarget = Object.create(target);
        return new Proxy(proxyTarget, handlers);
      };
      /**
      * Creates a set of wrapper functions for an event object, which handles
      * wrapping of listener functions that those messages are passed.
      *
      * A single wrapper is created for each listener function, and stored in a
      * map. Subsequent calls to `addListener`, `hasListener`, or `removeListener`
      * retrieve the original wrapper, so that  attempts to remove a
      * previously-added listener work as expected.
      *
      * @param {DefaultWeakMap<function, function>} wrapperMap
      *        A DefaultWeakMap object which will create the appropriate wrapper
      *        for a given listener function when one does not exist, and retrieve
      *        an existing one when it does.
      *
      * @returns {object}
      */
      const wrapEvent = wrapperMap => ({
        addListener(target, listener, ...args) {
          target.addListener(wrapperMap.get(listener), ...args);
        },
        hasListener(target, listener) {
          return target.hasListener(wrapperMap.get(listener));
        },
        removeListener(target, listener) {
          target.removeListener(wrapperMap.get(listener));
        }
      });
      const onRequestFinishedWrappers = new DefaultWeakMap(listener => {
        if (typeof listener !== "function") {
          return listener;
        }
        /**
        * Wraps an onRequestFinished listener function so that it will return a
        * `getContent()` property which returns a `Promise` rather than using a
        * callback API.
        *
        * @param {object} req
        *        The HAR entry object representing the network request.
        */
        return function onRequestFinished(req) {
          const wrappedReq = wrapObject(req, {
            /*wrappers*/
          }, /*wrappers*/
          {
            getContent: {
              minArgs: 0,
              maxArgs: 0
            }
          });
          listener(wrappedReq);
        };
      });
      // Keep track if the deprecation warning has been logged at least once.
      let loggedSendResponseDeprecationWarning = false;
      const onMessageWrappers = new DefaultWeakMap(listener => {
        if (typeof listener !== "function") {
          return listener;
        }
        /**
        * Wraps a message listener function so that it may send responses based on
        * its return value, rather than by returning a sentinel value and calling a
        * callback. If the listener function returns a Promise, the response is
        * sent when the promise either resolves or rejects.
        *
        * @param {*} message
        *        The message sent by the other end of the channel.
        * @param {object} sender
        *        Details about the sender of the message.
        * @param {function(*)} sendResponse
        *        A callback which, when called with an arbitrary argument, sends
        *        that value as a response.
        * @returns {boolean}
        *        True if the wrapped listener returned a Promise, which will later
        *        yield a response. False otherwise.
        */
        return function onMessage(message, sender, sendResponse) {
          let didCallSendResponse = false;
          let wrappedSendResponse;
          let sendResponsePromise = new Promise(resolve => {
            wrappedSendResponse = function (response) {
              if (!loggedSendResponseDeprecationWarning) {
                console.warn(SEND_RESPONSE_DEPRECATION_WARNING, new Error().stack);
                loggedSendResponseDeprecationWarning = true;
              }
              didCallSendResponse = true;
              resolve(response);
            };
          });
          let result;
          try {
            result = listener(message, sender, wrappedSendResponse);
          } catch (err) {
            result = Promise.reject(err);
          }
          const isResultThenable = result !== true && isThenable(result);
          // If the listener didn't returned true or a Promise, or called
          // wrappedSendResponse synchronously, we can exit earlier
          // because there will be no response sent from this listener.
          if (result !== true && !isResultThenable && !didCallSendResponse) {
            return false;
          }
          // A small helper to send the message if the promise resolves
          // and an error if the promise rejects (a wrapped sendMessage has
          // to translate the message into a resolved promise or a rejected
          // promise).
          const sendPromisedResult = promise => {
            promise.then(msg => {
              // send the message value.
              sendResponse(msg);
            }, error => {
              // Send a JSON representation of the error if the rejected value
              // is an instance of error, or the object itself otherwise.
              let message;
              if (error && (error instanceof Error || typeof error.message === "string")) {
                message = error.message;
              } else {
                message = "An unexpected error occurred";
              }
              sendResponse({
                __mozWebExtensionPolyfillReject__: true,
                message
              });
            }).catch(err => {
              // Print an error on the console if unable to send the response.
              console.error("Failed to send onMessage rejected reply", err);
            });
          };
          // If the listener returned a Promise, send the resolved value as a
          // result, otherwise wait the promise related to the wrappedSendResponse
          // callback to resolve and send it as a response.
          if (isResultThenable) {
            sendPromisedResult(result);
          } else {
            sendPromisedResult(sendResponsePromise);
          }
          // Let Chrome know that the listener is replying.
          return true;
        };
      });
      const wrappedSendMessageCallback = ({reject, resolve}, reply) => {
        if (extensionAPIs.runtime.lastError) {
          // Detect when none of the listeners replied to the sendMessage call and resolve
          // the promise to undefined as in Firefox.
          // See https://github.com/mozilla/webextension-polyfill/issues/130
          if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
            resolve();
          } else {
            reject(new Error(extensionAPIs.runtime.lastError.message));
          }
        } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
          // Convert back the JSON representation of the error into
          // an Error instance.
          reject(new Error(reply.message));
        } else {
          resolve(reply);
        }
      };
      const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
        if (args.length < metadata.minArgs) {
          throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
        }
        if (args.length > metadata.maxArgs) {
          throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
        }
        return new Promise((resolve, reject) => {
          const wrappedCb = wrappedSendMessageCallback.bind(null, {
            resolve,
            reject
          });
          args.push(wrappedCb);
          apiNamespaceObj.sendMessage(...args);
        });
      };
      const staticWrappers = {
        devtools: {
          network: {
            onRequestFinished: wrapEvent(onRequestFinishedWrappers)
          }
        },
        runtime: {
          onMessage: wrapEvent(onMessageWrappers),
          onMessageExternal: wrapEvent(onMessageWrappers),
          sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
            minArgs: 1,
            maxArgs: 3
          })
        },
        tabs: {
          sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
            minArgs: 2,
            maxArgs: 3
          })
        }
      };
      const settingMetadata = {
        clear: {
          minArgs: 1,
          maxArgs: 1
        },
        get: {
          minArgs: 1,
          maxArgs: 1
        },
        set: {
          minArgs: 1,
          maxArgs: 1
        }
      };
      apiMetadata.privacy = {
        network: {
          "*": settingMetadata
        },
        services: {
          "*": settingMetadata
        },
        websites: {
          "*": settingMetadata
        }
      };
      return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
    };
    if (typeof chrome != "object" || !chrome || !chrome.runtime || !chrome.runtime.id) {
      throw new Error("This script should only be loaded in a browser extension.");
    }
    // The build process adds a UMD wrapper around this file, which makes the
    // `module` variable available.
    module.exports = wrapAPIs(chrome);
  } else {
    module.exports = browser;
  }
});

},{}],"3zMHZ":[function(require,module,exports) {
module.exports = require('./bundle-url').getBundleURL() + "chrome-logo.7f47d82b.png";

},{"./bundle-url":"5fYKf"}],"2wNpg":[function(require,module,exports) {
module.exports = require('./bundle-url').getBundleURL() + "safari-logo.4b60422a.png";

},{"./bundle-url":"5fYKf"}],"luw8z":[function(require,module,exports) {
module.exports = require('./bundle-url').getBundleURL() + "edge-logo.d03db074.png";

},{"./bundle-url":"5fYKf"}],"57qR9":[function(require,module,exports) {
module.exports = require('./bundle-url').getBundleURL() + "firefox-logo.f2134a7f.png";

},{"./bundle-url":"5fYKf"}]},["FsXfO"], "FsXfO", "parcelRequire427e")

